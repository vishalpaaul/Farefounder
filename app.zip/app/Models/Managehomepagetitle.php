<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Managehomepagetitle extends Model
{
	protected $table='tb_home_page_title';
	protected $primaryKey = 'id';
	public $timestamps = false;
  protected $fillable = [
        'title_id', 'title', 'Description','status','delete_status'
    ];
}

