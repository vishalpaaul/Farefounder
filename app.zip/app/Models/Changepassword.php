<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Changepassword extends Model
{
  
  protected $table='users';
  public $timestamps = false;
  protected $fillable = [
        'id','name', 'email', 'password',
    ];
}

