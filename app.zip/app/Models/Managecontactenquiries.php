<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Managecontactenquiries extends Model
{
    use HasFactory;

    protected $table = 'tb_content_details'; // ✅ Ensure correct table name

    protected $fillable = [
        'name', 
        'email', 
        'phone', 
        'message',
		'status',
        'created_at',
        'delete_status'
    ];
	public $timestamps = false;
}

