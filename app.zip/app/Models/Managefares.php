<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Managefares extends Model
{
	protected $table='tb_destination_fare';
	public $timestamps = false;
  protected $fillable = ['page_id','origin', 'Origin_code', 'destination','destination_code', 'airline_image', 'status', 'delete_status'];
}

