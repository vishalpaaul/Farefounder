<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Managehotdeal extends Model
{
	protected $table='t_hot_deals';
	public $timestamps = false;
  protected $fillable = [
        'hot_deal_id','origin', 'destination','from_date','to_date','price_in_usd','result_url','airline_image','status'
    ];
}

