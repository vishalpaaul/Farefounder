<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Manageflightsdeal extends Model
{
	protected $table='t_flight_deal';
	
	public $timestamps = false;
  protected $fillable = [
        'origin', 'Origin_code', 'destination','destination_code',
    ];
}

