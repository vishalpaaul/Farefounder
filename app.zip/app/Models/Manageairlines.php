<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Manageairlines extends Model
{
	protected $table='tb_pages';
	protected $primaryKey = 'page_id';
	public $timestamps = false;
  protected $fillable = [
        'page_type_id', 'short_code','page_name','page_title','page_display_name','page_description','page_keyword','author','robots','og_type','og_title','og_description','og_url','og_image'
    ];
}

