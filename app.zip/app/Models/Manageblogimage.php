<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Manageblogimage extends Model
{
  protected $table='tb_blog_images';
  public $timestamps = false;
  protected $fillable = ['page_id', 'title_1', 'title_2', 'title_3', 'airline_image', 'status', 'delete_status'];
	
}

