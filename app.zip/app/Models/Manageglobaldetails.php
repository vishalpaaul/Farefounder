<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Manageglobaldetails extends Model
{
	protected $table='tb_global_details';
	public $timestamps = false;
  protected $fillable = [
        'contact_address_line1', 'contact_address_line2', 'toll_free_number','toll_free_number2','email', 'promo_code','airline_image','status',
    ];
}

