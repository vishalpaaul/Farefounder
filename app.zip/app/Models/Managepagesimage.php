<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Managepagesimage extends Model
{
  protected $table='tb_page_images';
  protected $primaryKey = 'id';
  public $timestamps = false;
  protected $fillable = ['id','page_id', 'title_1', 'title_2', 'title_3', 'airline_image', 'status', 'delete_status'];
	
}
