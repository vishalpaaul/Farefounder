<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Managepagesinformation extends Model
{
	protected $table='tb_information_page';
	//public $timestamps = false;
	//protected $primaryKey = 'id';
  protected $fillable = [
        'id', 'page_name','status','airline_image',
    ];
	
}

