<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Manageinformation extends Model
{
	protected $table='tb_manage_information';
	//public $timestamps = false;
	//protected $primaryKey = 'id';
  protected $fillable = [
        'pages_id', 'title_name', 'sub_title','discription','status','airline_image',
    ];
	
}

