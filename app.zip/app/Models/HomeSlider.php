<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HomeSlider extends Model
{
	public $timestamps = false;
  protected $fillable = [
        'title_1', 'title_2', 'title_3',
    ];
}

