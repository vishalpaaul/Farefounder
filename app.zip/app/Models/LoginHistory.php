<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LoginHistory extends Model
{
    use HasFactory;

    protected $table = 'login_histories'; // Table name

    protected $fillable = [
        'admin_id',
        'email',
        'ip_address',
        'user_agent',
        'login_time',
    ];

    // Define relationship (if you have an Admin model)
    public function admin()
    {
        return $this->belongsTo(Admin::class, 'admin_id');
    }
}