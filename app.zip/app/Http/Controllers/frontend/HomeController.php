<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Managecontactenquiries;
use App\Models\subscribers;
use Illuminate\Support\Facades\Validator;




class HomeController extends Controller
{
   public function index()
   {
	 return view('frontend.index');   
   }
   
   public function about()
   {
    return view('frontend.about-us');   
   }
   
   public function contact()
   {
     return view('frontend.contact-us');   
   }
   
   public function destinations($page_id)
   {
   //return view('frontend.destinations'); 
   return view('frontend.destinations',compact('page_id'));
 
   //return view('frontend.destinations', compact('destinations', 'page_id'));'page',
   }
   
   public function special()
   {
    return view('frontend.special-offers');   
   }

   public function privacy()
   {
    return view('frontend.privacy-policy');   
   }
   
    public function refund()
   {
    return view('frontend.refund-policy');   
   }
   
   public function terms()
   {
	return view('frontend.terms-conditions');   
   }
   public function Cancellation()
   {
	return view('frontend.Cancellation-policy');   
   }
   
 public function submitForm(Request $request)
{
    try {
        // ✅ Debug: Check incoming request data
        // dd($request->all());

        // ✅ Validation
        $validator = Validator::make($request->all(), [
            'name' => 'required|regex:/^[A-Za-z]+$/',
            'email' => 'required|email',
            'phone' => 'required|numeric|digits:10',
            'message' => 'required|regex:/^(?!.*http).*$/',
        ], [
            'name.regex' => 'First name should contain only letters.',
            'phone.numeric' => 'Phone number must contain only numbers.',
            'phone.digits' => 'Phone number must be 10 digits.',
            'message.regex' => 'Links are not allowed in the message.',
            'email.unique' => 'This email has already been used.'
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        // ✅ Save data to database
        $enquiry = new Managecontactenquiries();
        $enquiry->name = $request->name;
        $enquiry->email = $request->email;
        $enquiry->phone = $request->phone;
        $enquiry->message = $request->message;
        $enquiry->status = 'Enabled';  
        $enquiry->created_at = now();     
        $enquiry->delete_status = 'False';

        if ($enquiry->save()) {
			// ✅ Send email
            //Mail::to('booking@journeyflyer.com')->send(new ContactMail($enquiry));
            return redirect()->back()->with('success', 'Your message has been sent successfully!');
        }

        return redirect()->back()->with('error', 'Failed to submit the form. Try again.');
    
    } catch (Exception $e) {
        // Log the error for debugging
        Log::error('Form submission failed: ' . $e->getMessage());

        // Return with an error message
        return redirect()->back()->with('error', 'Something went wrong. Please try again later.');
    }
} 
    public function subscribers(Request $request)
    {
        // Validate the email input
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|unique:subscribers,email'
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()->first()], 422); // 422 for validation errors
        }

        // Store email in the database
        subscribers::create(['email' => $request->email]);

        return response()->json(['success' => 'Subscription successful!']);
    }	

}
