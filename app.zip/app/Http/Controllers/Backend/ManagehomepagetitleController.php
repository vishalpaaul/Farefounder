<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Managehomepagetitle;
class ManagehomepagetitleController extends Controller
{
    
    public function index()
    {
		
        $HomeTitle_show=Managehomepagetitle::orderBy('id','DESC')->where('delete_status', 1)->get()->toarray();
		
		$count = Managehomepagetitle::where('status','=','Enabled')->where('delete_status', 1)->count();
		return view('backend.manage_home_page_title',compact('count','HomeTitle_show'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    /* public function create()
    {
        //
    } */
public function Managehomepagetitle(Request $request)
	{
	 //
		
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
	   request()->validate([
		'title_id'=> 'required',
		'title'=> 'required',
		'Description'=>  'nullable|string', 
		]);
		
		  $data=$request->all();
		  if(!empty($data)){
		  try{
			
			$Managehomepagetitle=new Managehomepagetitle();
		    $Managehomepagetitle->title_id=$data['title_id'];
			$Managehomepagetitle->title=$data['title'];
			$Managehomepagetitle->Description=$data['Description'];
			$Managehomepagetitle->status=$data['status'];
			$Managehomepagetitle->created_at = date("Y-m-d H:i:s");
			$Managehomepagetitle->delete_status = 1;
			
			 $Managehomepagetitle->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
		}catch (\Exception $e){
			
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect("admin/manage_home_page_title");
		}
		 $request->session()->flash('alert-success', 'User added sucessfully'); 
		return redirect("admin/manage_home_page_title");
		  }
      else{
			 
	       return redirect()-back();  
		
          }	  
		/* echo "<pre>";
		print_r($data);
		die; */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $HomeTitle_show=Managehomepagetitle::orderBy('id','DESC')->where('delete_status', 1)->get()->toarray();
        $HomeTitle_edit=Managehomepagetitle::orderBy('id','DESC')->find($id)->toarray();
		
		$count = Managehomepagetitle::where('status','=','Enabled')->where('delete_status', 1)->count();
		return view('backend.manage_home_page_title',compact('count','HomeTitle_show','HomeTitle_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    	///print_r($id);exit();
        $data=$request->all();
        $Managehomepagetitle=Managehomepagetitle::findOrFail($id);
			
       //dd($request->all(), $request->file('airline_image'));
        request()->validate([
		'title_id'=> 'required',
		'title'=> 'required',
		'Description'=>  'required',
		]);
		 
		
		   $data=$request->all();
		   if(!empty($data)){
		   try{
			
			$Managehomepagetitle=Managehomepagetitle::findOrFail($id);
			
			$Managehomepagetitle->title_id=$data['title_id'];
			$Managehomepagetitle->title=$data['title'];
			$Managehomepagetitle->Description=$data['Description'];
			$Managehomepagetitle->status=$data['status'];
			$Managehomepagetitle->updated_at = date("Y-m-d H:i:s");
		
			$Managehomepagetitle->delete_status = 1;
			
			 $Managehomepagetitle->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
		}catch (\Exception $e){
			
			$request->session()->flash('alert-danger','Registration Failed');
	return redirect()->Route('manage_home_page_title.edit',$id);
		}
		 $request->session()->flash('alert-success', 'User Updates sucessfully'); 
		return redirect()->Route('manage_home_page_title.index');
		  }
      else{
			 
	   return redirect()->Route('manage_home_page_title.index');  
		
          }
    }


         /* public function status($slug)
         {   
        $id = $this->getValue($slug, $id=true);
        if($id){
            $change = $this->user->find($id);
            $active = $change->status;
            if ($id != null) 
            {
                if($active==1)
                {
                    $update_arr = array('status' => 0);
                     $this->user->where('id', $id)->update($update_arr);
                }
                else
                { 
                    $update_arr = array('status' => 1);
                    $this->user->where('id', $id)
                        ->update($update_arr);
                }
                 Session::flash('success', 'User status changed successfully.');             
            }else{
                Session::flash('warning', 'You have something went wrong');
            }
             return back();
        }else{
            Session::flash('warning', 'You have something went wrong');
        }
         return back();
    } */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   public function destroy(Request $request, $id)
  {
    try {
        // Find the record by ID
        $Managehomepagetitle = Managehomepagetitle::find($id);

        // Check if record exists
        if (!$Managehomepagetitle) {
            return redirect()->back()->with('alert-danger', 'Record not found.');
        }

        // Update the delete_status column instead of deleting the record
        $Managehomepagetitle->delete_status =  0;
        
        if ($Managehomepagetitle->save()) {
            $request->session()->flash('alert-success', 'User delete sucessfully.');
        } else {
            $request->session()->flash('alert-danger', 'Failed to update record.');
        }
    } catch (\Exception $e) {
        $request->session()->flash('alert-danger', 'Error: ' . $e->getMessage());
    }

    return redirect()->back();
}
	
}
