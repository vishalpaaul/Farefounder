<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Managehotdeal;

class ManagehotdealController extends Controller
{
    
    public function index()
    {
	   
        $Managehotdeal_show=Managehotdeal::orderBy('id','DESC')->where('delete_status', 1)->get()->toarray();
	    $count = Managehotdeal::where('status','=','Enabled')->where('delete_status', 1)->count();
		$Managehotdeal_show = Managehotdeal::where('delete_status', 1)->paginate(5); // Show 10 records per page
		return view('backend.manage_hotdeals',compact('count','Managehotdeal_show'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    /* public function create()
    {
        //
    } */
public function Managehotdeal(Request $request)
	{
	 //
		
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
	   request()->validate([
		'hot_deal_id'=> 'required',
		'origin'=> 'required',
		'destination'=>  'required',
		'from_date'=>  'required',
		'to_date'=>  'required',
		'price_in_usd'=>  'required',
		'result_url'=>  'required',
		'airline_image'=>'required|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',]);
		
		   $data=$request->all();
		   if(!empty($data)){
		   try{
			
			$Managehotdeal=new Managehotdeal();
			if($request->hasfile('airline_image'))
            {
            $file = $request->file('airline_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Managehotdeal->airline_image = $imageName;
            }
			$Managehotdeal->hot_deal_id=$data['hot_deal_id'];
			$Managehotdeal->origin=$data['origin'];
			$Managehotdeal->destination=$data['destination'];
			$Managehotdeal->from_date = date('Y-m-d', strtotime($request->input('from_date')));
			$Managehotdeal->to_date = date('Y-m-d', strtotime($request->input('to_date')));
			$Managehotdeal->price_in_usd=$data['price_in_usd'];
			$Managehotdeal->result_url=$data['result_url'];
			$Managehotdeal->status=$data['status'];
			$Managehotdeal->created_at = date("Y-m-d H:i:s");
			$Managehotdeal->delete_status = 1;
			
			 $Managehotdeal->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
			
		}catch (\Exception $e){
			 echo "<pre>";
		print_r($data);
		die; 
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect("admin/manage_hotdeals");
		}
		 $request->session()->flash('alert-success', 'User added sucessfully'); 
		return redirect("admin/manage_hotdeals");
		  }
      else{
			 
	       return redirect()-back();  
		
          }	  
		/* echo "<pre>";
		print_r($data);
		die; */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $Managehotdeal_show=Managehotdeal::orderBy('id','DESC')->where('delete_status', 1)->get()->toarray();
        $manage_hotdeals_edit=Managehotdeal::orderBy('id','DESC')->find($id)->toarray();
		
		$count = Managehotdeal::where('status','=','Enabled')->where('delete_status', 1)->count();
		 $Managehotdeal_show = Managehotdeal::where('delete_status', 1)->paginate(5);
		return view('backend.manage_hotdeals',compact('count','Managehotdeal_show','manage_hotdeals_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    	///dd($request->all());
    		$data=$request->all();
    		$Managehotdeal=Managehotdeal::findOrFail($id);
			//dd($Managehotdeal);
        request()->validate([
		'hot_deal_id' => 'required',
        'origin' => 'required',
        'destination' => 'required',
        'from_date' => 'required|date',
        'to_date' => 'required|date',
        'price_in_usd' => 'required|numeric',
        'result_url' => 'required',
        'airline_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',]);
		  
		  $data=$request->all();
		   if(!empty($data)){
		   try{
			
			$Managehotdeal=Managehotdeal::findOrFail($id);
			if($request->hasfile('airline_image'))
            {
            
            $file = $request->file('airline_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Managehotdeal->airline_image = $imageName;
            }
			$Managehotdeal->hot_deal_id=$data['hot_deal_id'];
			$Managehotdeal->origin=$data['origin'];
			$Managehotdeal->destination=$data['destination'];
			$Managehotdeal->from_date = date('Y-m-d', strtotime($request->input('from_date')));
			$Managehotdeal->to_date = date('Y-m-d', strtotime($request->input('to_date')));
			$Managehotdeal->price_in_usd=$data['price_in_usd'];
			$Managehotdeal->result_url=$data['result_url'];
			$Managehotdeal->status=$data['status'];
			$Managehotdeal->updated_at = date("Y-m-d H:i:s");
			$Managehotdeal->delete_status = 1;
			
			$Managehotdeal->save(); 
			
		}catch (\Exception $e){
			
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect()->Route('manage_hotdeals.edit',$id);
		}
		 $request->session()->flash('alert-success', 'User Updates sucessfully'); 
		return redirect()->Route('manage_hotdeals.index');
		  }
      else{
			 
	       return redirect()->Route('manage_hotdeals.index');  
		
          }
    }


        public function updateStatus(Request $request)
        {
       try {
        $Managehotdeal = Managehotdeal::findOrFail($request->id);
        $Managehotdeal->status = $request->status;
        $Managehotdeal->save();

        return response()->json(['message' => 'Status updated successfully!']);
    } catch (\Exception $e) {
        return response()->json(['message' => 'Error updating status!'], 500);
    }
}

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
   {
    try {
        // Find the record by ID
        $Managehotdeal = Managehotdeal::find($id);

        // Check if record exists
        if (!$Managehotdeal) {
            return redirect()->back()->with('alert-danger', 'Record not found.');
        }

        // Update the delete_status column instead of deleting the record
        $Managehotdeal->delete_status = 0;
        
        if ($Managehotdeal->save()) {
            $request->session()->flash('alert-success', 'User delete sucessfully.');
        } else {
            $request->session()->flash('alert-danger', 'Failed to update record.');
        }
    } catch (\Exception $e) {
        $request->session()->flash('alert-danger', 'Error: ' . $e->getMessage());
    }

    return redirect()->back();
  }

	
	
}
