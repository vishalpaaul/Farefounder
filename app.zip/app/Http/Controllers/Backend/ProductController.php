<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{    
    public function index()
    {
        $data_list=Product::all();
        return view('backend.product',compact('data_list'));
    }
    public function create()
    {
        $data_list=Product::all();
        $Form="Show";
        return view('backend.product',compact('data_list','Form'));
    }
    public function store(Request $request)
    {
        $rulesVar=[
                    'product_name' => 'required',                   
                    'description' => 'required',
                  ];
        $validatedData = $request->validate($rulesVar);

        $Product=new Product();
        
        $Product->product_name=$request->product_name;
        $Product->description=$request->description;
        
        $Product->save();
        return redirect()->route('Product.index')->with('flash_message','Data Inserted SuccessFully'); 
    }
    public function show($id)
    {
        
    }
    public function edit($id)
    {
        $data_list=Product::all();
        $data_edit=Product::findOrFail($id);
        $Form="Show";
        return view('backend.product',compact('data_list','data_edit','Form'));
    }
    public function update(Request $request, $id)
    {
        $rulesVar=[
                    'product_name' => 'required',                   
                    'description' => 'required',
                  ];
        $validatedData = $request->validate($rulesVar);

        $Product=Product::findOrFail($id);
        
        $Product->product_name=$request->product_name;
        $Product->description=$request->description;
        
        $Product->save();
        return redirect()->route('Product.index')->with('flash_message','Data Updated SuccessFully'); 
        
    }
    public function destroy($id)
    {
        $Product=Product::findOrFail($id);
        $Product->delete();       
        return redirect()->route('Product.index')->with('flash_message','Data Deleted SuccessFully');
       
    }
}
