<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Manageblog;
class ManageblogController extends Controller
{
    
    public function index()
    {
		
		//$Manageblog_show = t_flight_deal::orderBy('page_id','ASC')->get();
        $Manageblog_show=Manageblog::orderBy('page_id','DESC')->where('delete_status', 'False')->where('page_type_id','=',6)->get()->toarray();
		///$Manageblog_show=t_flight_deal::get()->toarray();
		$count = Manageblog::where('status','=','Enabled')->where('delete_status', 'False')->where('page_type_id','=',6)->count();
		
		return view('backend.manage_blog',compact('count','Manageblog_show'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    /* public function create()
    {
        //
    } */
public function Manageblog(Request $request)
	{
	 //
		
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       //dd(request()->toarray());
	   request()->validate([
		'short_code'=> 'required',
		'page_type_id'=>  'required',
		'page_name'=>  'required',
		'page_title'=>  'required',
		'user_name'=>  'required',
		'comments'=>  'required',
		'eye'=>  'required',
		'page_display_name'=>  'required',
		'page_description'=>  'required',
		'page_keyword'=>  'required',
		'author'=>  'required',
		'robots'=>  'required',
		'og_type'=>  'required',
		'og_title'=>  'required',
		'og_description'=>  'required',
		'og_url'=>  'required',
		'paratitle'=>  'required',
		'paracontent'=>  'required',
		'og_image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',]);
		
		   $data=$request->all();
		   if(!empty($data)){
		   try{
			
			$Manageblog=new Manageblog();
			if($request->hasfile('og_image'))
            {
            $file = $request->file('og_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Manageblog->og_image = $imageName;
            }
			$Manageblog->short_code=$data['short_code'];
			$Manageblog->page_type_id=$data['page_type_id'];
			
			$Manageblog->page_name=$data['page_name'];
			$Manageblog->page_title=$data['page_title'];
			$Manageblog->user_name=$data['user_name'];
			$Manageblog->comments=$data['comments'];
			$Manageblog->eye=$data['eye'];
			$Manageblog->page_display_name=$data['page_display_name'];
			$Manageblog->page_description=$data['page_description'];
			$Manageblog->page_keyword=$data['page_keyword'];
			$Manageblog->author=$data['author'];
			$Manageblog->robots=$data['robots'];
			$Manageblog->og_type=$data['og_type'];
			$Manageblog->og_title=$data['og_title'];
			$Manageblog->paratitle=$data['paratitle'];
			$Manageblog->paracontent=$data['paracontent'];
			$Manageblog->og_description=$data['og_description'];
			$Manageblog->og_url=$data['og_url'];
			$Manageblog->status=$data['status'];
			$Manageblog->created_at = date("Y-m-d H:i:s");
			
			$Manageblog->delete_status = 'False';
			
			 $Manageblog->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
			
		}catch (\Exception $e){
		//echo "<pre>";
		//print_r($data);
		//die; 
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect("admin/manage_blog");
		}
		 $request->session()->flash('alert-success', 'User added sucessfully'); 
		return redirect("admin/manage_blog");
		  }
      else{
			 
	       return redirect()-back();  
		
          }	  
		/* echo "<pre>";
		print_r($data);
		die; */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($page_id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($page_id)
    {
        $Manageblog_show=Manageblog::orderBy('page_id','DESC')->where('delete_status', 'False')->get()->toarray();
        $manage_blog_edit=Manageblog::orderBy('page_id','DESC')->find($page_id)->toarray();
		$count = Manageblog::where('status','=','Enabled')->where('delete_status', 'False')->count();
		return view('backend.manage_blog',compact('count','Manageblog_show','manage_blog_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $page_id)
    {
    	///print_r($page_id);exit();
    		$data=$request->all();
    		$Manageblog=Manageblog::findOrFail($page_id);
			/* print_r($Manageblog->toArray());//exit();
			echo "<hr>";
			print_r($data);exit(); */

        request()->validate([
		'short_code'=> 'required',
		'page_type_id'=>  'required',
		
		'page_name'=>  'required',
		'page_title'=>  'required',
		'user_name'=>  'required',
		'comments'=>  'required',
		'eye'=>  'required',
		'page_display_name'=>  'required',
		'page_description'=>  'required',
		'page_keyword'=>  'required',
		'author'=>  'required',
		'robots'=>  'required',
		'og_type'=>  'required',
		'og_title'=>  'required',
		'og_description'=>  'required',
		'og_url'=>  'required',
		'paratitle'=>  'required',
		'paracontent'=>  'required',
		'og_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',]);
		
		   $data=$request->all();
		   if(!empty($data)){
		   try{
			
			$Manageblog=Manageblog::findOrFail($page_id);
			if($request->hasfile('og_image'))
            {
            $file = $request->file('og_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Manageblog->og_image = $imageName;
            }
			$Manageblog->short_code=$data['short_code'];
			$Manageblog->page_type_id=$data['page_type_id'];
			
			$Manageblog->page_name=$data['page_name'];
			$Manageblog->page_title=$data['page_title'];
			$Manageblog->user_name=$data['user_name'];
			$Manageblog->comments=$data['comments'];
			$Manageblog->eye=$data['eye'];
			$Manageblog->page_display_name=$data['page_display_name'];
			$Manageblog->page_description=$data['page_description'];
			$Manageblog->page_keyword=$data['page_keyword'];
			$Manageblog->author=$data['author'];
			$Manageblog->robots=$data['robots'];
			$Manageblog->og_type=$data['og_type'];
			$Manageblog->og_title=$data['og_title'];
			$Manageblog->paratitle=$data['paratitle'];
			$Manageblog->paracontent=$data['paracontent'];
			$Manageblog->og_description=$data['og_description'];
			$Manageblog->og_url=$data['og_url'];
			$Manageblog->status=$data['status'];
			$Manageblog->created_at = date("Y-m-d H:i:s");
			
			$Manageblog->delete_status = 'False';
			
			 $Manageblog->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
		}catch (\Exception $e){
			
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect()->Route('manage_blog.edit',$page_id);
		}
		 $request->session()->flash('alert-success', 'User Updates sucessfully'); 
		return redirect()->Route('manage_blog.index');
		  }
      else{
			 
	       return redirect()->Route('manage_blog.index');  
		
          }
    }


         /* public function status($slug)
         {   
        $id = $this->getValue($slug, $id=true);
        if($id){
            $change = $this->user->find($id);
            $active = $change->status;
            if ($id != null) 
            {
                if($active==1)
                {
                    $update_arr = array('status' => 0);
                     $this->user->where('id', $id)->update($update_arr);
                }
                else
                { 
                    $update_arr = array('status' => 1);
                    $this->user->where('id', $id)
                        ->update($update_arr);
                }
                 Session::flash('success', 'User status changed successfully.');             
            }else{
                Session::flash('warning', 'You have something went wrong');
            }
             return back();
        }else{
            Session::flash('warning', 'You have something went wrong');
        }
         return back();
    } */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     
	
	public function destroy(Request $request, $page_id)
    {
    try {
        // Find the record by page id
        $Manageblog = Manageblog::find($page_id);

        // Check if record exists
        if (!$Manageblog) {
            return redirect()->back()->with('alert-danger', 'Record not found.');
        }

        // Update the delete_status column instead of deleting the record
        $Manageblog->delete_status = 'True';
        
        if ($Manageblog->save()) {
            $request->session()->flash('alert-success', 'User delete sucessfully.');
        } else {
            $request->session()->flash('alert-danger', 'Failed to update record.');
        }
    } catch (\Exception $e) {
        $request->session()->flash('alert-danger', 'Error: ' . $e->getMessage());
    }

    return redirect()->back();
  }
}
