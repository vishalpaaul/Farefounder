<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Models\HomeSlider;
class flightsdealController extends Controller
{
    
    public function index()
    {
		
		//$HomeSlider_show = HomeSlider::orderBy('id','ASC')->get();
        $HomeSlider_show=HomeSlider::orderBy('id','DESC')->get()->toarray();
		///$HomeSlider_show=HomeSlider::get()->toarray();
		$count = HomeSlider::where('status','=','Enabled')->count();
		return view('backend.manage_flights_deal',compact('count','HomeSlider_show'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    /* public function create()
    {
        //
    } */
public function HomeSlider(Request $request)
	{
	 //
		
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
	   request()->validate([
		'title_1'=> 'required',
		'title_2'=> 'required',
		'title_3'=>  'required',
		'airline_image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',]);
		
		$imageName = time().'.'.$request->airline_image->extension();  
        $request->airline_image->move(public_path('images'), $imageName);
	      
		  $data=$request->all();
		   if(!empty($data)){
		try{
			
			$HomeSlider=new HomeSlider();
			$HomeSlider->title_1=$data['title_1'];
			$HomeSlider->title_2=$data['title_2'];
			$HomeSlider->title_3=$data['title_3'];
			$HomeSlider->status=$data['status'];
			$HomeSlider->created_at = date("Y-m-d H:i:s");
			$HomeSlider->airline_image = $imageName;
			$HomeSlider->delete_status = 'False';
			
			 $HomeSlider->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
		}catch (\Exception $e){
			
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect("manage_flights_deal");
		}
		 $request->session()->flash('alert-success', 'User added sucessfully'); 
		return redirect("manage_flights_deal");
		  }
      else{
			 
	       return redirect()-back();  
		
          }	  
		/* echo "<pre>";
		print_r($data);
		die; */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $HomeSlider_show=HomeSlider::orderBy('id','DESC')->get()->toarray();
        $HomeSlider_edit=HomeSlider::orderBy('id','DESC')->find($id)->toarray();
		$count = HomeSlider::where('status','=','Enabled')->count();
		return view('backend.manage_flights_deal',compact('count','HomeSlider_show','HomeSlider_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    	///print_r($id);exit();
    		$data=$request->all();
    		$HomeSlider=HomeSlider::findOrFail($id);
			/* print_r($HomeSlider->toArray());//exit();
			echo "<hr>";
			print_r($data);exit(); */

        request()->validate([
		'title_1'=> 'required',
		'title_2'=> 'required',
		'title_3'=>  'required',
		'airline_image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',]);
		
		$imageName = time().'.'.$request->airline_image->extension();  
        $request->airline_image->move(public_path('images'), $imageName);
	      
		  $data=$request->all();
		   if(!empty($data)){
		try{
			
			$HomeSlider=HomeSlider::findOrFail($id);
			
			$HomeSlider->title_1=$data['title_1'];
			$HomeSlider->title_2=$data['title_2'];
			$HomeSlider->title_3=$data['title_3'];
			$HomeSlider->status=$data['status'];
			$HomeSlider->updated_at = date("Y-m-d H:i:s");
			$HomeSlider->airline_image = $imageName;
			$HomeSlider->delete_status = 'False';
			
			 $HomeSlider->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
		}catch (\Exception $e){
			
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect()->Route('manage_flights_deal.edit',$id);
		}
		 $request->session()->flash('alert-success', 'User Updates sucessfully'); 
		return redirect()->Route('manage_flights_deal.index');
		  }
      else{
			 
	       return redirect()->Route('manage_flights_deal.index');  
		
          }
    }


         /* public function status($slug)
         {   
        $id = $this->getValue($slug, $id=true);
        if($id){
            $change = $this->user->find($id);
            $active = $change->status;
            if ($id != null) 
            {
                if($active==1)
                {
                    $update_arr = array('status' => 0);
                     $this->user->where('id', $id)->update($update_arr);
                }
                else
                { 
                    $update_arr = array('status' => 1);
                    $this->user->where('id', $id)
                        ->update($update_arr);
                }
                 Session::flash('success', 'User status changed successfully.');             
            }else{
                Session::flash('warning', 'You have something went wrong');
            }
             return back();
        }else{
            Session::flash('warning', 'You have something went wrong');
        }
         return back();
    } */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function destroy(Request $request,$id)
	{
	try{
	  HomeSlider::where('id',$id)->delete();
      $request->session()->flash('alert-success', 'User delete sucessfully'); 	  
	}	catch (\Exception $e){
	$request->session()->flash('alert-danger','Failed');	
	}
	return redirect()->back();	
	} 
	
}
