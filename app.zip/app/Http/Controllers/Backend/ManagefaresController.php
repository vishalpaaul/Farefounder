<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Managefares;
class ManagefaresController extends Controller
{
    
    public function index($page_id)
    {
	$Managefares_show=Managefares::orderBy('id','DESC')->where('page_id', $page_id)->where('delete_status', 1)->get()->toarray();
    $count = Managefares::where('status', 'Enabled')->where('page_id', $page_id)->where('delete_status', 1)->count();
    //dd($Managefares_show);
    return view('backend.manage_fares',compact('count','Managefares_show',$page_id));	
	}

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    /* public function create()
    {
        //
    } */
public function Managefares(Request $request)
	{
	 //
		
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
     $request->validate([
        'page_id' => 'required|integer', // Ensure page_id is included and valid
        'origin' => 'required|string|max:255',
        'Origin_code' => 'required|string|max:255',
        'destination' => 'required|string|max:255',
        'destination_code'=> 'required|string|max:255',
		'from_date'=>  'required|string|max:255',
		'to_date'=>  'required|string|max:255',
		'price_in_usd'=> 'required|string|max:255',
		'result_url'=> 'required|string|max:255',
		'airline_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
    ]);  
	
		   $data=$request->all();
		   if(!empty($data)){
		   try{
			$page_id = intval($request->input('page_id'));
			$Managefares=new Managefares();
			if($request->hasfile('airline_image'))
            {
            $file = $request->file('airline_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Managefares->airline_image = $imageName;
            }
			$Managefares->page_id = $page_id;
			$Managefares->origin=$data['origin'];
			$Managefares->Origin_code=$data['Origin_code'];
			$Managefares->destination=$data['destination'];
			$Managefares->destination_code=$data['destination_code'];
		    $Managefares->from_date = date('Y-m-d', strtotime($request->input('from_date')));
			$Managefares->to_date = date('Y-m-d', strtotime($request->input('to_date')));
			$Managefares->price_in_usd=$data['price_in_usd'];
			$Managefares->result_url=$data['result_url'];
			$Managefares->status=$data['status'];
			$Managefares->created_at = date("Y-m-d H:i:s");
			$Managefares->delete_status = 1;
			
			 $Managefares->save(); 
			 $page_id = $Managefares->page_id;//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
			
		// Success message and redirect
        $request->session()->flash('alert-success', "Record added successfully with ID: $page_id");
     return redirect('admin/manage_fares/'.$page_id);
    } catch (\Exception $e) {
        // Error handling
        $request->session()->flash('alert-danger', 'Registration Failed. Error: ' . $e->getMessage());
        return redirect()->back()->withInput();
    }
		  }
      else{
			 
	       return redirect()-back();  
		
          }	  
		/* echo "<pre>";
		print_r($data);
		die; */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($page_id)
    {
     //dd($page_id); 
	 $Managefares_show=Managefares::orderBy('id','DESC')->where('page_id', $page_id)->where('delete_status', 1)->get()->toarray();
    $count = Managefares::where('status', 'Enabled')->where('page_id', $page_id)->where('delete_status', 1)->count();
    //dd($Managefares_show);
    return view('backend.manage_fares',compact('count','Managefares_show','page_id'));
	
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $manage_fares_edit=Managefares::findOrFail($id); ;
      $page_id = $manage_fares_edit->page_id;
	  
	  $Managefares_show = Managefares::where('page_id', $page_id)->orderBy('id', 'DESC')->where('delete_status', 1)->get();
		
	  $count = Managefares::where('status', 'Enabled')->where('delete_status', 1)->where('page_id', $page_id)->count();
	  
	  session()->flash('page_id', $page_id);
		
	 return view('backend.manage_fares',compact('count','Managefares_show','manage_fares_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
        'page_id' => 'required',
        'origin'=> 'required',
		'Origin_code'=> 'required',
		'destination'=>  'required',
		'destination_code'=>  'required',
		'from_date'=>  'required',
		'to_date'=>  'required',
		'price_in_usd'=>  'required',
		'result_url'=>  'required',
		'airline_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',]);
		
		
		  
		 $validatedData = $request->all();
		   if(!empty($validatedData)){
		   try{
			
			$Managefares=Managefares::findOrFail($id);
			if($request->hasfile('airline_image'))
            {
            $file = $request->file('airline_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Managefares->airline_image = $imageName;
            }
			$Managefares->page_id = $validatedData['page_id'];
			$Managefares->origin=$validatedData['origin'];
			$Managefares->Origin_code=$validatedData['Origin_code'];
			$Managefares->destination=$validatedData['destination'];
			$Managefares->destination_code=$validatedData['destination_code'];
		    $Managefares->from_date = date('Y-m-d', strtotime($request->input('from_date')));
			$Managefares->to_date = date('Y-m-d', strtotime($request->input('to_date')));
			$Managefares->price_in_usd=$validatedData['price_in_usd'];
			$Managefares->result_url=$validatedData['result_url'];
			$Managefares->status=$validatedData['status'];
			$Managefares->updated_at = date("Y-m-d H:i:s");
			$Managefares->delete_status = 1;
			
			 $Managefares->save(); 
			// Flash success message with ID
           $page_id = $Managefares->page_id;
            $request->session()->flash('alert-success', "User updated successfully with page id: $page_id");

            // Redirect to the index route with the page_id
            return redirect('admin/manage_fares/'.$page_id);

        } catch (\Exception $e) {
            // Flash error message
            $request->session()->flash('alert-danger', 'Registration Failed');
             return redirect('admin/manage_fares/'.$page_id);
        }
    } else {
        // Redirect to index route with the page_id if data is empty
        return redirect('admin/manage_fares/'.$page_id);
    }
    }


         /* public function status($slug)
         {   
        $id = $this->getValue($slug, $id=true);
        if($id){
            $change = $this->user->find($id);
            $active = $change->status;
            if ($id != null) 
            {
                if($active==1)
                {
                    $update_arr = array('status' => 0);
                     $this->user->where('id', $id)->update($update_arr);
                }
                else
                { 
                    $update_arr = array('status' => 1);
                    $this->user->where('id', $id)
                        ->update($update_arr);
                }
                 Session::flash('success', 'User status changed successfully.');             
            }else{
                Session::flash('warning', 'You have something went wrong');
            }
             return back();
        }else{
            Session::flash('warning', 'You have something went wrong');
        }
         return back();
    } */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function destroy(Request $request, $id)
{
    try {
        // Find the record by ID
        $manageFare = Managefares::find($id);

        // Check if record exists
        if (!$manageFare) {
            return redirect()->back()->with('alert-danger', 'Record not found.');
        }

        // Update the delete_status column instead of deleting the record
        $manageFare->delete_status = 0;
        
        if ($manageFare->save()) {
            $request->session()->flash('alert-success', 'Record marked as False successfully.');
        } else {
            $request->session()->flash('alert-danger', 'Failed to update record.');
        }
    } catch (\Exception $e) {
        $request->session()->flash('alert-danger', 'Error: ' . $e->getMessage());
    }

    return redirect()->back();
} 
	
}
