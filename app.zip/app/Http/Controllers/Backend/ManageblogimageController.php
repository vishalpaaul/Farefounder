<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Models\Manageblogimage;
class ManageblogimageController extends Controller
{

    
	public function index($page_id)
{
      //dd($page_id);
	    
	  $Manageblogimage_show=Manageblogimage::orderBy('id','DESC')->where('delete_status', 'False')->where('page_id', $page_id)->get()->toarray();
    $count = Manageblogimage::where('status', 'Enabled')->where('delete_status', 'False')->where('page_id', $page_id)->count();
    //dd($Manageblogimage_show);
    return view('backend.manage_blog_image',compact('count','Manageblogimage_show',$page_id));
}
	
	

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    /* public function create()
    {
        //
    } */
public function Manageblogimage(Request $request,$page_id)
	{
	 //
		
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
 public function store(Request $request)
{
    
	// Validate the incoming request
     $request->validate([
        'page_id' => 'required|integer', // Ensure page_id is included and valid
        'title_1' => 'required|string|max:255',
        'title_2' => 'required|string|max:255',
        'title_3' => 'required|string|max:255',
        'airline_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',
	]);
     //$page_id = request()->route('page_id');
    try {
        // Collect form data
        $data = $request->all();
        //$page_id = $data['page_id']; // Get the page_id from the request
          
		$page_id = intval($request->input('page_id'));
		$manageblogImage = new Manageblogimage();

        // Handle the image upload
        if ($request->hasFile('airline_image')) {
            $file = $request->file('airline_image');
            $extension = $file->getClientOriginalExtension();
            $imageName = time() . '.' . $extension;
            $file->move(public_path('images'), $imageName);
            $manageblogImage->airline_image = $imageName;
        }

        // Save data to the database
        $manageblogImage->page_id = $page_id;
        $manageblogImage->title_1 = $data['title_1'];
        $manageblogImage->title_2 = $data['title_2'];
        $manageblogImage->title_3 = $data['title_3'];
        $manageblogImage->status = $data['status'] ?? 'active'; // Default to 'active' if not provided
        $manageblogImage->created_at = now(); // Use Laravel's helper for current time
        $manageblogImage->delete_status = 'False';
        $manageblogImage->save();

        // Fetch the ID of the newly created record
        $page_id = $manageblogImage->page_id;

        // Success message and redirect
        $request->session()->flash('alert-success', "Record added successfully with ID: $page_id");
        return redirect('manage_blog_image/'.$page_id);

    } catch (\Exception $e) {
        // Error handling
        $request->session()->flash('alert-danger', 'Registration Failed. Error: ' . $e->getMessage());
        return redirect()->back()->withInput();
    }
}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($page_id)
    {
      //dd($page_id); 
	 $Manageblogimage_show=Manageblogimage::orderBy('id','DESC')->where('delete_status', 'False')->where('page_id', $page_id)->get()->toarray();
    $count = Manageblogimage::where('status', 'Enabled')->where('delete_status', 'False')->where('page_id', $page_id)->count();
    //dd($Manageblogimage_show);
    return view('backend.manage_blog_image',compact('count','Manageblogimage_show','page_id'));
   
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
	  $Manageblogimage_edit=Manageblogimage::findOrFail($id); ;
      $page_id = $Manageblogimage_edit->page_id;
	  
	  $Manageblogimage_show = Manageblogimage::where('page_id', $page_id)->orderBy('id', 'DESC')->where('delete_status', 'False')->get();
		
	  $count = Manageblogimage::where('status', 'Enabled')->where('delete_status', 'False')->where('page_id', $page_id)->count();
	  
	    session()->flash('page_id', $page_id);
		return view('backend.manage_blog_image',compact('count','Manageblogimage_show','Manageblogimage_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
{
    // Validate the request data
    $validatedData = $request->validate([
        'page_id' => 'required',
        'title_1' => 'required',
        'title_2' => 'required',
        'title_3' => 'required',
        'airline_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',
    ]);

    // Get all validated data
    $validatedData = $request->all();
    
    if (!empty($validatedData)) {
        try {
            // Find the record by ID or fail
            $Manageblogimage = Manageblogimage::findOrFail($id);

            // Check if a new image file was uploaded
            if ($request->hasFile('airline_image')) {
                // Process the uploaded file
                $file = $request->file('airline_image');
                $extension = $file->getClientOriginalExtension();
                $imageName = time() . '.' . $extension;

                // Move the file to the public images directory
                $file->move(public_path('images'), $imageName);

                // Update the airline_image field
                $Manageblogimage->airline_image = $imageName;
            }

            // Update other fields
            $Manageblogimage->page_id = $validatedData['page_id'];
            $Manageblogimage->title_1 = $validatedData['title_1'];
            $Manageblogimage->title_2 = $validatedData['title_2'];
            $Manageblogimage->title_3 = $validatedData['title_3'];
            $Manageblogimage->status = $request->input('status',$Manageblogimage->status); // Use the existing value if not provided
            $Manageblogimage->delete_status = 'False'; // Set delete_status explicitly
            $Manageblogimage->updated_at = now(); // Use Laravel's helper for the current timestamp

            // Save the changes
            $Manageblogimage->save();

            // Flash success message with ID
           $page_id = $Manageblogimage->page_id;
            $request->session()->flash('alert-success', "User updated successfully with page id: $page_id");

            // Redirect to the index route with the page_id
            return redirect('manage_blog_image/'.$page_id);

        } catch (\Exception $e) {
            // Flash error message
            $request->session()->flash('alert-danger', 'Registration Failed');
             return redirect('manage_blog_image/'.$page_id);
        }
    } else {
        // Redirect to index route with the page_id if data is empty
        return redirect('manage_blog_image/'.$page_id);
    }
}


         /* public function status($slug)
         {   
        $id = $this->getValue($slug, $id=true);
        if($id){
            $change = $this->user->find($id);
            $active = $change->status;
            if ($id != null) 
            {
                if($active==1)
                {
                    $update_arr = array('status' => 0);
                     $this->user->where('id', $id)->update($update_arr);
                }
                else
                { 
                    $update_arr = array('status' => 1);
                    $this->user->where('id', $id)
                        ->update($update_arr);
                }
                 Session::flash('success', 'User status changed successfully.');             
            }else{
                Session::flash('warning', 'You have something went wrong');
            }
             return back();
        }else{
            Session::flash('warning', 'You have something went wrong');
        }
         return back();
    } */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     
	
	public function destroy(Request $request, $id)
   {
    try {
        // Find the record by ID
        $Manageblogimage = Manageblogimage::find($id);

        // Check if record exists
        if (!$Manageblogimage) {
            return redirect()->back()->with('alert-danger', 'Record not found.');
        }

        // Update the delete_status column instead of deleting the record
        $Manageblogimage->delete_status = 'True';
        
        if ($Manageblogimage->save()) {
            $request->session()->flash('alert-success', 'User delete sucessfully.');
        } else {
            $request->session()->flash('alert-danger', 'Failed to update record.');
        }
    } catch (\Exception $e) {
        $request->session()->flash('alert-danger', 'Error: ' . $e->getMessage());
    }

    return redirect()->back();
  }
}
