<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Manageflightsdeal;
class ManageflightsdealController extends Controller
{
    
    public function index()
    {
	   
        $Manageflightsdeal_show=Manageflightsdeal::orderBy('id','DESC')->where('delete_status', 1)->get()->toarray();
	    $count = Manageflightsdeal::where('status','=','Enabled')->where('delete_status', 1)->count();
		
		return view('backend.manage_flights_deal',compact('count','Manageflightsdeal_show'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    /* public function create()
    {
        //
    } */
public function Manageflightsdeal(Request $request)
	{
	 //
		
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
	   request()->validate([
		'origin'=> 'required',
		'Origin_code'=> 'required',
		'destination'=>  'required',
		'destination_code'=>  'required',
		'from_date'=>  'required',
		'to_date'=>  'required',
		'price_in_usd'=>  'required',
		'result_url'=>  'required',
		'airline_image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',]);
		
		   $data=$request->all();
		   if(!empty($data)){
		   try{
			
			$Manageflightsdeal=new Manageflightsdeal();
			if($request->hasfile('airline_image'))
            {
            $file = $request->file('airline_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Manageflightsdeal->airline_image = $imageName;
            }
			$Manageflightsdeal->origin=$data['origin'];
			$Manageflightsdeal->Origin_code=$data['Origin_code'];
			$Manageflightsdeal->destination=$data['destination'];
			$Manageflightsdeal->destination_code=$data['destination_code'];
		    $Manageflightsdeal->from_date = date('Y-m-d', strtotime($request->input('from_date')));
			$Manageflightsdeal->to_date = date('Y-m-d', strtotime($request->input('to_date')));
			$Manageflightsdeal->price_in_usd=$data['price_in_usd'];
			$Manageflightsdeal->result_url=$data['result_url'];
			$Manageflightsdeal->status=$data['status'];
			$Manageflightsdeal->created_at = date("Y-m-d H:i:s");
			$Manageflightsdeal->delete_status = 1;
			
			 $Manageflightsdeal->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
			
		}catch (\Exception $e){
			 echo "<pre>";
		print_r($data);
		die; 
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect("admin/manage_flights_deal");
		}
		 $request->session()->flash('alert-success', 'User added sucessfully'); 
		return redirect("admin/manage_flights_deal");
		  }
      else{
			 
	       return redirect()-back();  
		
          }	  
		/* echo "<pre>";
		print_r($data);
		die; */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $Manageflightsdeal_show=Manageflightsdeal::orderBy('id','DESC')->where('delete_status', 1)->get()->toarray();
        $manage_flights_deal_edit=Manageflightsdeal::orderBy('id','DESC')->find($id)->toarray();
		
		$count = Manageflightsdeal::where('status','=','Enabled')->where('delete_status', 1)->count();
		
		return view('backend.manage_flights_deal',compact('count','Manageflightsdeal_show','manage_flights_deal_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    	///print_r($id);exit();
    		$data=$request->all();
    		$Manageflightsdeal=Manageflightsdeal::findOrFail($id);
			/* print_r($Manageflightsdeal->toArray());//exit();
			echo "<hr>";
			print_r($data);exit(); */

        request()->validate([
		'origin'=> 'required',
		'Origin_code'=> 'required',
		'destination'=>  'required',
		'destination_code'=>  'required',
		'from_date'=>  'required',
		'to_date'=>  'required',
		'price_in_usd'=>  'required',
		'result_url'=>  'required',
		'airline_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',]);
		  
		  $data=$request->all();
		   if(!empty($data)){
		   try{
			
			$Manageflightsdeal=Manageflightsdeal::findOrFail($id);
			if($request->hasfile('airline_image'))
            {
            $file = $request->file('airline_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Manageflightsdeal->airline_image = $imageName;
            }
			$Manageflightsdeal->origin=$data['origin'];
			$Manageflightsdeal->Origin_code=$data['Origin_code'];
			$Manageflightsdeal->destination=$data['destination'];
			$Manageflightsdeal->destination_code=$data['destination_code'];
		    $Manageflightsdeal->from_date = date('Y-m-d', strtotime($request->input('from_date')));
			$Manageflightsdeal->to_date = date('Y-m-d', strtotime($request->input('to_date')));
			$Manageflightsdeal->price_in_usd=$data['price_in_usd'];
			$Manageflightsdeal->result_url=$data['result_url'];
			$Manageflightsdeal->status=$data['status'];
			$Manageflightsdeal->updated_at = date("Y-m-d H:i:s");
			$Manageflightsdeal->delete_status = 1;
			
			 $Manageflightsdeal->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
		}catch (\Exception $e){
			
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect()->Route('manage_flights_deal.edit',$id);
		}
		 $request->session()->flash('alert-success', 'User Updates sucessfully'); 
		return redirect()->Route('manage_flights_deal.index');
		  }
      else{
			 
	       return redirect()->Route('manage_flights_deal.index');  
		
          }
    }


         /* public function status($slug)
         {   
        $id = $this->getValue($slug, $id=true);
        if($id){
            $change = $this->user->find($id);
            $active = $change->status;
            if ($id != null) 
            {
                if($active==1)
                {
                    $update_arr = array('status' => 0);
                     $this->user->where('id', $id)->update($update_arr);
                }
                else
                { 
                    $update_arr = array('status' => 1);
                    $this->user->where('id', $id)
                        ->update($update_arr);
                }
                 Session::flash('success', 'User status changed successfully.');             
            }else{
                Session::flash('warning', 'You have something went wrong');
            }
             return back();
        }else{
            Session::flash('warning', 'You have something went wrong');
        }
         return back();
    } */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
   {
    try {
        // Find the record by ID
        $Manageflightsdeal = Manageflightsdeal::find($id);

        // Check if record exists
        if (!$Manageflightsdeal) {
            return redirect()->back()->with('alert-danger', 'Record not found.');
        }

        // Update the delete_status column instead of deleting the record
        $Manageflightsdeal->delete_status = 0;
        
        if ($Manageflightsdeal->save()) {
            $request->session()->flash('alert-success', 'User delete sucessfully.');
        } else {
            $request->session()->flash('alert-danger', 'Failed to update record.');
        }
    } catch (\Exception $e) {
        $request->session()->flash('alert-danger', 'Error: ' . $e->getMessage());
    }

    return redirect()->back();
  }

	
	
}
