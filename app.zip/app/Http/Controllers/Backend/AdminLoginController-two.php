<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use Socialite;
use App\Models\User;
use Auth,Session,URL;
use Illuminate\Support\Facades\Hash;

class AdminLoginController  extends Controller
{
    public function login()
    {
        return view('Lara_admin.login');
    }
	
    public function AdminLogin(Request $request)
    {
		 //dd(request()->toarray());
         request()->validate([
            'email' => 'required',
            'password' => 'required',
        ]);
        try
        {
		$email=$request->email;
        $password=$request->password;

        $credentials = $request->only('email', 'password');

        // Attempt to log in using the 'admin' guard
        if (Auth::guard('admin')->attempt($credentials)) {
            return redirect()->route('dashboard');
        } else {
            // Flash error message for invalid login credentials
           $request->session()->flash('alert-danger','your username and password are wrong.');
            return redirect()->route('login');
        }
    } catch (\Exception $e){
			$request->session()->flash('alert-danger','login Failed');
			return redirect()->back();
		}
	
}
public function dashboard(Request $request)
    {
        return view('Lara_admin.dashboard');
    }
protected function guard()
    {
        return Auth::guard(); // Specify your guard here
    }
}
   