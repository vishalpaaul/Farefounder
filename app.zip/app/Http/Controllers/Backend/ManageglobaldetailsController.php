<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Manageglobaldetails;
class ManageglobaldetailsController extends Controller
{
    
    public function index()
    {
		
		//$Manageglobaldetails_show = t_flight_deal::orderBy('id','ASC')->get();
        $Manageglobaldetails_show=Manageglobaldetails::orderBy('id','DESC')->get()->toarray();
		///$Manageglobaldetails_show=t_flight_deal::get()->toarray();
		$count = Manageglobaldetails::where('status','=','Enabled')->count();
		return view('backend.manage_global_details',compact('count','Manageglobaldetails_show'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    /* public function create()
    {
        //
    } */
public function Manageglobaldetails(Request $request)
	{
	 //
		
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
	   request()->validate([
		'contact_address_line1'=> 'required',
		'contact_address_line2'=> 'required',
		'toll_free_number'=>  'required',
		'toll_free_number2'=>  'required',
		'email'=>  'required',
		'promo_code'=>  'required',
		'airline_image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',]);
		
		
	      
		   $data=$request->all();
		   if(!empty($data)){
		   try{
			
			$Manageglobaldetails=new Manageglobaldetails();
			if($request->hasfile('airline_image'))
            {
            $file = $request->file('airline_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Manageglobaldetails->airline_image = $imageName;
            }
			$Manageglobaldetails->contact_address_line1=$data['contact_address_line1'];
			$Manageglobaldetails->contact_address_line2=$data['contact_address_line2'];
			$Manageglobaldetails->toll_free_number=$data['toll_free_number'];
			$Manageglobaldetails->toll_free_number2=$data['toll_free_number2'];
		    $Manageglobaldetails->email=$data['email'];
			$Manageglobaldetails->promo_code=$data['promo_code'];
			$Manageglobaldetails->status=$data['status'];
			$Manageglobaldetails->created_at = date("Y-m-d H:i:s");
			
			$Manageglobaldetails->delete_status = 'False';
			
			$Manageglobaldetails->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
			
		}catch (\Exception $e){
			 echo "<pre>";
		print_r($data);
		die; 
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect("admin/manage_global_details");
		}
		 $request->session()->flash('alert-success', 'User added sucessfully'); 
		return redirect("admin/manage_global_details");
		  }
      else{
			 
	       return redirect()-back();  
		
          }	  
		/* echo "<pre>";
		print_r($data);
		die; */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $Manageglobaldetails_show=Manageglobaldetails::orderBy('id','DESC')->get()->toarray();
        $manage_global_details_edit=Manageglobaldetails::orderBy('id','DESC')->find($id)->toarray();
		$count = Manageglobaldetails::where('status','=','Enabled')->count();
		return view('backend.manage_global_details',compact('count','Manageglobaldetails_show','manage_global_details_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    	///print_r($id);exit();
    		$data=$request->all();
    		$Manageglobaldetails=Manageglobaldetails::findOrFail($id);
			/* print_r($Manageglobaldetails->toArray());//exit();
			echo "<hr>";
			print_r($data);exit(); */

        request()->validate([
		'contact_address_line1'=> 'required',
		'contact_address_line2'=> 'required',
		'toll_free_number'=>  'required',
		'toll_free_number2'=>  'required',
		'email'=>  'required',
		'promo_code'=>  'required',
		'airline_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',]);
		
		
		   $data=$request->all();
		   if(!empty($data)){
		   try{
			
			$Manageglobaldetails=Manageglobaldetails::findOrFail($id);
			if($request->hasfile('airline_image'))
            {
            
            $file = $request->file('airline_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Manageglobaldetails->airline_image = $imageName;
            }
			$Manageglobaldetails->contact_address_line1=$data['contact_address_line1'];
			$Manageglobaldetails->contact_address_line2=$data['contact_address_line2'];
			$Manageglobaldetails->toll_free_number=$data['toll_free_number'];
			$Manageglobaldetails->toll_free_number2=$data['toll_free_number2'];
		   
			$Manageglobaldetails->email=$data['email'];
			$Manageglobaldetails->promo_code=$data['promo_code'];
			$Manageglobaldetails->status=$data['status'];
			$Manageglobaldetails->updated_at = date("Y-m-d H:i:s");
			
			$Manageglobaldetails->delete_status = 'False';
			
			 $Manageglobaldetails->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
		}catch (\Exception $e){
			
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect()->Route('manage_global_details.edit',$id);
		}
		 $request->session()->flash('alert-success', 'User Updates sucessfully'); 
		return redirect()->Route('manage_global_details.index');
		  }
      else{
			 
	      return redirect()->Route('manage_global_details.index');  
		
          }
    }


         /* public function status($slug)
         {   
        $id = $this->getValue($slug, $id=true);
        if($id){
            $change = $this->user->find($id);
            $active = $change->status;
            if ($id != null) 
            {
                if($active==1)
                {
                    $update_arr = array('status' => 0);
                     $this->user->where('id', $id)->update($update_arr);
                }
                else
                { 
                    $update_arr = array('status' => 1);
                    $this->user->where('id', $id)
                        ->update($update_arr);
                }
                 Session::flash('success', 'User status changed successfully.');             
            }else{
                Session::flash('warning', 'You have something went wrong');
            }
             return back();
        }else{
            Session::flash('warning', 'You have something went wrong');
        }
         return back();
    } */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function destroy(Request $request,$id)
	{
	try{
	  Manageglobaldetails::where('id',$id)->delete();
      $request->session()->flash('alert-success', 'User delete sucessfully'); 	  
	}	catch (\Exception $e){
	$request->session()->flash('alert-danger','Failed');	
	}
	return redirect()->back();	
	} 
	
}
