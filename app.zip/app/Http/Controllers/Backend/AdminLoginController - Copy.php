<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;



class AdminLoginController extends Controller
{
    public function login()
    {
        return view('backend.login');
    }

    public function AdminLogin(Request $request)
    {
        // Validate request
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        try {
            $credentials = $request->only('email', 'password');

            // Attempt login using the 'admin' guard
            if (Auth::guard('admin')->attempt($credentials)) {
                return redirect()->route('admin.dashboard');
            } else {
                // Flash error message for invalid login credentials
                return redirect()->route('admin.login')->with('alert-danger', 'Your username and password are incorrect.');
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('alert-danger', 'Login Failed');
        }
    }

    public function dashboard()
    {
        return view('backend.dashboard');
    }

    public function logout(Request $request)
    {
        Auth::guard('admin')->logout(); // Log out admin
        Session::flush(); // Destroy session
        return redirect()->route('login')->with('alert-success', 'You have been logged out.');
    }

    protected function guard()
    {
        return Auth::guard('admin');
    }
}