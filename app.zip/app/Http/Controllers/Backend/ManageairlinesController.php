<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Manageairlines;
class ManageairlinesController extends Controller
{
    
    public function index()
    {
		
		//$Manageairlines_show = t_flight_deal::orderBy('page_id','ASC')->get();
        $Manageairlines_show=Manageairlines::orderBy('page_id','DESC')->where('delete_status', 1)->where('page_type_id','=',4)->get()->toarray();
		///$Manageairlines_show=t_flight_deal::get()->toarray();
		$count = Manageairlines::where('status','=','Enabled')->where('delete_status', 1)->where('page_type_id','=',4)->count();
		
		return view('backend.manage_airlines_pages',compact('count','Manageairlines_show'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    /* public function create()
    {
        //
    } */
public function Manageairlines(Request $request)
	{
	 //
		
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       //dd(request()->toarray());
	   request()->validate([
		'short_code'=> 'required',
		'page_type_id'=>  'required',
		'page_name'=>  'required',
		'page_title'=>  'required',
		'page_display_name'=>  'required',
		'page_description'=>  'required',
		'page_keyword'=>  'required',
		'author'=>  'required',
		'robots'=>  'required',
		'og_type'=>  'required',
		'og_title'=>  'required',
		'og_description'=>  'required',
		'og_url'=>  'required',
		'paratitle'=>  'required',
		'paracontent'=>  'required',
		'og_image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',]);
		
	      
		  $data=$request->all();
		   if(!empty($data)){
		try{
			
			$Manageairlines=new Manageairlines();
			if($request->hasfile('og_image'))
            {
            $file = $request->file('og_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Manageairlines->og_image = $imageName;
            }
			$Manageairlines->short_code=$data['short_code'];
			$Manageairlines->page_type_id=$data['page_type_id'];
			
			$Manageairlines->page_name=$data['page_name'];
			$Manageairlines->page_title=$data['page_title'];
			$Manageairlines->page_display_name=$data['page_display_name'];
			$Manageairlines->page_description=$data['page_description'];
			$Manageairlines->page_keyword=$data['page_keyword'];
			$Manageairlines->author=$data['author'];
			$Manageairlines->robots=$data['robots'];
			$Manageairlines->og_type=$data['og_type'];
			$Manageairlines->og_title=$data['og_title'];
			$Manageairlines->paratitle=$data['paratitle'];
			$Manageairlines->paracontent=$data['paracontent'];
			$Manageairlines->og_description=$data['og_description'];
			$Manageairlines->og_url=$data['og_url'];
			$Manageairlines->status=$data['status'];
			$Manageairlines->created_at = date("Y-m-d H:i:s");
			
			$Manageairlines->delete_status = 1;
			
			 $Manageairlines->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
			
		}catch (\Exception $e){
		//echo "<pre>";
		//print_r($data);
		//die; 
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect("admin/manage_airlines_pages");
		}
		 $request->session()->flash('alert-success', 'User added sucessfully'); 
		return redirect("admin/manage_airlines_pages");
		  }
      else{
			 
	       return redirect()-back();  
		
          }	  
		/* echo "<pre>";
		print_r($data);
		die; */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($page_id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($page_id)
    {
        $Manageairlines_show=Manageairlines::orderBy('page_id','DESC')->where('delete_status', 1)->where('page_type_id','=',4)->get()->toarray();
        $manage_airlines_pages_edit=Manageairlines::orderBy('page_id','DESC')->find($page_id)->toarray();
		$count = Manageairlines::where('status','=','Enabled')->where('delete_status', 1)->where('page_type_id','=',4)->count();
	
		return view('backend.manage_airlines_pages',compact('count','Manageairlines_show','manage_airlines_pages_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $page_id)
    {
    	///print_r($page_id);exit();
    		$data=$request->all();
    		$Manageairlines=Manageairlines::findOrFail($page_id);
			/* print_r($Manageairlines->toArray());//exit();
			echo "<hr>";
			print_r($data);exit(); */

        request()->validate([
		'short_code'=> 'required',
		'page_type_id'=>  'required',
		
		'page_name'=>  'required',
		'page_title'=>  'required',
		'page_display_name'=>  'required',
		'page_description'=>  'required',
		'page_keyword'=>  'required',
		'author'=>  'required',
		'robots'=>  'required',
		'og_type'=>  'required',
		'og_title'=>  'required',
		'og_description'=>  'required',
		'og_url'=>  'required',
		'paratitle'=>  'required',
		'paracontent'=>  'required',
		'og_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',]);
		
	      
		   $data=$request->all();
		   if(!empty($data)){
		   try{
			
			$Manageairlines=Manageairlines::findOrFail($page_id);
			if($request->hasfile('og_image'))
            {
            $file = $request->file('og_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Manageairlines->og_image = $imageName;
            }
			$Manageairlines->short_code=$data['short_code'];
			$Manageairlines->page_type_id=$data['page_type_id'];
			
			$Manageairlines->page_name=$data['page_name'];
			$Manageairlines->page_title=$data['page_title'];
			$Manageairlines->page_display_name=$data['page_display_name'];
			$Manageairlines->page_description=$data['page_description'];
			$Manageairlines->page_keyword=$data['page_keyword'];
			$Manageairlines->author=$data['author'];
			$Manageairlines->robots=$data['robots'];
			$Manageairlines->og_type=$data['og_type'];
			$Manageairlines->og_title=$data['og_title'];
			$Manageairlines->paratitle=$data['paratitle'];
			$Manageairlines->paracontent=$data['paracontent'];
			$Manageairlines->og_description=$data['og_description'];
			$Manageairlines->og_url=$data['og_url'];
			$Manageairlines->status=$data['status'];
			$Manageairlines->created_at = date("Y-m-d H:i:s");
			
			$Manageairlines->delete_status = 1;
			
			 $Manageairlines->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
		}catch (\Exception $e){
			
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect()->Route('manage_airlines_pages.edit',$page_id);
		}
		 $request->session()->flash('alert-success', 'User Updates sucessfully'); 
		return redirect()->Route('manage_airlines_pages.index');
		  }
      else{
			 
	       return redirect()->Route('manage_airlines_pages.index');  
		
          }
    }


         /* public function status($slug)
         {   
        $id = $this->getValue($slug, $id=true);
        if($id){
            $change = $this->user->find($id);
            $active = $change->status;
            if ($id != null) 
            {
                if($active==1)
                {
                    $update_arr = array('status' => 0);
                     $this->user->where('id', $id)->update($update_arr);
                }
                else
                { 
                    $update_arr = array('status' => 1);
                    $this->user->where('id', $id)
                        ->update($update_arr);
                }
                 Session::flash('success', 'User status changed successfully.');             
            }else{
                Session::flash('warning', 'You have something went wrong');
            }
             return back();
        }else{
            Session::flash('warning', 'You have something went wrong');
        }
         return back();
    } */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    
    public function destroy(Request $request, $page_id)
    {
    try {
        // Find the record by page id
        $Manageairlines = Manageairlines::find($page_id);

        // Check if record exists
        if (!$Manageairlines) {
            return redirect()->back()->with('alert-danger', 'Record not found.');
        }

        // Update the delete_status column instead of deleting the record
        $Manageairlines->delete_status = 0;
        
        if ($Manageairlines->save()) {
            $request->session()->flash('alert-success', 'User delete sucessfully.');
        } else {
            $request->session()->flash('alert-danger', 'Failed to update record.');
        }
    } catch (\Exception $e) {
        $request->session()->flash('alert-danger', 'Error: ' . $e->getMessage());
    }

    return redirect()->back();
  }
	
	
}
