<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\LoginHistory; 
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;

class AdminLoginController extends Controller
{
    public function login()
    {
        return view('backend.login');
    }

  public function AdminLogin(Request $request)
{
    $request->validate([
        'email' => 'required|email',
        'password' => 'required',
    ]);

    try {
        $credentials = $request->only('email', 'password');

        // Debugging
        if (!\App\Models\User::where('email', $request->email)->exists()) {
            return redirect()->back()->with('alert-danger', 'Admin user does not exist.');
        }

        // Attempt login using the 'admin' guard
        if (Auth::guard('admin')->attempt($credentials)) {
            $admin = Auth::guard('admin')->user();

            LoginHistory::create([
                'admin_id'   => $admin->id,
                'email'      => $admin->email,
                'ip_address' => $request->ip(),
                'user_agent' => $request->header('User-Agent'),
                'login_time' => now(),
            ]);

            return redirect()->route('admin.dashboard');
        } else {
            return redirect()->back()->with('alert-danger', 'Invalid email or password.');
        }
    } catch (\Exception $e) {
        return redirect()->back()->with('alert-danger', 'Error: ' . $e->getMessage());
    }
}

    public function dashboard()
    {
        return view('backend.dashboard');
    }

    public function logout(Request $request)
    {
        Auth::guard('admin')->logout(); // Log out admin
       $request->session()->invalidate(); // Invalidate session
        $request->session()->regenerateToken(); // Regenerate CSRF token
        return redirect()->route('login')->with('alert-success', 'You have been logged out.');
    }

    protected function guard()
    {
        return Auth::guard('admin');
    }
}