<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Manageinformation;
class ManageinformationController extends Controller
{
    
    public function index()
    {
	
        $Manageinformation_show=Manageinformation::orderBy('id','DESC')->where('delete_status', 1)->get()->toarray();
		
		$count = Manageinformation::where('status','=','Enabled')->where('delete_status', 1)->count();
		return view('backend.manage_information',compact('count','Manageinformation_show'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    /* public function create()
    {
        //
    } */
public function Manageinformation(Request $request)
	{
	 //
		
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
	   request()->validate([
		'pages_id'=> 'required',
		'title_name'=> 'required',
		'sub_title'=>  'required',
		'discription'=>  'required',
		'airline_image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',]);
		
	      
		   $data=$request->all();
		   if(!empty($data)){
		   try{
			
			$Manageinformation=new Manageinformation();
			if($request->hasfile('airline_image'))
            {
            $file = $request->file('airline_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Manageinformation->airline_image = $imageName;
            }
			$Manageinformation->pages_id=$data['pages_id'];
			$Manageinformation->title_name=$data['title_name'];
			$Manageinformation->sub_title=$data['sub_title'];
			$Manageinformation->discription=$data['discription'];
		    $Manageinformation->status=$data['status'];
			$Manageinformation->created_at = date("Y-m-d H:i:s");
			
			$Manageinformation->delete_status = 1;
			
			 $Manageinformation->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
			
		}catch (\Exception $e){
			 echo "<pre>";
		print_r($data);
		die; 
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect("admin/manage_information");
		}
		 $request->session()->flash('alert-success', 'User added sucessfully'); 
		return redirect("admin/manage_information");
		  }
      else{
			 
	       return redirect()-back();  
		
          }	  
		/* echo "<pre>";
		print_r($data);
		die; */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $Manageinformation_show=Manageinformation::orderBy('id','DESC')->where('delete_status', 1)->get()->toarray();
        $manage_information_edit=Manageinformation::orderBy('id','DESC')->find($id)->toarray();
		$count = Manageinformation::where('status','=','Enabled')->where('delete_status', 1)->count();
		return view('backend.manage_information',compact('count','Manageinformation_show','manage_information_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    	///print_r($id);exit();
    		$data=$request->all();
    		$Manageinformation=Manageinformation::findOrFail($id);
			/* print_r($Manageinformation->toArray());//exit();
			echo "<hr>";
			print_r($data);exit(); */

        request()->validate([
		'pages_id'=> 'required',
		'title_name'=> 'required',
		'sub_title'=>  'required',
		'discription'=>  'required',
		'airline_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',]);
		
	      
		   $data=$request->all();
		   if(!empty($data)){
		   try{
			
			$Manageinformation=Manageinformation::findOrFail($id);
			//dd(request()->toarray());
			if($request->hasfile('airline_image'))
            {
            
            $file = $request->file('airline_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Manageinformation->airline_image = $imageName;
            }
			$Manageinformation->pages_id=$data['pages_id'];
			$Manageinformation->title_name=$data['title_name'];
			$Manageinformation->sub_title=$data['sub_title'];
			$Manageinformation->discription=$data['discription'];
			$Manageinformation->status=$data['status'];
			$Manageinformation->updated_at = date("Y-m-d H:i:s");
			
			$Manageinformation->delete_status = 1;
			
			 $Manageinformation->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
		}catch (\Exception $e){
			
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect()->Route('manage_information.edit',$id);
		}
		 $request->session()->flash('alert-success', 'User Updates sucessfully'); 
		return redirect()->Route('manage_information.index');
		  }
      else{
			 
	       return redirect()->Route('manage_information.index');  
		
          }
    }


         /* public function status($slug)
         {   
        $id = $this->getValue($slug, $id=true);
        if($id){
            $change = $this->user->find($id);
            $active = $change->status;
            if ($id != null) 
            {
                if($active==1)
                {
                    $update_arr = array('status' => 0);
                     $this->user->where('id', $id)->update($update_arr);
                }
                else
                { 
                    $update_arr = array('status' => 1);
                    $this->user->where('id', $id)
                        ->update($update_arr);
                }
                 Session::flash('success', 'User status changed successfully.');             
            }else{
                Session::flash('warning', 'You have something went wrong');
            }
             return back();
        }else{
            Session::flash('warning', 'You have something went wrong');
        }
         return back();
    } */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    
    
	public function destroy(Request $request, $id)
   {
    try {
        // Find the record by ID
        $Manageinformation = Manageinformation::find($id);

        // Check if record exists
        if (!$Manageinformation) {
            return redirect()->back()->with('alert-danger', 'Record not found.');
        }

        // Update the delete_status column instead of deleting the record
        $Manageinformation->delete_status = 0;
        
        if ($Manageinformation->save()) {
            $request->session()->flash('alert-success', 'User delete sucessfully.');
        } else {
            $request->session()->flash('alert-danger', 'Failed to update record.');
        }
    } catch (\Exception $e) {
        $request->session()->flash('alert-danger', 'Error: ' . $e->getMessage());
    }

    return redirect()->back();
}

	
	
}
