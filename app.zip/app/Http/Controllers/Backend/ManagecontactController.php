<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Managecontactenquiries;
class ManagecontactController extends Controller
{
    
    public function index()
    {
	
      $Managecontactenquiries_show=Managecontactenquiries::orderBy('id','DESC')->where('delete_status', 'False')->get()->toarray();
	  $count = Managecontactenquiries::where('status','=','Enabled')->where('delete_status', 'False')->count();
	 return view('backend.manage_contact_enquiries',compact('count','Managecontactenquiries_show'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    /* public function create()
    {
        //
    } */
public function Managecontactenquiries(Request $request)
	{
	 //
		
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
	   request()->validate([
		'name'=> 'required',
		'phone'=> 'required',
		'email'=>  'required',
		'message'=>  'required',]);
		
	      
		  $data=$request->all();
		   if(!empty($data)){
		try{
			
			$Managecontactenquiries=new Managecontactenquiries();
			$Managecontactenquiries->name=$data['name'];
			$Managecontactenquiries->phone=$data['phone'];
			$Managecontactenquiries->email=$data['email'];
			$Managecontactenquiries->message=$data['message'];
		    $Managecontactenquiries->status=$data['status'];
			$Managecontactenquiries->created_at = date("Y-m-d H:i:s");
			
			$Managecontactenquiries->delete_status = 'False';
			
			$Managecontactenquiries->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
			
		}catch (\Exception $e){
			 echo "<pre>";
		print_r($data);
		die; 
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect("admin/manage_contact_enquiries");
		}
		 $request->session()->flash('alert-success', 'User added sucessfully'); 
		return redirect("admin/manage_contact_enquiries");
		  }
      else{
			 
	       return redirect()-back();  
		
          }	  
		/* echo "<pre>";
		print_r($data);
		die; */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $Managecontactenquiries_show=Managecontactenquiries::orderBy('id','DESC')->get()->toarray();
        $manage_contact_enquiries_edit=Managecontactenquiries::orderBy('id','DESC')->find($id)->toarray();
		$count = Managecontactenquiries::where('status','=','Enabled')->count();
		return view('backend.manage_contact_enquiries',compact('count','Managecontactenquiries_show','manage_contact_enquiries_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    	///print_r($id);exit();
    		$data=$request->all();
    		$Managecontactenquiries=Managecontactenquiries::findOrFail($id);
			/* print_r($Managecontactenquiries->toArray());//exit();
			echo "<hr>";
			print_r($data);exit(); */

        request()->validate([
		'name'=> 'required',
		'phone'=> 'required',
		'email'=>  'required',
		'message'=>  'required',]);
		
		
	      
		  $data=$request->all();
		   if(!empty($data)){
		try{
			
			$Managecontactenquiries=Managecontactenquiries::findOrFail($id);
			
			$Managecontactenquiries=new Managecontactenquiries();
			$Managecontactenquiries->name=$data['name'];
			$Managecontactenquiries->phone=$data['phone'];
			$Managecontactenquiries->email=$data['email'];
			$Managecontactenquiries->message=$data['message'];
			$Managecontactenquiries->status=$data['status'];
			$Managecontactenquiries->updated_at = date("Y-m-d H:i:s");
			$Managecontactenquiries->delete_status = 'False';
			
			 $Managecontactenquiries->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
		}catch (\Exception $e){
			
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect()->Route('manage_contact_enquiries.edit',$id);
		}
		 $request->session()->flash('alert-success', 'User Updates sucessfully'); 
		return redirect()->Route('manage_contact_enquiries.index');
		  }
      else{
			 
	       return redirect()->Route('manage_contact_enquiries.index');  
		
          }
    }


         /* public function status($slug)
         {   
        $id = $this->getValue($slug, $id=true);
        if($id){
            $change = $this->user->find($id);
            $active = $change->status;
            if ($id != null) 
            {
                if($active==1)
                {
                    $update_arr = array('status' => 0);
                     $this->user->where('id', $id)->update($update_arr);
                }
                else
                { 
                    $update_arr = array('status' => 1);
                    $this->user->where('id', $id)
                        ->update($update_arr);
                }
                 Session::flash('success', 'User status changed successfully.');             
            }else{
                Session::flash('warning', 'You have something went wrong');
            }
             return back();
        }else{
            Session::flash('warning', 'You have something went wrong');
        }
         return back();
    } */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     
	public function destroy(Request $request, $id)
   {
    try {
        // Find the record by ID
        $Managecontactenquiries = Managecontactenquiries::find($id);

        // Check if record exists
        if (!$Managecontactenquiries) {
            return redirect()->back()->with('alert-danger', 'Record not found.');
        }

        // Update the delete_status column instead of deleting the record
        $Managecontactenquiries->delete_status = 'True';
        
        if ($Managecontactenquiries->save()) {
            $request->session()->flash('alert-success', 'User delete sucessfully.');
        } else {
            $request->session()->flash('alert-danger', 'Failed to update record.');
        }
    } catch (\Exception $e) {
        $request->session()->flash('alert-danger', 'Error: ' . $e->getMessage());
    }

    return redirect()->back();
  }
	
}
