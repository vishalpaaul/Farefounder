<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\HomeSlider;
class HomeSliderController extends Controller
{
    
    public function index()
    {
		
        $HomeSlider_show=HomeSlider::orderBy('id','DESC')->where('delete_status', 1)->get()->toarray();
		///$HomeSlider_show=HomeSlider::get()->toarray();
		$count = HomeSlider::where('status','=','Enabled')->where('delete_status', 1)->count();
		return view('backend.manage_home_slider',compact('count','HomeSlider_show'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    /* public function create()
    {
        //
    } */
public function HomeSlider(Request $request)
	{
	 //
		
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
	   request()->validate([
		'title_1'=> 'required',
		'title_2'=> 'required',
		'title_3'=>  'required',
		'airline_image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
		]);
		
		  $data=$request->all();
		  if(!empty($data)){
		  try{
			
			$HomeSlider=new HomeSlider();
		    if($request->hasfile('airline_image'))
            {
            $file = $request->file('airline_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $HomeSlider->airline_image = $imageName;
            }
			$HomeSlider->title_1=$data['title_1'];
			$HomeSlider->title_2=$data['title_2'];
			$HomeSlider->title_3=$data['title_3'];
			$HomeSlider->status=$data['status'];
			$HomeSlider->created_at = date("Y-m-d H:i:s");
			$HomeSlider->delete_status = 1;
			
			 $HomeSlider->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
		}catch (\Exception $e){
			
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect("admin/manage_home_slider");
		}
		 $request->session()->flash('alert-success', 'User added sucessfully'); 
		return redirect("admin/manage_home_slider");
		  }
      else{
			 
	       return redirect()-back();  
		
          }	  
		/* echo "<pre>";
		print_r($data);
		die; */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $HomeSlider_show=HomeSlider::orderBy('id','DESC')->where('delete_status', 1)->get()->toarray();
        $HomeSlider_edit=HomeSlider::orderBy('id','DESC')->find($id)->toarray();
		
		$count = HomeSlider::where('status','=','Enabled')->where('delete_status', 1)->count();
		return view('backend.manage_home_slider',compact('count','HomeSlider_show','HomeSlider_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    	///print_r($id);exit();
        $data=$request->all();
        $HomeSlider=HomeSlider::findOrFail($id);
			
       //dd($request->all(), $request->file('airline_image'));
        request()->validate([
		'title_1'=> 'required',
		'title_2'=> 'required',
		'title_3'=>  'required',
	    'airline_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',
		]);
		 
		
		   $data=$request->all();
		   if(!empty($data)){
		   try{
			
			$HomeSlider=HomeSlider::findOrFail($id);
			if($request->hasfile('airline_image'))
            {
            
            $file = $request->file('airline_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $HomeSlider->airline_image = $imageName;
            }
			$HomeSlider->title_1=$data['title_1'];
			$HomeSlider->title_2=$data['title_2'];
			$HomeSlider->title_3=$data['title_3'];
			$HomeSlider->status=$data['status'];
			$HomeSlider->updated_at = date("Y-m-d H:i:s");
		
			$HomeSlider->delete_status = 1;
			
			 $HomeSlider->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
		}catch (\Exception $e){
			
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect()->Route('manage_home_slider.edit',$id);
		}
		 $request->session()->flash('alert-success', 'User Updates sucessfully'); 
		return redirect()->Route('manage_home_slider.index');
		  }
      else{
			 
	       return redirect()->Route('manage_home_slider.index');  
		
          }
    }


         /* public function status($slug)
         {   
        $id = $this->getValue($slug, $id=true);
        if($id){
            $change = $this->user->find($id);
            $active = $change->status;
            if ($id != null) 
            {
                if($active==1)
                {
                    $update_arr = array('status' => 0);
                     $this->user->where('id', $id)->update($update_arr);
                }
                else
                { 
                    $update_arr = array('status' => 1);
                    $this->user->where('id', $id)
                        ->update($update_arr);
                }
                 Session::flash('success', 'User status changed successfully.');             
            }else{
                Session::flash('warning', 'You have something went wrong');
            }
             return back();
        }else{
            Session::flash('warning', 'You have something went wrong');
        }
         return back();
    } */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   public function destroy(Request $request, $id)
  {
    try {
        // Find the record by ID
        $HomeSlider = HomeSlider::find($id);

        // Check if record exists
        if (!$HomeSlider) {
            return redirect()->back()->with('alert-danger', 'Record not found.');
        }

        // Update the delete_status column instead of deleting the record
        $HomeSlider->delete_status =  0;
        
        if ($HomeSlider->save()) {
            $request->session()->flash('alert-success', 'User delete sucessfully.');
        } else {
            $request->session()->flash('alert-danger', 'Failed to update record.');
        }
    } catch (\Exception $e) {
        $request->session()->flash('alert-danger', 'Error: ' . $e->getMessage());
    }

    return redirect()->back();
}
	
}
