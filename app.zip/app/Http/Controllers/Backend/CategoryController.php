<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;

class CategoryController extends Controller
{    
    public function index()
    {
        $data_list=Category::all();
        return view('backend.Category',compact('data_list'));
    }
    public function create()
    {
        $data_list=Category::all();
        $Form="Show";
        return view('backend.Category',compact('data_list','Form'));
    }
    public function store(Request $request)
    {
        $rulesVar=[
                    'category_name' => 'required',                   
                    'description' => 'required',
                  ];
        $validatedData = $request->validate($rulesVar);

        $Category=new Category();
        
        $Category->category_name=$request->category_name;
        $Category->description=$request->description;
        
        $Category->save();
        return redirect()->route('Category.index')->with('flash_message','Data Inserted SuccessFully'); 
    }
    public function show($id)
    {
        
    }
    public function edit($id)
    {
        $data_list=Category::all();
        $data_edit=Category::findOrFail($id);
        $Form="Show";
        return view('backend.Category',compact('data_list','data_edit','Form'));
    }
    public function update(Request $request, $id)
    {
        $rulesVar=[
                    'category_name' => 'required',                   
                    'description' => 'required',
                  ];
        $validatedData = $request->validate($rulesVar);

        $Category=Category::findOrFail($id);
        
        $Category->category_name=$request->category_name;
        $Category->description=$request->description;
        
        $Category->save();
        return redirect()->route('Category.index')->with('flash_message','Data Updated SuccessFully'); 
        
    }
    public function destroy($id)
    {
        $Category=Category::findOrFail($id);
        $Category->delete();       
        return redirect()->route('Category.index')->with('flash_message','Data Deleted SuccessFully');
       
    }
}
