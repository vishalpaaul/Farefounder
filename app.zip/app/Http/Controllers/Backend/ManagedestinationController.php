<?php
namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Managedestination;
class ManagedestinationController extends Controller
{
    
    public function index()
    {
	  
		
		$Managedestination_show=Managedestination::orderBy('page_id','DESC')->where('delete_status', 1)->where('page_type_id','=',3)->get()->toarray();
		
		$count = Managedestination::where('status','=','Enabled')->where('delete_status', 1)->where('page_type_id','=',3)->count();
		$Managedestination_show = Managedestination::orderBy('page_id','DESC')->where('delete_status', 1)->where('page_type_id','=',3)->paginate(5); // Show 10 records per page
		return view('backend.manage_destination',compact('count','Managedestination_show'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    /* public function create()
    {
        //
    } */
public function Managedestination(Request $request)
	{
	 //
		
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       //dd(request()->toarray());
	   request()->validate([
		'short_code'=> 'required',
		'page_type_id'=>  'required',
		'destinations_type'=>  'required',
		'page_name'=>  'required',
		'page_title'=>  'required',
		'page_display_name'=>  'required',
		'page_description'=>  'required',
		'page_keyword'=>  'required',
		'author'=>  'required',
		'robots'=>  'required',
		'og_type'=>  'required',
		'og_title'=>  'required',
		'og_description'=>  'required',
		'og_url'=>  'required',
		'paratitle'=>  'required',
		'paracontent'=>  'required',
		'og_image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',]);
		 $existing = \App\Models\Managedestination::where('short_code', $request->short_code)->first();
         if ($existing) {
         return redirect()->back()->withErrors(['short_code' => 'Short code already exists.'])->withInput();
        }
		    $data=$request->all();
		    if(!empty($data)){
		    try{
			
			$Managedestination=new Managedestination();
			if($request->hasfile('og_image'))
            {
            $file = $request->file('og_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Managedestination->og_image = $imageName;
            }
			$Managedestination->short_code=$data['short_code'];
			$Managedestination->page_type_id=$data['page_type_id'];
			$Managedestination->destinations_type=$data['destinations_type'];
			$Managedestination->page_name=$data['page_name'];
			$Managedestination->page_title=$data['page_title'];
			$Managedestination->page_display_name=$data['page_display_name'];
			$Managedestination->page_description=$data['page_description'];
			$Managedestination->page_keyword=$data['page_keyword'];
			$Managedestination->author=$data['author'];
			$Managedestination->robots=$data['robots'];
			$Managedestination->og_type=$data['og_type'];
			$Managedestination->og_title=$data['og_title'];
			$Managedestination->paratitle=$data['paratitle'];
			$Managedestination->paracontent=$data['paracontent'];
			$Managedestination->og_description=$data['og_description'];
			$Managedestination->og_url=$data['og_url'];
			$Managedestination->status=$data['status'];
			$Managedestination->created_at = date("Y-m-d H:i:s");
			
			$Managedestination->delete_status = 1;
			
			 $Managedestination->save(); 
			//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
			
		}catch (\Exception $e){
		//echo "<pre>";
		//print_r($data);
		//die; 
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect("admin/manage_destination");
		}
		 $request->session()->flash('alert-success', 'User added sucessfully'); 
		return redirect("admin/manage_destination");
		  }
      else{
			 
	       return redirect()-back();  
		
          }	  
		/* echo "<pre>";
		print_r($data);
		die; */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($page_id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($page_id)
    {
        $Managedestination_show=Managedestination::orderBy('page_id','DESC')->where('delete_status', 1)->where('page_type_id','=',3)->get()->toarray();
		
		$manage_destination_edit=Managedestination::orderBy('page_id','DESC')->find($page_id)->toarray();
		
		$count = Managedestination::where('status','=','Enabled')->where('delete_status', 1)->where('page_type_id','=',3)->count();
		$Managedestination_show = Managedestination::orderBy('page_id','DESC')->where('delete_status', 1)->where('page_type_id','=',3)->paginate(5); // Show 10 records per page
		return view('backend.manage_destination',compact('count','Managedestination_show','manage_destination_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $page_id)
    {
    	///print_r($page_id);exit();
    		$data=$request->all();
    		$Managedestination=Managedestination::findOrFail($page_id);
			/* print_r($Managedestination->toArray());//exit();
			echo "<hr>";
			print_r($data);exit(); */

        request()->validate([
		'short_code'=> 'required',
		'page_type_id'=>  'required',
		'destinations_type'=>  'required',
		'page_name'=>  'required',
		'page_title'=>  'required',
		'page_display_name'=>  'required',
		'page_description'=>  'required',
		'page_keyword'=>  'required',
		'author'=>  'required',
		'robots'=>  'required',
		'og_type'=>  'required',
		'og_title'=>  'required',
		'og_description'=>  'required',
		'og_url'=>  'required',
		'paratitle'=>  'required',
		'paracontent'=>  'required',
		'og_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',]);
		

		  $data=$request->all();
		  if(!empty($data)){
		try{
			//dd(request()->toarray());
			$Managedestination=Managedestination::findOrFail($page_id);
			if($request->hasfile('og_image'))
            {
            
            $file = $request->file('og_image');
            $extention = $file->getClientOriginalExtension();
            $imageName = time().'.'.$extention;
            $file->move(public_path('images'), $imageName);
            $Managedestination->og_image = $imageName;
            }
		    $Managedestination->short_code=$data['short_code'];
			$Managedestination->page_type_id=$data['page_type_id'];
			$Managedestination->destinations_type=$data['destinations_type'];
			$Managedestination->page_name=$data['page_name'];
			$Managedestination->page_title=$data['page_title'];
			$Managedestination->page_display_name=$data['page_display_name'];
			$Managedestination->page_description=$data['page_description'];
			$Managedestination->page_keyword=$data['page_keyword'];
			$Managedestination->author=$data['author'];
			$Managedestination->robots=$data['robots'];
			$Managedestination->og_type=$data['og_type'];
			$Managedestination->og_title=$data['og_title'];
			$Managedestination->paratitle=$data['paratitle'];
			$Managedestination->paracontent=$data['paracontent'];
			$Managedestination->og_description=$data['og_description'];
			$Managedestination->og_url=$data['og_url'];
			$Managedestination->status=$data['status'];
			$Managedestination->created_at = date("Y-m-d H:i:s");
			
			$Managedestination->delete_status = 1;
			
            $Managedestination->save(); 
				//\DB::table('sector_contro')->insert(['origin'=>$data['origin'],'destination'=>$data['destination'],'airline'=>$data['airline'],'gds_supplier'=>$data['gds_supplier']]);
		}catch (\Exception $e){
		/*  echo "<pre>";
		print_r($data);
		die; */ 	
			$request->session()->flash('alert-danger','Registration Failed');
			return redirect()->Route('manage_destination.edit',$page_id);
		}
		 $request->session()->flash('alert-success', 'User Updates sucessfully'); 
		return redirect()->Route('manage_destination.index');
		  }
      else{
			 
	       return redirect()->Route('manage_destination.index');  
		
          }
    }
    
	
     /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
      
	public function destroy(Request $request, $page_id)
    {
    try {
        // Find the record by page id
        $Managedestination = Managedestination::find($page_id);

        // Check if record exists
        if (!$Managedestination) {
            return redirect()->back()->with('alert-danger', 'Record not found.');
        }

        // Update the delete_status column instead of deleting the record
        $Managedestination->delete_status = 0;
        
        if ($Managedestination->save()) {
            $request->session()->flash('alert-success', 'User delete sucessfully.');
        } else {
            $request->session()->flash('alert-danger', 'Failed to update record.');
        }
    } catch (\Exception $e) {
        $request->session()->flash('alert-danger', 'Error: ' . $e->getMessage());
    }

    return redirect()->back();
  }
	
}
