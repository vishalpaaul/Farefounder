<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title> Farefounder : Find Cheap Flights & Book Air Tickets Online </title>
		<meta name="keywords" content="" />
		<meta name="description" content="">
		<meta name="author" content="">
		<meta name="robots" content="index , follow">
		<link rel="canonical" href="">
		<link href="{{ url('public/images/favicon.png') }}" rel="shortcut icon" type="image/x-icon" />
		
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="{{url('public/frontend/css/bootstrap.min.css')}}" />
        <link rel="stylesheet" href="{{url('public/frontend/css/page-style.css')}}" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" /> 
		<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&display=swap" rel="stylesheet">	
    </head>
    <body>
	
	    
		<!-- HEADER CODE -->
		 @include('frontend.layouts.header')
		<!-- HEADER CODE -->
		
   @php
   use App\Models\HomeSlider;
  $homeSliderimage = HomeSlider::where('delete_status', 1)->where('status','Enabled')->first();
   @endphp
		<div class="holiday_banner" style="background:#00266b; background-size: cover; background-position: center; min-height: 400px;">
		 <div class="container">
		  <div class="row">
		   <div class="col-md-12">
		    <div class="banner_heading">
			 <h1> {{$homeSliderimage['title_1']}} </h1>
			 <h2> {{$homeSliderimage['title_2']}} </h2>
			</div>
			
			<!--- FORM --->
			@include('frontend.form')
			<!--- FORM --->
			
		   </div>
		  </div>
		 </div>
		</div>
		
		@include('frontend.layouts.reviews')
		
		@include('frontend.layouts.bottom')
		
		
		<div class="destination_main">
		 <div class="container">
		  <div class="row">
		   <div class="col-md-12">
		    <div class="heading_one">
			 <h3> Top Flight Deals for your <span> Traveling Adventures </span> </h3>
			 <p> From New York City’s bustling environment to the exotic sceneries of Denver city, any traveler’s heart can fall for any of these destinations. </p>
			</div>
		   </div>
		  </div>
	 @php
	 use App\Models\Managehotdeal;
     $hot_deal_id = 9;
     $hotdeali = Managehotdeal::where('hot_deal_id', $hot_deal_id) ->where('delete_status', 1)->where('status', 'Enabled')->first();
    @endphp
		  <div class="row">
		   <div class="col-md-6">
		    <div class="row">
			 <div class="col-md-12 gap1">
			   <div class="items_1">
				<div class="dest_img" style="background:url({{ asset('public/images/'.$hotdeali['airline_image'] )}}) left top no-repeat; height:250px; background-size: cover; background-position: center;"></div>
				<div class="deals_content">
					<h4> {{ $hotdeali->destination }} </h4>
					<p> {{ \Carbon\Carbon::parse($hotdeali->from_date)->format('d M Y') }} | {{ \Carbon\Carbon::parse($hotdeali->to_date)->format('d M Y') }} </p>
					<h5> $ {{ $hotdeali->price_in_usd }} </h5>
				</div>
			  </div>
			 </div>
	 @php
     $hot_deal_id = 7;
     $hotdealf = Managehotdeal::where('hot_deal_id', $hot_deal_id) ->where('delete_status', 1)->where('status', 'Enabled')->first();
    @endphp
			 <div class="col-md-6 gap1">
			   <div class="items_1">
				<div class="dest_img" style="background:url({{ asset('public/images/'.$hotdealf['airline_image'] )}}) left top no-repeat; height:250px; background-size: cover; background-position: center;"></div>
				<div class="deals_content">
					<h4> {{ $hotdealf->destination }} </h4>
					<p> {{ \Carbon\Carbon::parse($hotdealf->from_date)->format('d M Y') }} | {{ \Carbon\Carbon::parse($hotdealf->to_date)->format('d M Y') }} </p>
					<h5> $ {{ $hotdealf->price_in_usd }} </h5>
				</div>
			  </div>
			 </div>
	@php
     $hot_deal_id = 6;
     $hotdeale = Managehotdeal::where('hot_deal_id', $hot_deal_id) ->where('delete_status', 1)->where('status', 'Enabled')->first();
    @endphp
			 <div class="col-md-6 gap1">
			   <div class="items_1">
				<div class="dest_img" style="background:url({{ asset('public/images/'.$hotdeale['airline_image'] )}}) left top no-repeat; height:250px; background-size: cover; background-position: center;"></div>
				<div class="deals_content">
					<h4> {{ $hotdeale->destination }} </h4>
					<p> {{ \Carbon\Carbon::parse($hotdeale->from_date)->format('d M Y') }} | {{ \Carbon\Carbon::parse($hotdeale->to_date)->format('d M Y') }} </p>
					<h5> $ {{ $hotdeale->price_in_usd }} </h5>
				</div>
			  </div>
			 </div>
			</div>
		   </div>
	 @php
     $hot_deal_id = 8;
     $hotdealh = Managehotdeal::where('hot_deal_id', $hot_deal_id) ->where('delete_status', 1)->where('status', 'Enabled')->first();
     @endphp
		   <div class="col-md-6">
		    <div class="row">
			 <div class="col-md-12">
			   <div class="items_1">
				<div class="dest_img" style="background:url({{ asset('public/images/'.$hotdealh['airline_image'] )}}) left top no-repeat; height:250px; background-size: cover; background-position: center;"></div>
				<div class="deals_content">
					<h4> {{$hotdealh->destination}} </h4>
					<p> {{ \Carbon\Carbon::parse($hotdealh->from_date)->format('d M Y') }} | {{ \Carbon\Carbon::parse($hotdealh->to_date)->format('d M Y') }} </p>
					<h5> $ {{ $hotdealh->price_in_usd }} </h5>
				</div>
			  </div>
			 </div>
	 @php
     $hot_deal_id = 5;
     $hotdealc = Managehotdeal::where('hot_deal_id', $hot_deal_id) ->where('delete_status', 1)->where('status', 'Enabled')->first();
    @endphp
			 <div class="col-md-6 gap1">
			   <div class="items_1">
				<div class="dest_img" style="background:url({{ asset('public/images/'.$hotdealc['airline_image'] )}}) left top no-repeat; height:250px; background-size: cover; background-position: center;"></div>
				<div class="deals_content">
					<h4> {{$hotdealc->destination}} </h4>
					<p> {{ \Carbon\Carbon::parse($hotdealc->from_date)->format('d M Y') }} | {{ \Carbon\Carbon::parse($hotdealc->to_date)->format('d M Y') }} </p>
					<h5> $ {{ $hotdealc->price_in_usd }} </h5>
				</div>
			  </div>
			 </div>
	 @php
     $hot_deal_id = 4;
     $hotdealb = Managehotdeal::where('hot_deal_id', $hot_deal_id) ->where('delete_status', 1)->where('status', 'Enabled')->first();
     @endphp
			 <div class="col-md-6">
			   <div class="items_1">
				<div class="dest_img" style="background:url({{ asset('public/images/'.$hotdealb['airline_image'] )}}) left top no-repeat; height:250px; background-size: cover; background-position: center;"></div>
				<div class="deals_content">
					<h4> {{$hotdealb->destination}} </h4>
					<p> {{ \Carbon\Carbon::parse($hotdealb->from_date)->format('d M Y') }} | {{ \Carbon\Carbon::parse($hotdealb->to_date)->format('d M Y') }} </p>
					<h5> $ {{ $hotdealb->price_in_usd }} </h5>
				</div>
			  </div>
			 </div>
		  </div>
		 </div>
		</div>
		 </div>
		</div>
		
		<div class="flight_deal_main">
		 <div class="container">
		  <div class="row">
		   <div class="col-md-12">
		    <div class="heading_one">
			 <h3> Get Affordable Deals for the <span> World’s Best Destinations from the US </span> </h3>
			 <p> travel to your favorite destinations with all premium amenities at affordable prices! </p>
			</div>
		   </div>
		  </div>
		  
		  <div class="row">
	@php
    use App\Models\Manageflightsdeal;
    $flightsdeal = Manageflightsdeal::where('delete_status', 1)->where('status', 'Enabled')->get();
    @endphp

   @foreach ($flightsdeal as $deal)
		   <div class="col-md-6">
		    <div class="deal_item">
			 <a href="{{ $deal->result_url }}" target="_blank">
			 <div class="trip_data_item">
			  <h6> <strong> Depart : </strong> {{ \Carbon\Carbon::parse($deal->from_date)->format('d M Y') }}<span> | <strong> Return : </strong> <span> {{ \Carbon\Carbon::parse($deal->to_date)->format('d M Y') }} </span> </h6>
			 </div>
			 
			 <div class="allflt_main">
			  <div class="fare_logo">
			   <img src="{{ asset('public/images/'. $deal->airline_image) }}">
			  </div>
			  
			  <div class="fare_names">
			   <p> From </p>
			   <h4> {{ $deal->Origin_code }} </h4>
			   <h6> {{ $deal->origin }} </h6>
			  </div>
			  
			  <div class="deal_ttrt">
			    <span> <strong> ⇌ </strong> </span>
			  </div>
			  
			  <div class="fare_names eng_d">
			   <p> From </p>
			   <h4> {{ $deal->destination_code }} </h4>
			   <h6> {{ $deal->destination }} </h6>
			  </div>
			  
			  <div class="fare_Price">
			   <p> Starting From </p>
			   <h4> {{$deal->price_in_usd }} </h4>
			  </div>
			 </div>
			 </a>
			</div>
		   </div>
         @endforeach  
		   
		  </div>
		  
		  <div class="row">
		   <div class="col-md-12">
		    <div class="fare_update">
			 <p> <span> *Note: All fares are quoted in USD .</span>
Last updated on  <strong> {{ \Carbon\Carbon::yesterday()->format('l d/m/Y') }} at 05:00 AM, </strong> the fares mentioned above are for flight tickets and inclusive of fuel surcharges , service fee and taxes . Based on historical data, these fares are subject to change without prior notice and cannot be guaranteed at the time of booking . Kindly go through our <a href="#"> Terms & Conditions </a> before booking. </p>
			</div>
		   </div>
		  </div>
		 </div>
		</div>
		
	@php
    use App\Models\Manageinformation;
    $pages_id = 1;
    $aboutus = Manageinformation::where('pages_id', $pages_id)->where('delete_status', 1)->where('status', 'Enabled')->first();
    @endphp
		<div class="book_instant">
		 <div class="container">
		  <div class="row">
		   <div class="col-md-12">
		    <div class="aboutus_info">
			 <h6> Welcome to </h6>
			 <h3> Book Cheap Air Tickets with Farefounder </h3>
			 <p> {!! optional($aboutus)->discription; !!}</p>
			 <a href="{{url('about-us')}}"> Read More</a>
			</div>
		   </div>
		  </div>
		 </div>
		</div>
		
		
		<div class="mydubre">
		 <div class="container">
		  <div class="suscribe_main" style="    padding: 0 0px 12px 0;">
	    <div class="col-md-2">
		 <div class="alart_bell">
		  <img src="{{url('public/frontend/images/emailer-2.png')}}">
		 </div>
		 </div>
		 
		 <div class="col-md-4">
		 <div class="subscribe_cont">
		  <h4> Join our newsletter </h4>
		  <p> Sign up and we’ll send the best deals to you </p>
		 </div>
		 </div>
		 
		 <div class="col-md-6">
		 <div class="newslatter_box">
		  <input type="email" class="subscribe_control" placeholder="Your email">
		  <button type="submit" class="subscribe_primary"> Subscribe </button>
		 </div>
	    </div>
	  </div>
		 </div>
		</div>
		
    <!-- FOOTER CODE -->
	@include('frontend.layouts.footer')
	<!-- FOOTER CODE -->
   
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<script src="{{url('public/frontend/js/popper.min.js')}}"></script>
	<script src="{{url('public/frontend/js/bootstrap.min.js')}}"></script>
	<script src="{{url('public/frontend/js/airports.js')}}"></script>
	
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
   <script>
	$(document).ready(function() {
		$("#news-slider").owlCarousel({
			items : 3,
			itemsDesktop:[1199,3],
			itemsDesktopSmall:[980,2],
			itemsMobile : [600,1],
			navigation:true,
			navigationText:["",""],
			pagination:true,
			autoPlay:true
		});
	});
	</script>
	
	<script>
   $("#location").autocomplete({
    source: airports,
    select: function (event, ui) {
        $("#location").val(ui.item.label.split("-")[0].trim()); // Set input to airport code
        $("#from_city").text(ui.item.value); // Set display text to city name
        return false;	
    }	
});



$("#location2").autocomplete({
    source: airports,
    select: function (event, ui) {
        $("#location2").val(ui.item.label.split("-")[0].trim()); // Set input to airport code
        $("#to_city").text(ui.item.value); // Set display text to city name
        return false;
    }
});

// Clear input functions
    window.clearInput = function () {
        $("#location").val(""); // Clear input field
        //$("#from_city").text(""); // Clear airport display
    };

    window.clearInput2 = function () {
        $("#location2").val(""); // Clear input field
        //$("#to_city").text(""); // Clear airport display
    };
</script>

<script>
 $(function() {
    $("#datepicker").datepicker({
        minDate: 0, // Disable past dates
        dateFormat: "dd-M-yy",
        onSelect: function(dateText, inst) {
            let selectedDate = $(this).datepicker("getDate"); // Get selected date
            let dayOfWeek = $.datepicker.formatDate('DD', selectedDate); // Day of the week

            $("#depDt").val(dateText); // Store in hidden input
            $("#datepicker_label").text(`${dayOfWeek}`); // Update label

            // Set return date minDate to one day after departure date
            let nextDay = new Date(selectedDate);
            nextDay.setDate(nextDay.getDate() + 1);
            $("#datepicker2").datepicker("option", "minDate", nextDay);
        }
    });

    $("#datepicker2").datepicker({
        minDate: "+1D", // Default minDate: one day after today
        dateFormat: "dd-M-yy",
        onSelect: function(dateText, inst) {
            let selectedDate = $(this).datepicker("getDate"); // Get selected date
            let dayOfWeek = $.datepicker.formatDate('DD', selectedDate); // Day of the week

            $("#retDt").val(dateText); // Store in hidden input
            $("#datepicker2_label").text(`${dayOfWeek}`); // Update label
        }
    });
});
</script>

<script type="text/javascript">
    function show_date(data) {
        if (data == "oneway") {
            document.getElementById("datepicker2").disabled = true;
            var a = document.getElementById("datepicker2");
            a.removeAttribute("required");
        } else if (data == "roundtrip") {
            document.getElementById("datepicker2").disabled = false;
            var b = document.getElementById("datepicker2");
            b.setAttribute("required", true);
        }
    }
</script>

<script type="text/javascript">
    $(document).ready(function() {
    $("#btm_clk").click(function() {
        $(".psg_dls").toggle('slideUp');
    });

    $(".btn_done").click(function() {
        var total = all_pesenger(); // Get total number of passengers
        var classType = $("#classType").val(); // Get selected class type from an input or select field
        
        // Convert class code to readable format
        var classText = 'Economy'; // Default class
        if (classType === 'S') classText = 'Premium Economy';
        if (classType === 'C') classText = 'Business Class';
        if (classType === 'F') classText = 'First Class';

        $("#btm_clk").val(total + ' , Travelers'); // Update input field with total passengers
        $("#class_label").text(classText); // Update the class type label
        $(".psg_dls").hide(1000); // Hide the selection box smoothly
    });
});
</script>

<script>
    function add_rt_passenger() {
        var infow = $("#InfantsRT").val();
        var childow = $("#ChildrenRT").val();
        var adultow = $("#AdultsRT").val();
        var total = +infow + +childow + +adultow;
        return total;
    }

    function all_pesenger() {

        var infow = $("#InfantsRT").val();
        var childow = $("#ChildrenRT").val();
        var adultow = $("#AdultsRT").val();
        var total = +infow + +childow + +adultow;
        return total;
    }

    function increase_adult_rt() {
        var adult_pass = add_rt_passenger();
        var adult_rt = document.getElementById("AdultsRT").value;
        if (adult_pass < 9) {
            var k = parseInt(adult_rt) + 1;
            document.getElementById("AdultsRT").value = k;
        }

    }

    function decrease_adult_rt() {
        var adult_rt = document.getElementById("AdultsRT").value;
        var InfantsRT = document.getElementById("InfantsRT").value;
        if (adult_rt != '1') {
            var k = parseInt(adult_rt) - 1;
            document.getElementById("AdultsRT").value = k;

            if (InfantsRT >= adult_rt) {
                var k = parseInt(InfantsRT) - 1;
                document.getElementById("InfantsRT").value = k;
            }

        }
    }

    function increase_child_rt() {
        var adult_pass = add_rt_passenger();
        var adult_rt = document.getElementById("ChildrenRT").value;
        if (adult_pass < 9) {

            var k = parseInt(adult_rt) + 1;
            document.getElementById("ChildrenRT").value = k;
        }

    }

    function decrease_child_rt() {
        var adult_rt = document.getElementById("ChildrenRT").value;
        if (adult_rt != '0') {
            var k = parseInt(adult_rt) - 1;
            document.getElementById("ChildrenRT").value = k;
        }
    }

    function increase_infant_rt() {

        var total_pass = add_rt_passenger();

        var adult_rt = document.getElementById("AdultsRT").value;
        var InfantsRT = document.getElementById("InfantsRT").value;

        if (total_pass < 9 && InfantsRT < adult_rt) {
            var k = parseInt(InfantsRT) + 1;
            document.getElementById("InfantsRT").value = k;
        }

    }

    function decrease_infant_rt() {
        var adult_rt = document.getElementById("InfantsRT").value;
        if (adult_rt != '0') {
            var k = parseInt(adult_rt) - 1;
            document.getElementById("InfantsRT").value = k;
        }
    }

    function Resolution() {
        if (window.innerWidth < 780) {
            return 1;
        } else {
            return 2;
        }
    }
</script>
	
    </body>
</html>