<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title> Farefounder : Find Cheap Flights & Book Air Tickets Online </title>
		<meta name="keywords" content="" />
		<meta name="description" content="">
		<meta name="author" content="">
		<meta name="robots" content="index , follow">
		<link rel="canonical" href="">
		<link href="{{ url('public/images/favicon.png') }}" rel="shortcut icon" type="image/x-icon" />
		
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="{{url('public/frontend/css/bootstrap.min.css')}}" />
        <link rel="stylesheet" href="{{url('public/frontend/css/page-style.css')}}" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" /> 
		<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&display=swap" rel="stylesheet">
    </head>
    <body>
	
	    
		<!-- HEADER CODE -->
		@include('frontend.layouts.header')
		<!-- HEADER CODE -->
		
		
		<div class="destination_banner" style="background:url({{url('public/frontend/./images/banners.jpg')}}) left top no-repeat; background-size: cover; background-position: center; min-height: 200px;">
		 <div class="container">
		  <div class="row">
		   <div class="col-md-12">
		    <div class="about_banner">
			 <h1> Privacy policy </h1>
			 <ul>
			 <li> <a href=""> Home </a> </li>
			 <li> | </li>
			 <li> Privacy policy </li>
			 </ul>
			</div>
		   </div>
		  </div>
		 </div>
		</div>
		
		
		
		@php
     use App\Models\Manageinformation;
     $pages_id = 2;
     $Privacy = Manageinformation::where('pages_id', $pages_id) ->where('delete_status', 1)->where('status', 'Enabled')->first();
     @endphp
       <div class="privacy_main">
		 <div class="container">
		  <div class="row">
		   <div class="col-md-12">
		    <div class="important_info">
			 <h2> {{ optional($Privacy)->title_name; }} </h2>
			 <p>   {!! optional($Privacy)->discription; !!} </p>
			 
			</div>
		   </div>
		  </div>
		 </div>
		</div>
		

		
    <!-- FOOTER CODE -->
	@include('frontend.layouts.footer')
	<!-- FOOTER CODE -->
   
     
    

	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="{{url('public/frontend/js/jquery-3.2.1.slim.min.js')}}"></script>
	<script src="{{url('public/frontend/js/popper.min.js')}}"></script>
	<script src="{{url('public/frontend/js/bootstrap.min.js')}}"></script>
	
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
   <script>
	$(document).ready(function() {
		$("#news-slider").owlCarousel({
			items : 3,
			itemsDesktop:[1199,3],
			itemsDesktopSmall:[980,2],
			itemsMobile : [600,1],
			navigation:true,
			navigationText:["",""],
			pagination:true,
			autoPlay:true
		});
	});
	</script>
    </body>
</html>