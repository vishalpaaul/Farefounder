<!DOCTYPE html>
<html lang="en">
    <head>
	@php
		use App\Models\Managedestination;
		
        $page = Managedestination::where('delete_status', 1)->where('page_name', $page_id)->first();

        // If no page is found, return 404
        if (!$page) {
            abort(404, 'Page Not Found');
        }

        // Fetch the SEO details for the page
        $seo_title = Managedestination::where('delete_status', 1)
            ->where('page_id', $page->page_id)
            ->first();

        // If no SEO details found, return default values
        $seo_data = [
            'page_title' => $seo_title->page_title ?? 'Default Title',
            'page_keyword' => $seo_title->page_keyword ?? '',
            'author' => $seo_title->author ?? '',
            'robots' => $seo_title->robots ?? '',
            'og_type' => $seo_title->og_type ?? 'website',
            'og_title' => $seo_title->og_title ?? 'Default OG Title',
            'og_description' => $seo_title->og_description ?? 'Default OG Description',
            'og_url' => $seo_title->og_url ?? url()->current(),
            'og_image' => url('admin/' . $seo_title->og_image ?? 'default-image.jpg'),
        ];
        
		 @endphp
		<title>{{ $seo_data['page_title'] }}</title>
		<meta name="keywords" content="{{ $seo_data['page_keyword'] }}" />
		<meta name="description" content="{{ $seo_data['og_description'] }}">
		<meta name="author" content="{{ $seo_data['author'] }}">
		<meta name="robots" content="{{ $seo_data['robots'] }}">
		<meta property="og:type" content="{{ $seo_data['og_type'] }}">
	    <meta property="og:title" content="{{ $seo_data['og_title']}}">
	    <meta property="og:description" content="{{ $seo_data['og_description'] }}">
	    <link rel="canonical" href="{{ $seo_data['og_url'] }}">
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <link href="{{ url('public/images/favicon.png') }}" rel="shortcut icon" type="image/x-icon" />
		
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="{{url('public/frontend/css/bootstrap.min.css')}}" />
        <link rel="stylesheet" href="{{url('public/frontend/css/page-style.css')}}" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" /> 
		<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&display=swap" rel="stylesheet">
    </head>
    <body>
	
	    
		<!-- HEADER CODE -->
		@include('frontend.layouts.header')
		<!-- HEADER CODE -->
		
		@php
       // Fetch page details from `tb_pages`
        $page = Managedestination::where('delete_status', 1)->where('page_name', $page_id) ->first();

        // If no page found, return 404
        if (!$page) {
            abort(404, 'Page Not Found');
        }

        // Get necessary page details
        $page_id = $page->page_id;
        $page_type_id = $page->page_type_id;
        $destinations_type = $page->destinations_type;

       // Fetch airline image details
	   use App\Models\Managepagesimage;
       $airlineImage =Managepagesimage::where('delete_status', 1) ->where('page_id', $page_id)->first();

     // Check if airline image exists, else use default
     $website_path = url('/');

    $airline_image = $airlineImage && $airlineImage->airline_image
    ? asset('public/images/' . $airlineImage->airline_image)
    : asset('public/frontend/images/france_banner.jpg');
        @endphp
		<div class="destination_banner" style="background:url({{ $airline_image }}) left top no-repeat; background-size: cover; background-position: center; min-height: 450px;">
		 <div class="container">
		  <div class="row">
		   <div class="col-md-12">
		    <div class="banner_heading">
			 <h1> Book {{ $page->page_display_name }} </h1>
			 <h2> Book Over 600 Airlines with 100+ Payment Options </h2>
			</div>
			
			@include('frontend.form')
		   </div>
		  </div>
		 </div>
		</div>
		@include('frontend.layouts.bottom')
		
		<div class="flight_deal_inner">
		 <div class="container">
		  <div class="row">
		   <div class="col-md-12">
		    <div class="heading_one">
			 <h3> Most Popular Flights Deals </h3>
			 <p> Search, Compare and book the lowest airfares from thousands of travel service providers and airlines <br> Check out our handpicked deals for the most trending domestic destinations. </p>
			</div>
		   </div>
		  </div>
		  
		  <div class="row">
		   <div class="col-md-12">
		    <div class="dealsecn">
			 <ul class="fare_header">
			 <li> <i class="fa fa-plane"></i> From </li>
			 <li> <i class="fa fa-plane" style="transform: rotate(90deg);"></i> To </li>
			 <li> <i class="fa fa-calendar"></i> Depart </li>
			 <li> <i class="fa fa-calendar"></i> Return </li>
			 <li> *Fares Starting From </li>
			 </ul>
			 
			 <ul class="fare_context">
			 <li>  Boston </li>
			 <li>  New Orleans </li>
			 <li>  Mar 18, 2025 </li>
			 <li>  Apr 17, 2025 </li>
			 <li> <a href="javascript:void(0)" class="g_orange">$690 <sup>.31</sup> </a> </li>
			 </ul>
			 
			 <ul class="fare_context">
			 <li>  Atlanta </li>
			 <li>  New Orleans </li>
			 <li>  Mar 22, 2025 </li>
			 <li>  Apr 11, 2025 </li>
			 <li> <a href="javascript:void(0)" class="g_orange">$610 <sup>.38</sup> </a> </li>
			 </ul>
			 
			 <ul class="fare_context">
			 <li>  Los Angeles </li>
			 <li>  New Orleans </li>
			 <li>  Mar 25, 2025 </li>
			 <li>  Apr 15, 2025 </li>
			 <li> <a href="javascript:void(0)" class="g_orange">$965 <sup>.22</sup> </a> </li>
			 </ul>
			 
			 <ul class="fare_context">
			 <li>  Washington </li>
			 <li>  New Orleans </li>
			 <li>  Mar 10, 2025 </li>
			 <li>  Apr 05, 2025 </li>
			 <li> <a href="javascript:void(0)" class="g_orange">$512 <sup>.54</sup> </a> </li>
			 </ul>
			</div>
		   </div>
		  </div>
		  
		  <div class="row">
		   <div class="col-md-12">
		    <div class="fare_update">
			 <p> <span> *Note: All fares are quoted in USD .</span>
Last updated on  <strong> {{ \Carbon\Carbon::yesterday()->format('l d/m/Y') }} at 05:00 AM, </strong> the fares mentioned above are for flight tickets and inclusive of fuel surcharges , service fee and taxes . Based on historical data, these fares are subject to change without prior notice and cannot be guaranteed at the time of booking . Kindly go through our <a href="#"> Terms & Conditions </a> before booking. </p>
			</div>
		   </div>
		  </div>
		 </div>
		</div>
		
		@php 
         $prow = Managedestination::where('delete_status', 1)->where('page_id', $page_id)->first();
        
		@endphp
		<div class="introduct_full">
		 <div class="container">
		  <div class="row">
		   <div class="col-md-12">
		    <div class="overview_text">
			 <h3> {{ $prow->paratitle }} </h3>
			 <p> {!!$prow['paracontent']!!} </p>
			 
			 
			</div>
		   </div>
		  </div>
		 </div>
		</div>
		
		
		
		
		 
		
    <!-- FOOTER CODE -->
	@include('frontend.layouts.footer')
	<!-- FOOTER CODE -->
   
     
    

	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<script src="{{url('public/frontend/js/popper.min.js')}}"></script>
	<script src="{{url('public/frontend/js/bootstrap.min.js')}}"></script>
	<script src="{{url('public/frontend/js/airports.js')}}"></script>
	
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
   <script>
	$(document).ready(function() {
		$("#news-slider").owlCarousel({
			items : 3,
			itemsDesktop:[1199,3],
			itemsDesktopSmall:[980,2],
			itemsMobile : [600,1],
			navigation:true,
			navigationText:["",""],
			pagination:true,
			autoPlay:true
		});
	});
	</script>
	
	<script>
   $("#location").autocomplete({
    source: airports,
    select: function (event, ui) {
        $("#location").val(ui.item.label.split("-")[0].trim()); // Set input to airport code
        $("#from_city").text(ui.item.value); // Set display text to city name
        return false;	
    }	
});



$("#location2").autocomplete({
    source: airports,
    select: function (event, ui) {
        $("#location2").val(ui.item.label.split("-")[0].trim()); // Set input to airport code
        $("#to_city").text(ui.item.value); // Set display text to city name
        return false;
    }
});

// Clear input functions
    window.clearInput = function () {
        $("#location").val(""); // Clear input field
        //$("#from_city").text(""); // Clear airport display
    };

    window.clearInput2 = function () {
        $("#location2").val(""); // Clear input field
        //$("#to_city").text(""); // Clear airport display
    };
</script>

<script>
 $(function() {
    $("#datepicker").datepicker({
        minDate: 0, // Disable past dates
        dateFormat: "dd-M-yy",
        onSelect: function(dateText, inst) {
            let selectedDate = $(this).datepicker("getDate"); // Get selected date
            let dayOfWeek = $.datepicker.formatDate('DD', selectedDate); // Day of the week

            $("#depDt").val(dateText); // Store in hidden input
            $("#datepicker_label").text(`${dayOfWeek}`); // Update label

            // Set return date minDate to one day after departure date
            let nextDay = new Date(selectedDate);
            nextDay.setDate(nextDay.getDate() + 1);
            $("#datepicker2").datepicker("option", "minDate", nextDay);
        }
    });

    $("#datepicker2").datepicker({
        minDate: "+1D", // Default minDate: one day after today
        dateFormat: "dd-M-yy",
        onSelect: function(dateText, inst) {
            let selectedDate = $(this).datepicker("getDate"); // Get selected date
            let dayOfWeek = $.datepicker.formatDate('DD', selectedDate); // Day of the week

            $("#retDt").val(dateText); // Store in hidden input
            $("#datepicker2_label").text(`${dayOfWeek}`); // Update label
        }
    });
});
</script>

<script type="text/javascript">
    function show_date(data) {
        if (data == "oneway") {
            document.getElementById("datepicker2").disabled = true;
            var a = document.getElementById("datepicker2");
            a.removeAttribute("required");
        } else if (data == "roundtrip") {
            document.getElementById("datepicker2").disabled = false;
            var b = document.getElementById("datepicker2");
            b.setAttribute("required", true);
        }
    }
</script>

<script type="text/javascript">
    $(document).ready(function() {
    $("#btm_clk").click(function() {
        $(".psg_dls").toggle('slideUp');
    });

    $(".btn_done").click(function() {
        var total = all_pesenger(); // Get total number of passengers
        var classType = $("#classType").val(); // Get selected class type from an input or select field
        
        // Convert class code to readable format
        var classText = 'Economy'; // Default class
        if (classType === 'S') classText = 'Premium Economy';
        if (classType === 'C') classText = 'Business Class';
        if (classType === 'F') classText = 'First Class';

        $("#btm_clk").val(total + ' , Travelers'); // Update input field with total passengers
        $("#class_label").text(classText); // Update the class type label
        $(".psg_dls").hide(1000); // Hide the selection box smoothly
    });
});
</script>

<script>
    function add_rt_passenger() {
        var infow = $("#InfantsRT").val();
        var childow = $("#ChildrenRT").val();
        var adultow = $("#AdultsRT").val();
        var total = +infow + +childow + +adultow;
        return total;
    }

    function all_pesenger() {

        var infow = $("#InfantsRT").val();
        var childow = $("#ChildrenRT").val();
        var adultow = $("#AdultsRT").val();
        var total = +infow + +childow + +adultow;
        return total;
    }

    function increase_adult_rt() {
        var adult_pass = add_rt_passenger();
        var adult_rt = document.getElementById("AdultsRT").value;
        if (adult_pass < 9) {
            var k = parseInt(adult_rt) + 1;
            document.getElementById("AdultsRT").value = k;
        }

    }

    function decrease_adult_rt() {
        var adult_rt = document.getElementById("AdultsRT").value;
        var InfantsRT = document.getElementById("InfantsRT").value;
        if (adult_rt != '1') {
            var k = parseInt(adult_rt) - 1;
            document.getElementById("AdultsRT").value = k;

            if (InfantsRT >= adult_rt) {
                var k = parseInt(InfantsRT) - 1;
                document.getElementById("InfantsRT").value = k;
            }

        }
    }

    function increase_child_rt() {
        var adult_pass = add_rt_passenger();
        var adult_rt = document.getElementById("ChildrenRT").value;
        if (adult_pass < 9) {

            var k = parseInt(adult_rt) + 1;
            document.getElementById("ChildrenRT").value = k;
        }

    }

    function decrease_child_rt() {
        var adult_rt = document.getElementById("ChildrenRT").value;
        if (adult_rt != '0') {
            var k = parseInt(adult_rt) - 1;
            document.getElementById("ChildrenRT").value = k;
        }
    }

    function increase_infant_rt() {

        var total_pass = add_rt_passenger();

        var adult_rt = document.getElementById("AdultsRT").value;
        var InfantsRT = document.getElementById("InfantsRT").value;

        if (total_pass < 9 && InfantsRT < adult_rt) {
            var k = parseInt(InfantsRT) + 1;
            document.getElementById("InfantsRT").value = k;
        }

    }

    function decrease_infant_rt() {
        var adult_rt = document.getElementById("InfantsRT").value;
        if (adult_rt != '0') {
            var k = parseInt(adult_rt) - 1;
            document.getElementById("InfantsRT").value = k;
        }
    }

    function Resolution() {
        if (window.innerWidth < 780) {
            return 1;
        } else {
            return 2;
        }
    }
</script>
    </body>
</html>