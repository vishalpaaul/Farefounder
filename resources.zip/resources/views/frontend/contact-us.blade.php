<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title> Farefounder : Find Cheap Flights & Book Air Tickets Online </title>
		<meta name="keywords" content="" />
		<meta name="description" content="">
		<meta name="author" content="">
		<meta name="robots" content="index , follow">
		<link rel="canonical" href="">
		<link href="{{ url('public/images/favicon.png') }}" rel="shortcut icon" type="image/x-icon" />
		
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="{{url('public/frontend/css/bootstrap.min.css')}}" />
        <link rel="stylesheet" href="{{url('public/frontend/css/page-style.css')}}" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" /> 
		<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&display=swap" rel="stylesheet">
    </head>
    <body>
	
	    
		<!-- HEADER CODE -->
		@include('frontend.layouts.header')
		<!-- HEADER CODE -->
		
		
		<div class="destination_banner" style="background:url({{url('public/frontend/./images/contact-banner.webp')}}) left top no-repeat; background-size: cover; background-position: center; min-height: 215px;">
		 <div class="container">
		  <div class="row">
		   <div class="col-md-12">
		    <div class="about_banner">
			 <h1> Contact us Need help? </h1>
			 <ul>
			 <li> <a href=""> Home </a> </li>
			 <li> | </li>
			 <li> Contact us </li>
			 </ul>
			</div>
		   </div>
		  </div>
		 </div>
		</div>
		
		
		<div class="botom_bner">
        <div class="container">
         <div class="row">
		 <div class="col-md-7">
		  <form name="RegForm" action="{{ route('contact.submit') }}" method="POST" onsubmit="return validateForm()">
		  @csrf
		  <div class="row_contact_us">
		  <div class="col-md-12">
		   <h4> Got a question or a query? We've got you covered. </h4>
		   @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
        @endif
		  </div>
		  
		  <div class="col-md-6">
		  <div class="form-group contact_plus">
		    <i class="fa fa-user"></i>
			<label class="small_label"> Name </label>
			<input type="text" name="name" class="form-control contact_control" placeholder="Name">
			<span id="name_err" style="color:red;"></span>
		  </div>
		  </div>
		  
		  <div class="col-md-6">
		  <div class="form-group contact_plus">
		    <i class="fa fa-phone"></i>
			<label class="small_label"> Mobile Number </label>
			<input type="text" class="form-control contact_control" placeholder="Mobile Number" name="phone" id="txtChar" onkeypress="return isNumberKey(event)" oninput="if(value.length>10)value=value.slice(0,10)">
			<span id="phone_err" style="color:red;"></span>
		  </div>
		  </div>
		  
		  <div class="col-md-12">
		  <div class="form-group contact_plus">
		    <i class="fa fa-envelope-o"></i>
			<label class="small_label"> Email Address</label>
			<input type="email" name="email" class="form-control contact_control" placeholder="Email address">
			<span id="email_err" style="color:red;"></span>
		  </div>
		  </div>
		  
		  
		  <div class="col-md-12">
		  <div class="form-group contact_plus">
		    <i class="fa fa-envelope-o"></i>
			<label class="small_label"> Your Query </label>
			<textarea class="form-control contact_textarea" rows="3"  name="message" placeholder="Typing..."></textarea>
			<span id="msg_err" style="color:red;"></span>
		  </div>
		  </div>
		  
          <div class="col-md-12">
		  <button type="submit" name="submitForm" class="subscribe_primary">Submit</button>
		  </div>
		  </div>
		</form>
		 </div>
		 @php
   use App\Models\Manageglobaldetails;
   $contactus = Manageglobaldetails::first();
   @endphp
		 <div class="col-md-5">
		  <div class="contact-info">
			<h5> Get In Touch </h5>
			<ul>
				<li><i class="fa fa-phone"></i><p> Call Us At: </p><a href="tel:+{{ $contactus->toll_free_number }}"> +{{ $contactus->toll_free_number }} </a></li>
				
				<li><i class="fa fa-envelope"></i><p>Mail Us At: </p><a href="mailto:{{ $contactus->email }}"> {{ $contactus->email }} </a></li>
				
				<li><i class="fa fa-map-marker"></i><p>Find Us At: </p><a href="javascript:void(0);"> {{ $contactus->contact_address_line1 }} {{ $contactus->contact_address_line2 }}</a></li>
			</ul>
		  </div>
		 </div>
        </div>
      </div>
    </div>
		
		
       <div class="book_instant">
		 <div class="container">
		  <div class="row">
		   <div class="col-md-12">
		    <div class="conttus_info">
			  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2831.167611283352!2d-106.9574783246918!3d44.79777267765782!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5335fabc2a6d206b%3A0x1887ab0668b2495c!2s30%20N%20Gould%20St%20Suite%20R%2C%20Sheridan%2C%20WY%2082801%2C%20USA!5e0!3m2!1sen!2sin!4v1742297331122!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
			</div>
		   </div>
		  </div>
		 </div>
		</div>
		

		
    <!-- FOOTER CODE -->
	@include('frontend.layouts.footer')
	<!-- FOOTER CODE -->
   
     
    

	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<!--<script src="{{url('public/frontend/js/jquery-3.2.1.slim.min.js')}}"></script>-->
	<script src="{{url('public/frontend/js/popper.min.js')}}"></script>
	<script src="{{url('public/frontend/js/bootstrap.min.js')}}"></script>
	
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
   <script>
	$(document).ready(function() {
		$("#news-slider").owlCarousel({
			items : 3,
			itemsDesktop:[1199,3],
			itemsDesktopSmall:[980,2],
			itemsMobile : [600,1],
			navigation:true,
			navigationText:["",""],
			pagination:true,
			autoPlay:true
		});
	});
	</script>
	<script>
    function isNumberKey(evt) {
        let charCode = evt.which ? evt.which : event.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) return false;
        return true;
    }

    function validateForm() {
        let name = document.forms["RegForm"]["name"].value.trim();
        let email = document.forms["RegForm"]["email"].value.trim();
        let phone = document.forms["RegForm"]["phone"].value.trim();
        let message = document.forms["RegForm"]["message"].value.trim();

        let namePattern = /^[A-Za-z]+$/;
        let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        let phonePattern = /^[0-9]{10}$/;
        let linkPattern = /(https?:\/\/[^\s]+)/g;

        document.getElementById("name_err").innerText = "";
        document.getElementById("email_err").innerText = "";
        document.getElementById("phone_err").innerText = "";
        document.getElementById("msg_err").innerText = "";

        let isValid = true;

        if (!namePattern.test(name)) {
            document.getElementById("name_err").innerText = "Only letters allowed!";
            isValid = false;
        }

        if (!emailPattern.test(email)) {
            document.getElementById("email_err").innerText = "Enter a valid email!";
            isValid = false;
        }

        if (!phonePattern.test(phone)) {
            document.getElementById("phone_err").innerText = "Phone number must be 10 digits!";
            isValid = false;
        }

        if (message === "") {
            document.getElementById("msg_err").innerText = "Message field cannot be empty!";
            isValid = false;
        } else if (linkPattern.test(message)) {
            document.getElementById("msg_err").innerText = "Links are not allowed!";
            isValid = false;
        }

        return isValid;
    }
</script>
    </body>
</html>