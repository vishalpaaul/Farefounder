<div class="botom_bner">
        <div class="container">
        <div class="row">
		<div class="col-md-12">
		 <div class="white_bg">
          <div class="main_usp">
            <div class="box1" style="background: #ffeef0; border: solid 1px #ffeef0;">
              <div class="icons">
                <img src="{{url('public/frontend/images/same-day.svg')}}">
              </div> 
              <h4> 100% Secure  </h4>
              <p> We guarantee your information and transactions are private and safe. </p>
            </div>
			
			
			
			<div class="box1" style="background: #e3f3eb; border: solid 1px #e3f3eb;">
              <div class="icons">
                <img src="{{url('public/frontend/images/instant-booking.svg')}}">
              </div> 
             <h4> Flexibility </h4>
              <p> we have a wide range of flight options that will meet your budget. </p>
            </div>

    <div class="box1" style="background: #f6f4e4; border: solid 1px #f6f4e4;">
              <div class="icons">
                <img src="{{url('public/frontend/images/price-promise.svg')}}">
              </div> 
              <h4> Best Prices  </h4>
              <p> Enjoy affordable deals and exclusive offers for frequent travelers. </p>
            </div>
            
            <div class="box1" style=" background: #eef7fe; border: solid 1px #eef7fe;">
              <div class="icons">
                <img src="{{url('public/frontend/images/customer-support.svg')}}">
              </div> 
             <h4> Customer Support  </h4>
              <p> we are always ready to assist our customers. </p>
            </div>
          </div>
		  </div>
		  </div>
        </div>
      </div>
    </div>