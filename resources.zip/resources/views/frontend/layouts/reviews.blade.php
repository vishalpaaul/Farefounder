<div class="reviews_main">
	 <div class="container">
	  <div class="row">
	   <div class="col-md-12">
        <div class="trust_left">
		 <h4> Excellent </h4>
		 <img src="{{url('public/frontend/images/stars-4.5.svg')}}" style="width: 160px; margin: 0 0 10px 0;">
		 <h6> Based on <span> 97 reviews </span> </h6>
		 <img src="{{url('public/frontend/images/download2.png')}}">
		</div>

	      <div class="trustpoilt_right">
			<div id="news-slider" class="owl-carousel">
				<div class="trust_slide">
					<div class="trust_img">
						<img src="{{url('public/frontend/images/stars-4.5.svg')}}" style="width: 90px; margin: 0 0 10px 0;">
					</div>
					<div class="trust_review">
						<h3> Franklin was very helpful in getting... </h3>
						<p> Franklin was very helpful in getting the trip put back in place. It was still hard to understand the final price breakdown. Probably because... </p>
						<h6> <span> Deborah Mosko </span>, October 06 </h6>
					</div>
				</div>

				<div class="trust_slide">
					<div class="trust_img">
						<img src="{{url('public/frontend/images/stars-4.5.svg')}}" style="width: 90px; margin: 0 0 10px 0;">
					</div>
					<div class="trust_review">
						<h3> It was nice to talk with this gentle... </h3>
						<p> It was nice to talk with this gentle who dealt professionally, courteously and with patience He addressed all my needs diligently. </p>
						<h6> <span> Mahmud Majeed </span>, October 12 </h6>
					</div>
				</div>

				<div class="trust_slide">
					<div class="trust_img">
						<img src="{{url('public/frontend/images/stars-4.5.svg')}}" style="width: 90px; margin: 0 0 10px 0;">
					</div>
					<div class="trust_review">
						<h3> Gilbert is very helpful... </h3>
						<p> Gilbert is very helpful, he is patient with me to find proper flight to have enough transfer time. Good experience with This agent. </p>
						<h6> <span> Sherry Liu </span>, September 14 </h6>
					</div>
				</div>
                
				<div class="trust_slide">
					<div class="trust_img">
						<img src="{{url('public/frontend/images/stars-4.5.svg')}}" style="width: 90px; margin: 0 0 10px 0;">
					</div>
					<div class="trust_review">
						<h3> Stella Griffin was so pleasant to work... </h3>
						<p> Stella Griffin was so pleasant to work with even though I was a caught completely off guard with additional unexpected fees assessed by Air France </p>
						<h6> <span> Debra </span>, September 03 </h6>
					</div>
				</div>
             </div>
			</div>
          </div>
	  </div>
	 </div>
	</div>