  @php
   use App\Models\Manageglobaldetails;
   $logodetailds = Manageglobaldetails::first();
   @endphp
<nav class="navbar navbar-expand-lg navbar-light">
		  <div class="container">
		  <a class="navbar-brand" href="{{url('index')}}"> <img src="{{ asset('public/images/'. $logodetailds->airline_image) }}"> </a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		  </button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
			  <li class="nav-item active">
				<a class="nav-link" href="{{url('index')}}"> Home </a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="{{url('special-offers')}}"> Special Offers </a>
			  </li>

			  <li class="nav-item">
				<a class="nav-link" href="{{url('about-us')}}"> About Us </a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="{{url('contact-us')}}"> contact Us </a>
			  </li>
			</ul>
			
			<div class="form-inline my-2 my-lg-0">
			 <div class="header_call">
			  <a href="#"> <img src="{{url('public/frontend/images/calls_ub.gif')}}"> +{{ $logodetailds->toll_free_number }} </a>
			  <p> Book Online or Call us 24/7 </p>
			 </div>
		    </div>
			
			<div class="currency">
			 <img src="{{url('public/frontend/images/United_States.webp')}}" style="width: 35px;">
			 <h6> USD </h6>
			</div>
		  </div>
		</nav>