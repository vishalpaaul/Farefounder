<div class="footer_main">
	 <div class="container">
	  
	  
	  <div class="suscribe_main">
	   
	   
	   <div class="col-md-3">
	    <div class="quick_links">
		 <h4> Quick links </h4>
		 
		 <ul>
		  <li> <a href="{{url('about-us')}}"> <i class="fa fa-angle-right"></i> About Us </a> </li>
		  <li> <a href="{{url('contact-us')}}"> <i class="fa fa-angle-right"></i> Contact Us </a> </li>
		  <li> <a href="{{url('privacy-policy')}}"> <i class="fa fa-angle-right"></i> Privacy Policy </a> </li>
		  <li> <a href="{{url('terms-conditions')}}"> <i class="fa fa-angle-right"></i> Terms & Conditions </a> </li>
		  <li> <a href="{{url('refund-policy')}}"> <i class="fa fa-angle-right"></i> Refund Policy </a> </li>
		  <li> <a href="{{url('Cancellation-policy')}}"> <i class="fa fa-angle-right"></i> Cancellation policy </a> </li>
		  
		  <li> <a href=""> <i class="fa fa-angle-right"></i> Sitemap </a> </li>
		 </ul>
		</div>
	   </div>
	   
	   <div class="col-md-3">
	    <div class="quick_links">
		 <h4> U.S. Destinations </h4>
		 
		 <ul>
		 @php
				use App\Models\Managedestination;
                  $pageIds = Managedestination::where('delete_status', 1)
                   ->where('page_type_id', 3)
                   ->where('status', 'Enabled')
                   ->where('destinations_type', 'Domestic')
                   ->whereNotNull('short_code')
                   ->where('short_code', '!=', '')
                   ->orderBy('short_code', 'asc')
                   ->pluck('page_id')
                   ->toArray(); // Convert to array

    // Check if IDs exist
    if (empty($pageIds)) {
        return view('frontend.pages', ['pages' => []]);
    }

    // Fetch records matching the selected IDs
    $pages = Managedestination::where('delete_status', 1)
                 ->where('page_type_id', 3)
                 ->where('status', 'Enabled')
                 ->where('destinations_type', 'Domestic')
                 ->whereIn('page_id', $pageIds)
                 ->orderByRaw("FIELD(page_id, " . implode(',', $pageIds) . ")") // Maintain order
                 ->limit(6)
                 ->get();	
                 @endphp
               @foreach ($pages as $Managedestination)
		  <li> <a href="{{ url('domestic/' . $Managedestination->page_name) }}"> <i class="fa fa-angle-right"></i> {{ $Managedestination->page_display_name }} </a> </li>
		  @endforeach
		 </ul>
		</div>
	   </div>
	   
	   <div class="col-md-3">
	    <div class="quick_links">
		 <h4> International Destinations </h4>
		 
		 <ul>
		 @php
    $pageIds = Managedestination::where('delete_status', 1)
                   ->where('page_type_id', 3)
                   ->where('destinations_type', 'International')
                   ->where('status', 'Enabled')
                   ->whereNotNull('short_code')
                   ->where('short_code', '!=', '')
                   ->orderBy('short_code', 'asc')
                   ->pluck('page_id')
                   ->toArray(); // Convert to array

    // If no pages found, return empty data
    if (empty($pageIds)) {
        return view('frontend.pages', ['pages' => []]);
    }

    // Fetch matching records maintaining order
    $pages = Managedestination::where('delete_status', 1)
                 ->where('page_type_id', 3)
                 ->where('status', 'Enabled')
                 ->where('destinations_type', 'International')
                 ->whereIn('page_id', $pageIds)
                 ->orderByRaw("FIELD(page_id, " . implode(',', $pageIds) . ")") // Keep order
                 ->limit(6)
                 ->get();
				 @endphp
				 @foreach ($pages as $Managedestination)
		  <li> <a href="{{ url('International/' . $Managedestination->page_name) }}"> <i class="fa fa-angle-right"></i> {{ $Managedestination->page_display_name }} </a> </li>
		  @endforeach
		 </ul>
		</div>
	   </div>
	@php
   use App\Models\Manageglobaldetails;
   $logodetailds = Manageglobaldetails::first();
   @endphp
	   <div class="col-md-3">
	    <div class="contact_info">
		<h4> Have questions? </h4>
		
		 <p> Toll Free </p>
		 <a href="#"> +{{ $logodetailds->toll_free_number }} </a>
		 <h6> 24x7 Dedicated Customer Support </h6>
		 
		 <p> Email Address </p>
		 <a href=""> {{ $logodetailds->email }} </a>
		 
		 <p> Address </p>
		 <a href="javascript:void(0)"> {{ $logodetailds->contact_address_line1 }} {{ $logodetailds->contact_address_line2 }} </a>
		</div>
	   </div>
	  </div>
	  
	  <div class="suscribe_main2">
	   <div class="col-md-3">
	     <div class="social_links">
         <ul>
		    <li> Social Media </li>
            <li><a href="#" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#" class="twitters" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#" class="instagram" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
         </ul>
        </div>
	   </div>
	  
	   <div class="col-md-9">
	    <div class="payment_icons">
		   <ul>
			<li> Security & Payment </li>
			<li> <a href="https://www.asta.org/" target="_blank"> <img src="{{url('public/frontend/images/asta_logo.jpg')}}" alt="asta" style="width: 79px;border: solid 1px #c0bec0;border-radius: 2px;"> </a> </li>
			<li> <a href="https://www.authorize.net/" target="_blank"> <img src="{{url('public/frontend/images/autho.png')}}" style="width: 148px; border: solid 1px #c0bec0; border-radius: 2px; padding: 0 0px;"> </a> </li>
			
			<li> <a href="https://usa.visa.com/" target="_blank"> <img src="{{url('public/frontend/images/pay1.png')}}"> </a> </li>
			
			<li> <a href="https://www.mastercard.com/global/en.html" target="_blank"> <img src="{{url('public/frontend/images/pay2.png')}}"> </a> </li>
			
			<li> <a href="https://www.dinersclub.com/" target="_blank"> <img src="{{url('public/frontend/images/pay3.png')}}"> </a> </li>
			
			<li> <a href="https://www.americanexpress.com/en-in/?inav=NavLogo" target="_blank"> <img src="{{url('public/frontend/images/pay4.png')}}"> </a> </li>
			
			<li> <a href="https://www.godaddy.com/" target="_blank"> <img src="{{url('public/frontend/images/icons-p13.png')}}"> </a> </li>
			
		  </ul>
		  </div>
	   </div>
	  </div>
	  @php
      use App\Models\Manageinformation;
	  $pages_id = 4;
      $disclaimer = Manageinformation::where('pages_id', $pages_id) ->where('delete_status', 1)->where('status', 'Enabled')->first();
     @endphp
	  <div class="suscribe_main2">
	   <div class="col-md-12">
	    <div class="disclamer">
		 <p> <strong> Disclaimer: </strong>{{ html_entity_decode(strip_tags(optional($disclaimer)->discription)) }} </p>
		</div>
	   </div>
	  </div>
	  
	  <div class="row">
	   <div class="col-md-12">
	    <div class="copyright">
		 <p> Copyright © 2025 Farefounder.com is a unit of G Skywings
. All Rights Reserved. </p>
		</div>
	   </div>
	  </div>
	 </div>
	</div>