<div class="my_search">
			 <div class="top-search">
			  <div class="switch-field">
			   <input type="radio" id="radio-one" name="tripType" value="roundtrip" checked="checked" onclick="show_date(this.value)"/>
			   <label for="radio-one"> Round Trip </label>
				<input type="radio" id="radio-two" name="tripType" value="oneway" onclick="show_date(this.value)"/>
				<label for="radio-two"> One Way </label>
			  </div>
			  
			  <div class="trustpilot_widget">
				   <h6>  Excellent <img src="{{url('public/frontend/images/stars-4.5.svg')}}" style="width: 100px; margin: -3px 0 0px 0;"> <span> Based on 97 reviews </span> <img src="{{url('public/frontend/images/download2.png')}}" style="margin: -5px 0 0 0; width: 84px;"> </h6>
				  </div>
			 </div>
			
			 <div class="search_row">
			  <div class="colum_one">
			   <div class="form_group_sr">
                <label class="tittle_name"> Depart from </label>
                <input type="text" required="required" class="form-control ser_location" autocomplete="off" placeholder="Origin City" name="origin1" id="location" onclick="clearInput()">
				<p id="from_city"> City Name </p>
               </div>
			  </div>
			  
			  <div class="colum_one">
			   <div class="form_group_sr">
                <label class="tittle_name"> Arrive at </label>
                <input type="text" required="required" class="form-control ser_location" autocomplete="off" placeholder="Destination City" name="destination1" id="location2" onclick="clearInput2()">
				<p id="to_city"> City Name </p>
               </div>
			  </div>
			  
			  <div class="colum_two">
			   <div class="form_group_sr">
                <label class="tittle_name"> Departure Date </label>
                <input id="depDt" type="hidden" value="">
				<input type="text" class="form-control ser_location readonly" id="datepicker" required="required" autocomplete="off" placeholder="Departure">
				<p id="datepicker_label"> Day </p>
               </div>
			  </div>
			  
			  <div class="colum_two">
			   <div class="form_group_sr">
                <label class="tittle_name"> Return Date </label>
                <input id="retDt" type="hidden" value="">
				<input type="text" class="form-control ser_location readonly" id="datepicker2" required="required" autocomplete="off" placeholder="Return">
				<p id="datepicker2_label"> Day </p>
               </div>
			  </div>
			  
			  <div class="colum_three">
			   <div class="form_group_sr">
                <label class="tittle_name"> Travelers & Class  </label>
                <input type="text" class="form-control ser_location readonly" placeholder="1 , Travelers" name="" id="btm_clk" readonly="true">
				<p id='class_label'> Economy </p>
				
				<div class="psg_dls" style="display: none;">
				   
						 <div class="row_traveler">
							<div class="pass_bx">
							 <label>Adults <small>(+17 yrs)</small></label>		
							</div>

						   <div class="pass_bx">
						   <div class="input-group number-spinner">
							<span class="input-group-btn">
							<a class="btn mns_btn" data-dir="dwn" onclick="decrease_adult_rt()"><i class="fa fa-minus"></i></a>
							</span>
							 <input type="text" id="AdultsRT" class="form-control text-center add_num" name="adults" value="1">
							<span class="input-group-btn">
							<a class="btn add_btn" data-dir="up" onclick="increase_adult_rt()"><i class="fa fa-plus"></i></a>
							</span>
							 </div>
							 </div>
						 </div>
							
							<div class="row_traveler">
								<div class="pass_bx">
									<label>Child <small>(0-17 yrs)</small></label>
								</div>

							 <div class="pass_bx">
							 <div class="input-group number-spinner">
							  <span class="input-group-btn">
							<a class="btn mns_btn" data-dir="dwn" onclick="decrease_child_rt()"><i class="fa fa-minus"></i></a>
							  </span>
							<input type="text" id="ChildrenRT" class="form-control text-center add_num" name="childs" value="0">
							<span class="input-group-btn">
							<a class="btn add_btn" data-dir="up" onclick="increase_child_rt()"><i class="fa fa-plus"></i></a>
							</span>
							</div>
							</div>
							</div>
                           
						   <div class="row_traveler">
								<div class="pass_bx">
									<label> Infant <small>(Upto 2 yrs)</small></label> 
								</div>
							
							 <div class="pass_bx">
							 <div class="input-group number-spinner">
											<span class="input-group-btn">
							<a class="btn mns_btn" data-dir="dwn" onclick="decrease_infant_rt()"><i class="fa fa-minus" ></i></a>
											</span>
											<input type="text" class="form-control text-center add_num" id="InfantsRT" name="infants" value="0">
											<span class="input-group-btn">
							<a class="btn add_btn" data-dir="up" onclick="increase_infant_rt()"><i class="fa fa-plus"></i></a>
											</span>
										</div>
							 </div>			
							</div>
							
							<div class="bncfr_ccrty">
							<h6> Choose Travel Class </h6>
							
							<div class="ffrms_ppd">					
							<div class="form-group" style="margin: 0;">
								<select class="form-control Nhgsdrt" id="classType" name="classType" placeholder="Economy">
									<option selected="selected" value="Y">Economy</option>
									<option value="S"> Premium Economy </option>
									<option value="C"> Business Class </option>
									<option value="F"> First Class </option>
								</select>
							  </div>
							</div>
							</div>

							
						<div class="btn_dn">
							<button type="button" onclick="all_pesenger();" class="btn_done">Done</button>
						</div>

						</div>
               </div>
			  </div>
			  
			  <div class="colum_four">
               <button type="sumit" name="submitForm" class="deals_search_bn"> <i class="fa fa-search"></i> <span>Search</span> </button>
			  </div>
			 </div>
			</div>