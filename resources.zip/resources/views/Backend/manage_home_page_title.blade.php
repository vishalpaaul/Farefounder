@extends('Backend.common.layout')
  @section('pageTitle','Manage Home Page Title')
      
	  
	  
	{{-- sideBar Section Start --}}           
	    @section('sideBar')
	      @include('Backend.common.sidebar')
	    @endsection               
	{{-- sideBar Section End  --}}
	{{-- headerTop Section Start --}} 
		@section('headerTop')
	      @include('Backend.common.header') 
	    @endsection  
	{{-- headerTop Section End  --}}

	{{-- pageContent dashboard Start --}} 
       @section('pageContent')


       {{-- Edit Update/Create Start --}}
        @if(!empty($HomeTitle_edit))
          @php
	        $display_form = '';
			$action=route('manage_home_page_title.update',$HomeTitle_edit['id']);
			$button = 'Update';
            $title_id=$HomeTitle_edit['title_id'];
            $title=$HomeTitle_edit['title'];
            $Description=$HomeTitle_edit['Description'];
            $status=$HomeTitle_edit['status'];
		   @endphp
          @else
            @php
		     $display_form = 'style=display:none;';
			 $action=route('manage_home_page_title.store');
			 $button = 'Submit';
              $title_id='';
              $title='';
              $Description='';
              $status= '';
			 @endphp
        @endif
       {{-- Edit Update/Create End --}}
	   
	   
       		<div class="right_col" role="main">
        
            <div class="page-title">
              <div class="title_left">
                <h3>Manage Home Page Title  
				<div class="flash-message" style="font-size: 14px;float: right;padding: 0 15px;width: 355px;height: 59px;">
       @foreach (['danger', 'warning', 'success', 'info'] as $msg)
         @if(Session::has('alert-' . $msg))

           <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
           </p>
         @endif
      @endforeach
  </div></h3>
				
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel" id="abc" {{$display_form}} >
                  <div class="x_title">
                    <h2> <small>Manage Home Page Title </small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
             <form action="{{ $action }}" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data"> 
			@csrf
      @if(!empty($HomeTitle_edit))
        @method('PUT')
      @endif
             <div class="row">
			 
             <div class="col-md-4 col-sm-12  form-group">
             <label>Select Content Title</label>
             <select id="heard" name="title_id" class="form-control" required>
               <option value="" > Select Content Title </option>
			   <option value="bottom" {{ ('bottom' == $title_id) ? 'selected' : 'bottom' }} {{ ('bottom' == old('title_id')) ? 'selected' : 'bottom'}}> Bottom </option>
			   <option value="Desti" {{ ('Desti' == $title_id) ? 'selected' : 'Desti' }} {{ ('Desti' == old('title_id')) ? 'selected' : 'Desti'}}> Destinations </option>
			   <option value="flightd" {{ ('flightd' == $title_id) ? 'selected' : 'flightd' }} {{ ('flightd' == old('title_id')) ? 'selected' : 'flightd'}}> Flight deals </option>
			   
			   
               </select>
            </div>
			
		     <div class="col-md-4 col-sm-12  form-group">
             <label>Title Name </label>
             <input type="text" name="title" class="form-control" placeholder="Enter Title Name" required value="{{ $title }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('title')}}</p>
             </div>
			 
			 <div class="col-md-4 col-sm-12  form-group">
              <label>Description</label>
              <input type="text" name="Description" class="form-control" placeholder="Description"  value="{{ $Description }}"/>
			  
              </div>
			  
			  </div>
			 <div class="row">
             
			
			 <div class="col-md-4 col-sm-12  form-group">
            
             <label for="heard">Status</label>
                          <select id="heard" name="status" class="form-control" required>
                            <option value="Enabled" {{ ('Enabled' == $status) ? 'selected' : '' }} {{ ('Enabled' == old('status')) ? 'selected' : '' }}>Enabled</option>
                            <option value="Disabled" {{ ('Disabled' == $status) ? 'selected' : '' }} {{ ('Disabled' == old('status')) ? 'selected' : '' }}>Disabled</option>
                           
                          </select>
              </div>
			 
			 
			 </div>
                      
					  
                      
                      
                      <div class="ln_solid"></div>
                      <div class=" form-group">
                        <div class="col-md-6 col-sm-6">
                          
                          <button type="submit" class="btn btn-success">{{$button}}</button>
						  <button class="btn btn-primary" type="reset">Reset</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>
           
          

		     
            <div class="clearfix"></div>

            <div class="row">
             
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title" style="color: white;background-color: #2a3f54;">
                    <h2>Total Home  Page Title = {{$count}} <small></small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
				  
                  <div class="x_content">
				  <button id="sample_editable_1_new" class="btn btn-info">Add New +</button>
                      <div class="row">
					  
                          <div class="col-sm-12">
						  
                            <div class="card-box table-responsive">
                    
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th> Title Name</th>
                          <th>Description</th>
                         <th>Add Date</th>
						  <th>Add By</th>
						  <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>


                      <tbody>
					  {{-- @dd($HomeTitle_show) --}}
                        @foreach($HomeTitle_show as $Managehomepagetitle)
						
						<tr>
                          <td>{{$Managehomepagetitle['title']}}</td>
                          <td>{{$Managehomepagetitle['Description']}}</td>
                          
						  
						@php
						//$dateFromDb=$Managehomepagetitle['created_at'];
						//$dateFromDbDormated=date('d/m/Y',strtotime($dateFromDb));
					    //{{ $dateFromDbDormated }}
						@endphp
						
                          <td>
						  {{$Managehomepagetitle['created_at']}}
						  </td>
                          <td>Admin</td>
						  <td>
                           <label class="switch">
						   
                           <input type="checkbox" @if($Managehomepagetitle['status']=='Enabled')  checked @endif >
						  
						  <span class="slider round"></span>
                           </label>
                          </td>
						  <td style="width: 84px;">
                         
						   <a href="{{route('manage_home_page_title.edit',$Managehomepagetitle['id'])}}" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            <!--<a href="{{url('/manage_home_slider/'.$Managehomepagetitle['id'])}}" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></a>-->
						
							<form method="post" action="{{route('manage_home_page_title.destroy',$Managehomepagetitle['id'])}}" style="display: contents;">@csrf @method('DELETE') 
                            <button type="submit" onclick="return confirm('Are You Wanna delete Permanentely This Record ?')" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i>
                            </button>
                             </form>
                          </td>
                        </tr>
						@endforeach
						
						
						
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>

              

            

              
            </div>
          
        </div>
		@endsection
    {{-- pageContent dashboard End  --}}
    {{-- DataTable dashboard Start  --}}
    	@section('DataTable')
    	
			</pre>
		@endsection
    {{-- DataTable dashboard End    --}}

    {{-- footerBottom Section Start --}}           
      @section('footerBottom')	      
	  	@include('Backend.common.footer')
      @endsection          
    {{-- footerBottom Section End  --}}

    {{-- dataTableScripts scripts start --}}
	    {{-- @pushOnce('scripts') --}}
		    @push('dataTableScripts')
		        
		    @endpush
	    {{-- @endPushOnce --}}
	{{-- dataTableScripts scripts End   --}}

	