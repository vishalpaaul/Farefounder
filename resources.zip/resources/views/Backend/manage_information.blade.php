@extends('Backend.common.layout')
	@section('pageTitle','Manage Information')
      
	  
	  
	{{-- sideBar Section Start --}}           
	    @section('sideBar')
	      @include('Backend.common.sidebar')
	    @endsection               
	{{-- sideBar Section End  --}}
	{{-- headerTop Section Start --}} 
		@section('headerTop')
	      @include('Backend.common.header') 
	    @endsection  
	{{-- headerTop Section End  --}}

	{{-- pageContent dashboard Start --}} 
       @section('pageContent')


       {{-- Edit Update/Create Start --}}
        @if(!empty($manage_information_edit))
          @php
	        $display_form = '';
			$action=route('manage_information.update',$manage_information_edit['id']);
			$button = 'Update';
            $pages_id=$manage_information_edit['pages_id'];
            $title_name=$manage_information_edit['title_name'];
            $sub_title=$manage_information_edit['sub_title'];
            $discription=$manage_information_edit['discription'];
            $status=$manage_information_edit['status'];
		    $airline_image=$manage_information_edit['airline_image'];
          @endphp
          @else
            @php
		     $display_form = 'style=display:none;';
			 $action=route('manage_information.store');
			 $button = 'Submit';
              $pages_id='';
              $title_name='';
              $sub_title='';
              $discription='';
              $status= '';
			  $airline_image= '';
            @endphp
        @endif
       {{-- Edit Update/Create End --}}
	   
	   
       		<div class="right_col" role="main">
        
            <div class="page-title">
              <div class="title_left">
                <h3>Manage Information  
				<div class="flash-message" style="font-size: 14px;float: right;padding: 0 15px;width: 355px;height: 59px;">
       @foreach (['danger', 'warning', 'success', 'info'] as $msg)
         @if(Session::has('alert-' . $msg))

           <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
           </p>
         @endif
      @endforeach
  </div></h3>
				
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel" id="abc" {{$display_form}} >
                  <div class="x_title">
                    <h2> <small>Manage Information </small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
             <form action="{{ $action }}" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data"> 
			@csrf
      @if(!empty($manage_information_edit))
        @method('PUT')
      @endif
             <div class="row">
			 <div class="col-md-4 col-sm-12  form-group">
            
             <label for="heard">Select Page Name</label>
                        <select id="heard" name="pages_id" class="form-control" required>
                        <option >Select Page</option>
					
	@php
	use App\Models\Managepagesinformation;
    $pagesname = Managepagesinformation::where('delete_status', 1)->where('status', 'Enabled')->get()->toArray();
   @endphp

    @foreach ($pagesname as $page)
    <option value="{{ $page['id'] }}" 
        {{ old('pages_id', $pages_id) == $page['id'] ? 'selected' : '' }}>
        {{ $page['page_name'] }}
    </option>
    @endforeach 
     </select>
              </div>
             <div class="col-md-4 col-sm-12  form-group">
             <label>Title Name</label>
            <input type="text" name="title_name" value="{{ $title_name }}" class="form-control" placeholder="Enter Title Name" required />
			@if($errors->has('title_name'))   
			<p class="help-block" style="color: #df4949;">{{$errors->first('title_name')}}</p>
			@endif
            </div>
			
		     <div class="col-md-4 col-sm-12  form-group">
             <label>Sub Title</label>
             <input type="text" name="sub_title" class="form-control" placeholder="Enter Sub Title" required value="{{ $sub_title }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('sub_title')}}</p>
             </div>
			 
			 
			  
			  </div>
			   <div class="row">
			   <div class="col-md-12 col-sm-12  form-group">
              <label>Description Name</label>
               <textarea type="text" name="discription" placeholder="page description" id="editor">{{ $discription }}</textarea>
                  
			  <p class="help-block" style="color: #df4949;">{{$errors->first('discription')}}</p>
              </div>
			   </div>
			 
			
			  
			 <div class="row">
             <div class="col-md-4 col-sm-12  form-group">
			 <br>
			 <div class="form-group">
    @php
        $airline_image_OP = $airline_image == '' ? old('airline_image') : $airline_image;
        $current_image = $airline_image ? asset('public/images/'.$airline_image) : asset('public/images/no_image.png');
    @endphp
	<label for="airline_image">Select Slider Image</label>

    <div class="mt-3">
        <img id="imagePreview" src="{{ $current_image }}" alt="Preview" class="img-thumbnail" 
             style="max-width: 200px; max-height: 150px;">
    </div>

    <button type="button" class="btn btn-primary mt-2" onclick="document.getElementById('airline_image').click();">
        Select Image
    </button>
    <button type="button" class="btn btn-danger mt-2" id="removeImage" style="display: none;">Remove</button>
    <input type="file" class="d-none" id="airline_image" name="airline_image" onchange="previewImage(event)">
</div>
             </div>
			 <div class="col-md-4 col-sm-12  form-group">
            
             <label for="heard">Status</label>
                          <select id="heard" name="status" class="form-control" required>
                            <option value="Enabled" {{ ('Enabled' == $status) ? 'selected' : '' }} {{ ('Enabled' == old('status')) ? 'selected' : '' }}>Enabled</option>
                            <option value="Disabled" {{ ('Disabled' == $status) ? 'selected' : '' }} {{ ('Disabled' == old('status')) ? 'selected' : '' }}>Disabled</option>
                           
                          </select>
              </div>
			<!--<div class="form-group">
                        <label class="col-sm-3 control-label"> Image</label>
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                <div class="input-group">
                                    <div class="form-control uneditable-input" data-trigger="fileinput">
                                        <i class="glyphicon glyphicon-file fileinput-exists"></i>
                                        <span class="fileinput-filename"></span>
                                    </div>
                                    <span class="input-group-addon btn btn-default btn-file">
                                        <span class="fileinput-new">Select Image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="airline_image">
                                    </span>
                                    <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
                                    @error('airline_image')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
							
                            
                    </div>-->
			 
			 
			 
			 
			 </div>
                      
					  
                      
                      
                      <div class="ln_solid"></div>
                      <div class=" form-group">
                        <div class="col-md-6 col-sm-6">
                          
                          <button type="submit" class="btn btn-success">{{$button}}</button>
						  <button class="btn btn-primary" type="reset">Reset</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>
           
          

		     
            <div class="clearfix"></div>

            <div class="row">
             
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title" style="color: white;background-color: #2a3f54;">
                    <h2>Total Manage Information = {{$count}} <small></small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
				  
                  <div class="x_content">
				  <button id="sample_editable_1_new" class="btn btn-info">Add New +</button>
                      <div class="row">
					  
                          <div class="col-sm-12">
						  
                            <div class="card-box table-responsive">
                    
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Page Name</th>
						  <th>Title Name </th>
	                      <th>Sub Title Name </th>
			              <th>Discription</th>
						  <th>Slider Image</th>
                          <th>Add Date</th>
						  <th>Add By</th>
						  <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>


                      <tbody>
					  {{-- @dd($Manageinformation_show) --}}
                 @php
$Manageinformation_show =\App\Models\Manageinformation::select('tb_manage_information.*', 'tb_information_page.page_name as page_name') ->join('tb_information_page', 'tb_manage_information.pages_id', '=','tb_information_page.id')->where('tb_manage_information.delete_status',1)->orderByDesc('tb_manage_information.id')->get();
@endphp

					  @foreach ($Manageinformation_show as $info)
						
						 <tr>
                          <td>{{$info['page_name']}}</td>
                          <td>{{$info['title_name']}}</td>
                          <td>{{$info['sub_title']}}</td>
                          <td>{!!$info['discription']!!}</td>
                          <!--<td><img src="{{ asset('public/Backend_assets/images/img.jpg') }}" width="70px" height="70px" ></td>-->
                          <!--<td><img src="{{url(($info['airline_image']))}}" width="70px" height="70px" ></td>-->
						  <td><img src="{{ asset('public/images/'.$info['airline_image'] )}}" width="70px" height="70px" ></td>
						  
						@php
						//$dateFromDb=$info['created_at'];
						//$dateFromDbDormated=date('d/m/Y',strtotime($dateFromDb));
					    //{{ $dateFromDbDormated }}
						@endphp
						
                          <td>
						  {{$info['created_at']}}
						  </td>
                          <td>Admin</td>
						  <td>
                           <label class="switch">
						   
                           <input type="checkbox" @if($info['status']=='Enabled')  checked @endif >
						  
						  <span class="slider round"></span>
                           </label>
                          </td>
						  <td style="width: 84px;">
						  {{--@dd($info)--}}
						   <a href="{{route('manage_information.edit',$info['id'])}}" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            
						
							<form method="post" action="{{route('manage_information.destroy',$info['id'])}}" style="display: contents;">@csrf @method('DELETE') 
                            <button type="submit" onclick="return confirm('Are You Wanna delete Permanentely This Record ?')" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i>
                            </button>
                             </form>
                          </td>
                        </tr>
						@endforeach
						
						
						
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>

              

            

              
            </div>
          
        </div>
		@endsection
    {{-- pageContent dashboard End  --}}
    {{-- DataTable dashboard Start  --}}
    	@section('DataTable')
    	
			</pre>
		@endsection
    {{-- DataTable dashboard End    --}}

    {{-- footerBottom Section Start --}}           
      @section('footerBottom')	      
	  	@include('Backend.common.footer')
      @endsection          
    {{-- footerBottom Section End  --}}

    {{-- dataTableScripts scripts start --}}
	    {{-- @pushOnce('scripts') --}}
		    @push('dataTableScripts')
		        
		    @endpush
	    {{-- @endPushOnce --}}
	{{-- dataTableScripts scripts End   --}}

	