@extends('Backend.common.layout')
	@section('pageTitle','Change password')
      
	  
	  
	{{-- sideBar Section Start --}}           
	    @section('sideBar')
	      @include('Backend.common.sidebar')
	    @endsection               
	{{-- sideBar Section End  --}}
	{{-- headerTop Section Start --}} 
		@section('headerTop')
	      @include('Backend.common.header') 
	    @endsection  
	{{-- headerTop Section End  --}}

	{{-- pageContent dashboard Start --}} 
       @section('pageContent')


       
	   
       		<div class="right_col" role="main">
       
        
            <div class="clearfix"></div>
            <div class="row">
			
              <div class="col-md-12 col-sm-12 ">
			   @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
                <div class="x_panel" id="abc" >
                  <div class="x_title">
                    <h2> <small>Change Password </small>  </h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
				@foreach ($Changepassword_show as $item)	
             <form action="{{route('change_password.update', $item->id) }}" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left"> 
			 @endforeach
			 @csrf
            @method('PUT')
             <div class="row">
			 
             <div class="col-md-4 col-sm-12  form-group">
             <label>Current Password</label>
            <input type="text" name="current_password" value="" class="form-control" placeholder="Enter Old Password" required />
			</div>
			</div>
			<br>
			 <div class="row">
			 
             <div class="col-md-4 col-sm-12  form-group">
             <label>New Password</label>
            <input type="text" name="password" value="" class="form-control" placeholder="Enter New Password" required />
			</div>
			</div>  
<br>			
			<div class="row">
			 
             <div class="col-md-4 col-sm-12  form-group">
             <label>Confirm Password</label>
            <input type="text" name="password_confirmation" value="" class="form-control" placeholder="Enter confirm Password" required />
			</div>
			</div> 		  
                      
                      
                      <div class="ln_solid"></div>
                      <div class=" form-group">
                        <div class="col-md-6 col-sm-6">
                          
                          <button type="submit" class="btn btn-success">submit</button>
						 
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>
           <br>	<br>	
          

		     
          

            
          
        </div>
		
		@endsection
    {{-- pageContent dashboard End  --}}
    {{-- DataTable dashboard Start  --}}
    	@section('DataTable')
    	
			</pre>
		@endsection
    {{-- DataTable dashboard End    --}}

    {{-- footerBottom Section Start --}}           
      @section('footerBottom')	      
	  	@include('Backend.common.footer')
      @endsection          
    {{-- footerBottom Section End  --}}

    {{-- dataTableScripts scripts start --}}
	    {{-- @pushOnce('scripts') --}}
		    @push('dataTableScripts')
		        
		    @endpush
	    {{-- @endPushOnce --}}
	{{-- dataTableScripts scripts End   --}}

	