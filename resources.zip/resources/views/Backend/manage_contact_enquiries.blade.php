@extends('Backend.common.layout')
	@section('pageTitle','Manage Contact Enquiries
')
      
	  
	  
	{{-- sideBar Section Start --}}           
	    @section('sideBar')
	      @include('Backend.common.sidebar')
	    @endsection               
	{{-- sideBar Section End  --}}
	{{-- headerTop Section Start --}} 
		@section('headerTop')
	      @include('Backend.common.header') 
	    @endsection  
	{{-- headerTop Section End  --}}

	{{-- pageContent dashboard Start --}} 
       @section('pageContent')


       {{-- Edit Update/Create Start --}}
        @if(!empty($manage_contact_enquiries_edit))
          @php
	        $display_form = '';
			$action=route('manage_contact_enquiries.update',$manage_contact_enquiries_edit['id']);
		
			$button = 'Update';
            
            $name=$manage_contact_enquiries_edit['name'];
            $phone=$manage_contact_enquiries_edit['phone'];
            $email=$manage_contact_enquiries_edit['email'];
            $message=$manage_contact_enquiries_edit['message'];
            $status=$manage_contact_enquiries_edit['status'];
		    
          @endphp
          @else
            @php
		     $display_form = 'style=display:none;';
			 $action=route('manage_contact_enquiries.store');
			 $button = 'Submit';
              $id='';
              $name='';
              $phone='';
              $email='';
              $message='';
              $status= '';
			 
            @endphp
        @endif
       {{-- Edit Update/Create End --}}
	   
	   
       		<div class="right_col" role="main">
        
            <div class="page-title">
              <div class="title_left">
                <h3>Manage Contact Enquiries  
				<div class="flash-message" style="font-size: 14px;float: right;padding: 0 15px;width: 355px;height: 59px;">
       @foreach (['danger', 'warning', 'success', 'info'] as $msg)
         @if(Session::has('alert-' . $msg))

           <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
           </p>
         @endif
      @endforeach
  </div></h3>
				
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel" id="abc" {{$display_form}} >
                  <div class="x_title">
                    <h2> <small>Manage Contact Enquiries </small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
             <form action="{{ $action }}" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data"> 
			@csrf
      @if(!empty($manage_contact_enquiries_edit))
        @method('PUT')
      @endif
             <div class="row">
			 
             <div class="col-md-4 col-sm-12  form-group">
             <label>Name</label>
            <input type="text" name="name" value="{{ $name }}" class="form-control" placeholder="Enter Name" required />
			@if($errors->has('name'))   
			<p class="help-block" style="color: #df4949;">{{$errors->first('name')}}</p>
			@endif
            </div>
			
		     <div class="col-md-4 col-sm-12  form-group">
             <label>phone</label>
             <input type="text" name="phone" class="form-control" placeholder="Enter phone" required value="{{ $phone }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('phone')}}</p>
             </div>
			 <div class="col-md-4 col-sm-12  form-group">
             <label>email</label>
             <input type="text" name="email" class="form-control" placeholder="Enter email" required value="{{ $email }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('email')}}</p>
             </div>
			 
			  
			  </div>
			   <div class="row">
			   <div class="col-md-12 col-sm-12  form-group">
              <label>message</label>
               <textarea type="text" name="message" placeholder="message" id="editor">{{ $message }}</textarea>
                  
			  <p class="help-block" style="color: #df4949;">{{$errors->first('message')}}</p>
              </div>
			   </div>
			 
			
			  
			 <div class="row">
            
			 <div class="col-md-4 col-sm-12  form-group">
            
             <label for="heard">Status</label>
                          <select id="heard" name="status" class="form-control" required>
                            <option value="Enabled" {{ ('Enabled' == $status) ? 'selected' : '' }} {{ ('Enabled' == old('status')) ? 'selected' : '' }}>Enabled</option>
                            <option value="Disabled" {{ ('Disabled' == $status) ? 'selected' : '' }} {{ ('Disabled' == old('status')) ? 'selected' : '' }}>Disabled</option>
                           
                          </select>
              </div>
			<!--<div class="form-group">
                        <label class="col-sm-3 control-label"> Image</label>
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                <div class="input-group">
                                    <div class="form-control uneditable-input" data-trigger="fileinput">
                                        <i class="glyphicon glyphicon-file fileinput-exists"></i>
                                        <span class="fileinput-filename"></span>
                                    </div>
                                    <span class="input-group-addon btn btn-default btn-file">
                                        <span class="fileinput-new">Select Image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="airline_image">
                                    </span>
                                    <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
                                    @error('airline_image')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
							
                            
                    </div>-->
			 
			 
			 
			 
			 </div>
                      
					  
                      
                      
                      <div class="ln_solid"></div>
                      <div class=" form-group">
                        <div class="col-md-6 col-sm-6">
                          
                          <button type="submit" class="btn btn-success">{{$button}}</button>
						  <button class="btn btn-primary" type="reset">Reset</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>
           
          

		     
            <div class="clearfix"></div>

            <div class="row">
             
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title" style="color: white;background-color: #2a3f54;">
                    <h2>Total Manage Contact Enquiries  = {{$count}} <small></small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
				  
                  <div class="x_content">
				  <!--<button id="sample_editable_1_new" class="btn btn-info">Add New +</button>-->
                      <div class="row">
					  
                          <div class="col-sm-12">
						  
                            <div class="card-box table-responsive">
                    
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Name</th>
						  <th>Phone </th>
	                      <th>E-mail </th>
			              <th>Message</th>
						  <th>Add Date</th>
						  <th>Add By</th>
						  <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>


                      <tbody>
					  {{-- @dd($Managecontactenquiries_show) --}}
                        @foreach($Managecontactenquiries_show as $Managecontactenquiries)
						
						<tr>
                          
                          <td>{{$Managecontactenquiries['name']}}
						  </td>
                          <td>{{$Managecontactenquiries['phone']}}</td>
                          <td>{!!$Managecontactenquiries['email']!!}</td>
                          <td>{!!$Managecontactenquiries['message']!!}</td>
                          
						  
						  
						@php
						//$dateFromDb=$Managecontactenquiries['created_at'];
						//$dateFromDbDormated=date('d/m/Y',strtotime($dateFromDb));
					    //{{ $dateFromDbDormated }}
						@endphp
						
                          <td>
						  {{$Managecontactenquiries['created_at']}}
						  </td>
                          <td>Admin</td>
						  <td>
                           <label class="switch">
						   
                           <input type="checkbox" @if($Managecontactenquiries['status']=='Enabled')  checked @endif >
						  
						  <span class="slider round"></span>
                           </label>
                          </td>
						  <td style="width: 84px;">
						  {{--@dd($Managecontactenquiries)--}}
						   <!--<a href="{{route('manage_contact_enquiries.edit',$Managecontactenquiries['id'])}}" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>-->
                            
						
							<form method="post" action="{{route('manage_contact_enquiries.destroy',$Managecontactenquiries['id'])}}" style="display: contents;">@csrf @method('DELETE') 
                            <button type="submit" onclick="return confirm('Are You Wanna delete Permanentely This Record ?')" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i>
                            </button>
                             </form>
                          </td>
                        </tr>
						@endforeach
						
						
						
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>

              

            

              
            </div>
          
        </div>
		@endsection
    {{-- pageContent dashboard End  --}}
    {{-- DataTable dashboard Start  --}}
    	@section('DataTable')
    	
			</pre>
		@endsection
    {{-- DataTable dashboard End    --}}

    {{-- footerBottom Section Start --}}           
      @section('footerBottom')	      
	  	@include('Backend.common.footer')
      @endsection          
    {{-- footerBottom Section End  --}}

    {{-- dataTableScripts scripts start --}}
	    {{-- @pushOnce('scripts') --}}
		    @push('dataTableScripts')
		        
		    @endpush
	    {{-- @endPushOnce --}}
	{{-- dataTableScripts scripts End   --}}

	