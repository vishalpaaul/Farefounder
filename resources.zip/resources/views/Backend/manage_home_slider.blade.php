@extends('Backend.common.layout')
	@section('pageTitle','Manage Home Slider Images')
      
	  
	  
	{{-- sideBar Section Start --}}           
	    @section('sideBar')
	      @include('Backend.common.sidebar')
	    @endsection               
	{{-- sideBar Section End  --}}
	{{-- headerTop Section Start --}} 
		@section('headerTop')
	      @include('Backend.common.header') 
	    @endsection  
	{{-- headerTop Section End  --}}

	{{-- pageContent dashboard Start --}} 
       @section('pageContent')


       {{-- Edit Update/Create Start --}}
        @if(!empty($HomeSlider_edit))
          @php
	        $display_form = '';
			$action=route('manage_home_slider.update',$HomeSlider_edit['id']);
			$button = 'Update';
            $title_1=$HomeSlider_edit['title_1'];
            $title_2=$HomeSlider_edit['title_2'];
            $title_3=$HomeSlider_edit['title_3'];
            $status=$HomeSlider_edit['status'];
		    $airline_image=$HomeSlider_edit['airline_image'];
          @endphp
          @else
            @php
		     $display_form = 'style=display:none;';
			 $action=route('manage_home_slider.store');
			 $button = 'Submit';
              $title_1='';
              $title_2='';
              $title_3='';
              $status= '';
			  $airline_image= '';
            @endphp
        @endif
       {{-- Edit Update/Create End --}}
	   
	   
       		<div class="right_col" role="main">
        
            <div class="page-title">
              <div class="title_left">
                <h3>Manage Home Slider Images  
				<div class="flash-message" style="font-size: 14px;float: right;padding: 0 15px;width: 355px;height: 59px;">
       @foreach (['danger', 'warning', 'success', 'info'] as $msg)
         @if(Session::has('alert-' . $msg))

           <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
           </p>
         @endif
      @endforeach
  </div></h3>
				
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel" id="abc" {{$display_form}} >
                  <div class="x_title">
                    <h2> <small>Manage Home Slider Images </small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
             <form action="{{ $action }}" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data"> 
			@csrf
      @if(!empty($HomeSlider_edit))
        @method('PUT')
      @endif
             <div class="row">
			 
             <div class="col-md-4 col-sm-12  form-group">
             <label>Title Name 1</label>
            <input type="text" name="title_1" value="{{ $title_1 }}" class="form-control" placeholder="Enter Title 1" required />
			@if($errors->has('title_1'))   
			<p class="help-block" style="color: #df4949;">{{$errors->first('title_1')}}</p>
			@endif
            </div>
			
		     <div class="col-md-4 col-sm-12  form-group">
             <label>Title Name 2</label>
             <input type="text" name="title_2" class="form-control" placeholder="Enter Title 2" required value="{{ $title_2 }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('title_2')}}</p>
             </div>
			 
			 <div class="col-md-4 col-sm-12  form-group">
              <label>Title Name 3</label>
              <input type="text" name="title_3" class="form-control" placeholder="Enter Title 3" required value="{{ $title_3 }}"/>
			  <p class="help-block" style="color: #df4949;">{{$errors->first('title_3')}}</p>
              </div>
			  
			  </div>
			 <div class="row">
             <div class="col-md-4 col-sm-12 form-group">
             <div class="form-group">
    @php
        $airline_image_OP = $airline_image == '' ? old('airline_image') : $airline_image;
        $current_image = $airline_image ? asset('public/images/'.$airline_image) : asset('public/images/no_image.png');
    @endphp
	<label for="airline_image">Select Slider Image</label>

    <div class="mt-3">
        <img id="imagePreview" src="{{ $current_image }}" alt="Preview" class="img-thumbnail" 
             style="max-width: 200px; max-height: 150px;">
    </div>

    <button type="button" class="btn btn-primary mt-2" onclick="document.getElementById('airline_image').click();" style="line-height: normal;">
        Select Image
    </button>
   <button type="button" class="btn btn-danger mt-2" id="removeImage" style="display: none; line-height: normal;" >Remove</button>
    <input type="file" class="d-none" id="airline_image" name="airline_image" onchange="previewImage(event)">
</div>

  </div>
			<!--<div class="form-group">
                        <label class="col-sm-3 control-label"> Image</label>
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                <div class="input-group">
                                    <div class="form-control uneditable-input" data-trigger="fileinput">
                                        <i class="glyphicon glyphicon-file fileinput-exists"></i>
                                        <span class="fileinput-filename"></span>
                                    </div>
                                    <span class="input-group-addon btn btn-default btn-file">
                                        <span class="fileinput-new">Select Image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="airline_image">
                                    </span>
                                    <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
                                    @error('airline_image')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
							
                            
                    </div>-->
			 
			 <div class="col-md-4 col-sm-12  form-group">
            
             <label for="heard">Status</label>
                          <select id="heard" name="status" class="form-control" required>
                            <option value="Enabled" {{ ('Enabled' == $status) ? 'selected' : '' }} {{ ('Enabled' == old('status')) ? 'selected' : '' }}>Enabled</option>
                            <option value="Disabled" {{ ('Disabled' == $status) ? 'selected' : '' }} {{ ('Disabled' == old('status')) ? 'selected' : '' }}>Disabled</option>
                           
                          </select>
              </div>
			 
			 
			 </div>
                      
					  
                      
                      
                      <div class="ln_solid"></div>
                      <div class=" form-group">
                        <div class="col-md-6 col-sm-6">
                          
                          <button type="submit" class="btn btn-success">{{$button}}</button>
						  <button class="btn btn-primary" type="reset">Reset</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>
           
          

		     
            <div class="clearfix"></div>

            <div class="row">
             
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title" style="color: white;background-color: #2a3f54;">
                    <h2>Total Slider Images = {{$count}} <small></small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
				  
                  <div class="x_content">
				  <button id="sample_editable_1_new" class="btn btn-info">Add New +</button>
                      <div class="row">
					  
                          <div class="col-sm-12">
						  
                            <div class="card-box table-responsive">
                    
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Title Name 1</th>
                          <th>Title Name 2</th>
                          <th>Title Name 3</th>
                          <th>Slider Image</th>
                          <th>Add Date</th>
						  <th>Add By</th>
						  <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>


                      <tbody>
					  {{-- @dd($HomeSlider_show) --}}
                        @foreach($HomeSlider_show as $HomeSlider)
						
						<tr>
                          <td>{{$HomeSlider['title_1']}}</td>
                          <td>{{$HomeSlider['title_2']}}</td>
                          <td>{{$HomeSlider['title_3']}}</td>
                          <!--<td><img src="{{ asset('public/Backend_assets/images/img.jpg') }}" width="70px" height="70px" ></td>-->
                          <!--<td><img src="{{url(($HomeSlider['airline_image']))}}" width="70px" height="70px" ></td>-->
						  <td><img src="{{ asset('public/images/'.$HomeSlider['airline_image'] )}}" width="70px" height="70px" ></td>
						  
						@php
						//$dateFromDb=$HomeSlider['created_at'];
						//$dateFromDbDormated=date('d/m/Y',strtotime($dateFromDb));
					    //{{ $dateFromDbDormated }}
						@endphp
						
                          <td>
						  {{$HomeSlider['created_at']}}
						  </td>
                          <td>Admin</td>
						  <td>
                           <label class="switch">
						   
                           <input type="checkbox" @if($HomeSlider['status']=='Enabled')  checked @endif >
						  
						  <span class="slider round"></span>
                           </label>
                          </td>
						  <td style="width: 84px;">
                         
						   <a href="{{route('manage_home_slider.edit',$HomeSlider['id'])}}" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            <!--<a href="{{url('/manage_home_slider/'.$HomeSlider['id'])}}" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></a>-->
						
							<form method="post" action="{{route('manage_home_slider.destroy',$HomeSlider['id'])}}" style="display: contents;">@csrf @method('DELETE') 
                            <button type="submit" onclick="return confirm('Are You Wanna delete Permanentely This Record ?')" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i>
                            </button>
                             </form>
                          </td>
                        </tr>
						@endforeach
						
						
						
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>

              

            

              
            </div>
          
        </div>
		@endsection
    {{-- pageContent dashboard End  --}}
    {{-- DataTable dashboard Start  --}}
    	@section('DataTable')
    	
			</pre>
		@endsection
    {{-- DataTable dashboard End    --}}

    {{-- footerBottom Section Start --}}           
      @section('footerBottom')	      
	  	@include('Backend.common.footer')
      @endsection          
    {{-- footerBottom Section End  --}}

    {{-- dataTableScripts scripts start --}}
	    {{-- @pushOnce('scripts') --}}
		    @push('dataTableScripts')
		        
		    @endpush
	    {{-- @endPushOnce --}}
	{{-- dataTableScripts scripts End   --}}

	