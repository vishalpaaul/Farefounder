@extends('Lara_admin.common.layout')
	@section('pageTitle','Manage Home Slider Images')
	@php
		$action=route('HomeSlider.store');
	@endphp

	{{-- sideBar Section Start --}}           
	    @section('sideBar')
	      @include('Lara_admin.common.sidebar')
	    @endsection               
	{{-- sideBar Section End  --}}
	{{-- headerTop Section Start --}} 
		@section('headerTop')
	      @include('Lara_admin.common.header') 
	    @endsection  
	{{-- headerTop Section End  --}}

	{{-- pageContent dashboard Start --}}
       @section('pageContent')
       		<div class="right_col" role="main">
        
            <div class="page-title">
              <div class="title_left">
                <h3>Manage Home Slider Images  
				<div class="flash-message" style="font-size: 14px;float: right;padding: 0 15px;width: 355px;">
       @foreach (['danger', 'warning', 'success', 'info'] as $msg)
         @if(Session::has('alert-' . $msg))

           <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
           </p>
         @endif
      @endforeach
  </div></h3>
				
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel" id="abc" style="display:none" >
                  <div class="x_title">
                    <h2> <small>Manage Home Slider Images </small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
             <form action="{{ $action }}" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
			@csrf
             <div class="row">
			 
             <div class="col-md-4 col-sm-12  form-group">
             <label>Title Name 1</label>
            <input type="text" name="title_1"  class="form-control" placeholder="Enter Title 1" required>
            </div>
			
		     <div class="col-md-4 col-sm-12  form-group">
             <label>Title Name 2</label>
             <input type="text" name="title_2" class="form-control" placeholder="Enter Title 2" required>
             </div>
			 
			 <div class="col-md-4 col-sm-12  form-group">
              <label>Title Name 3</label>
              <input type="text" name="title_3" class="form-control" placeholder="Enter Title 3" required>
              </div>
			  
			  </div>
			 <!--<div class="row">
             <div class="col-md-4 col-sm-12  form-group">
             <label>Select Slider Image</label>
             
<input type="file" name="airline_image" data-role="magic-overlay" data-target="#pictureBtn" data-edit="insertImage">
             </div>
			 
			 
			 <div class="col-md-4 col-sm-12  form-group">
            
             <label for="heard">Status</label>
                          <select id="heard" class="form-control" required>
                            <option value="Enabled">Enabled</option>
                            <option value="Disabled">Disabled</option>
                           
                          </select>
              </div>
			 
			 
			 </div>-->
                      
					  
                      
                      
                      <div class="ln_solid"></div>
                      <div class=" form-group">
                        <div class="col-md-6 col-sm-6">
                          
                          <button type="submit" class="btn btn-success">Submit</button>
						  <button class="btn btn-primary" type="reset">Reset</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>
           
          

		     
            <div class="clearfix"></div>

            <div class="row">
             

              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title" style="color: white;background-color: #2a3f54;">
                    <h2>Total Slider Images=3 <small></small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
				  
                  <div class="x_content">
				  <button id="sample_editable_1_new" class="btn btn-info">Add New +</button>
                      <div class="row">
					  
                          <div class="col-sm-12">
						  
                            <div class="card-box table-responsive">
                    
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Title Name 1</th>
                          <th>Title Name 2</th>
                          <th>Title Name 3</th>
                          <th>Slider Image</th>
                          <th>Add Date</th>
						  <th>Add By</th>
						  <!--<th>Status</th>-->
                          <th>Action</th>
                        </tr>
                      </thead>


                      <tbody>
                        <tr>
                          <td>Tiger Nixon</td>
                          <td>System Architect</td>
                          <td>Edinburgh</td>
                          <td><img src="{{ asset('public/Lara_admin_assets/images/img.jpg') }}" width="70px" height="70px" ></td>
                          <td>2011/04/25</td>
                          <td>Admin</td>
						  
						  <td>
                           <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></a>
                          </td>
                        </tr>
						
						<tr>
                          <td>Tiger Nixon</td>
                          <td>System Architect</td>
                          <td>Edinburgh</td>
                          <td><img src="{{ asset('public/Lara_admin_assets/images/img.jpg') }}" width="70px" height="70px" ></td>
                          <td>2011/04/25</td>
                            <td>Admin</td>
						  <td>
                           <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></a>
                          </td>
                        </tr>
						
						<tr>
                          <td>Tiger Nixon</td>
                          <td>System Architect</td>
                          <td>Edinburgh</td>
                          <td><img src="{{ asset('public/Lara_admin_assets/images/img.jpg') }}" width="70px" height="70px" ></td>
                          <td>2011/04/25</td>
                            <td>Admin</td>
						  <td>
                           <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></a>
                          </td>
                        </tr>
						
						<tr>
                          <td>Tiger Nixon</td>
                          <td>System Architect</td>
                          <td>Edinburgh</td>
                         <td><img src="{{ asset('public/Lara_admin_assets/images/img.jpg') }}" width="70px" height="70px" ></td>
                          <td>2011/04/25</td>
                            <td>Admin</td>
						  <td>
                           <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></a>
                          </td>
                        </tr>
						
						<tr>
                          <td>Tiger Nixon</td>
                          <td>System Architect</td>
                          <td>Edinburgh</td>
                          <td><img src="{{ asset('public/Lara_admin_assets/images/img.jpg') }}" width="70px" height="70px" ></td>
                          <td>2011/04/25</td>
                            <td>Admin</td>
						  <td>
                           <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></a>
                          </td>
                        </tr>
						
						<tr>
                          <td>Tiger Nixon</td>
                          <td>System Architect</td>
                          <td>Edinburgh</td>
                          <td><img src="{{ asset('public/Lara_admin_assets/images/img.jpg') }}" width="70px" height="70px" ></td>
                          <td>2011/04/25</td>
                            <td>Admin</td>
						  <td>
                           <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></a>
                          </td>
                        </tr>
						
						<tr>
                          <td>Tiger Nixon</td>
                          <td>System Architect</td>
                          <td>Edinburgh</td>
                           <td><img src="{{ asset('public/Lara_admin_assets/images/img.jpg') }}" width="70px" height="70px" ></td>
                          <td>2011/04/25</td>
                            <td>Admin</td>
						  <td>
                           <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></a>
                          </td>
                        </tr>
						
						<tr>
                          <td>Tiger Nixon</td>
                          <td>System Architect</td>
                          <td>Edinburgh</td>
                          <td><img src="{{ asset('public/Lara_admin_assets/images/img.jpg') }}" width="70px" height="70px" ></td>
                          <td>2011/04/25</td>
                            <td>Admin</td>
						  <td>
                           <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></a>
                          </td>
                        </tr>
						
						<tr>
                          <td>Tiger Nixon</td>
                          <td>System Architect</td>
                          <td>Edinburgh</td>
                          <td><img src="{{ asset('public/Lara_admin_assets/images/img.jpg') }}" width="70px" height="70px" ></td>
                          <td>2011/04/25</td>
                            <td>Admin</td>
						  <td>
                           <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></a>
                          </td>
                        </tr>
                        <tr>
                          <td>Tiger Nixon</td>
                          <td>System Architect</td>
                          <td>Edinburgh</td>
                          <td><img src="{{ asset('public/Lara_admin_assets/images/img.jpg') }}" width="70px" height="70px" ></td>
                          <td>2011/04/25</td>
                            <td>Admin</td>
						  <td>
                           <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></a>
                          </td>
                        </tr>
						<tr>
                          <td>Tiger Nixon</td>
                          <td>System Architect</td>
                          <td>Edinburgh</td>
                          <td><img src="{{ asset('public/Lara_admin_assets/images/img.jpg') }}" width="70px" height="70px" ></td>
                          <td>2011/04/25</td>
                            <td>Admin</td>
						  <td>
                           <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></a>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>

              

            

              
            </div>
          
        </div>
		@endsection
    {{-- pageContent dashboard End  --}}
    {{-- DataTable dashboard Start  --}}
    	@section('DataTable')
    	
			</pre>
		@endsection
    {{-- DataTable dashboard End    --}}

    {{-- footerBottom Section Start --}}           
      @section('footerBottom')	      
	  	@include('Lara_admin.common.footer')
      @endsection          
    {{-- footerBottom Section End  --}}

    {{-- dataTableScripts scripts start --}}
	    {{-- @pushOnce('scripts') --}}
		    @push('dataTableScripts')
		        
		    @endpush
	    {{-- @endPushOnce --}}
	{{-- dataTableScripts scripts End   --}}

	