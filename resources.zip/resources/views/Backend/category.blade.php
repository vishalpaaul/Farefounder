@extends('Backend.common.layout')
  @section('pageTitle','Manage Category')
  {{-- Edit Update/Create Start --}}
      @php
        $Crud_page_title="Manage Category";
        $add_btn_action=route('Category.create');
      @endphp
      @if(!empty($data_edit))
        @php
          $display_form = '';
          $action=route('Category.update',$data_edit->id);
          $button = 'Update';
          $category_name=$data_edit->category_name;
          $description=$data_edit->description;
        @endphp
        @else
          @php
            $display_form = 'style=display:none;';
            $action=route('Category.store');
            $button = 'Submit';
            $category_name='';
            $description='';
          @endphp
      @endif
  {{-- Edit Update/Create End --}}
  {{-- sideBar Section Start --}}           
      @section('sideBar')
        @include('Backend.common.sidebar')
      @endsection               
  {{-- sideBar Section End  --}}
  {{-- headerTop Section Start --}} 
    @section('headerTop')
      @include('Backend.common.header') 
    @endsection  
  {{-- headerTop Section End  --}}
  {{-- pageContent dashboard Start --}}
     @section('pageContent')
      <div class="right_col" role="main">
        <div class="page-title">
          <div class="title_left">
            <h3>{{ $Crud_page_title }} </h3>
            {{--
              <div class="flash-message" style="font-size: 14px;float: right;padding: 0 15px;width: 355px;height: 59px;">
                   @foreach (['danger', 'warning', 'success', 'info'] as $msg)
                     @if(Session::has('alert-' . $msg))

                       <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                       </p>
                     @endif
                  @endforeach
              </div>--}}
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 ">
            <div class="x_panel" id="abc">{{--$display_form --}}
              <div class="x_title">
                <h2> <small>{{ $Crud_page_title }} </small></h2>
                <div class="clearfix"></div>
              </div>
              <div class="x_content">
                <br />
                {{-- Create/Edit Form Start--}}
                  @if(!empty($Form))
                    <form action="{{ $action }}" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data"> 
                      @csrf
                      @if(!empty($data_edit))
                        @method('PUT')
                      @endif
                      <div class="row">
                        <div class="col-md-4 col-sm-12  form-group">
                          <label>category_name</label>
                          <input type="text" name="category_name" value="{{ $category_name }}" class="form-control" placeholder="Enter category_name" required/>
                          @if($errors->has('category_name'))   
                          <p class="help-block" style="color: #df4949;">{{$errors->first('category_name')}}</p>
                          @endif
                        </div>
                        <div class="col-md-4 col-sm-12  form-group">
                          <label>category_name</label>
                          <input type="text" name="description" value="{{ $description }}" class="form-control" placeholder="Enter description" required/>
                          @if($errors->has('description'))   
                          <p class="help-block" style="color: #df4949;">{{$errors->first('description')}}</p>
                          @endif
                        </div>
                      </div>
                      <div class="ln_solid"></div>
                      <div class=" form-group">
                        <div class="col-md-6 col-sm-6">
                          <button type="submit" class="btn btn-success">{{$button}}</button>
                          <button class="btn btn-primary" type="reset">Reset</button>
                        </div>
                      </div>
                    </form>
                  @endif
                {{-- Create/Edit Form End--}}
                {{-- Data List Start --}}
                  <div class="row">
                    <div class="col-md-12 col-sm-12 ">
                      <div class="x_panel">
                        <div class="x_title" style="color: white;background-color: #2a3f54;">
                          <h2>Total {{ $Crud_page_title }} ={{ count($data_list) }} <small></small></h2>
                        </div>
                        <div class="clearfix"></div>
                        <div class="x_content">
                          {{--<button id="sample_editable_1_new" class="btn btn-info">Add New +</button>--}}
                          {{-- Add Button Start   --}}
                            @if(empty($Form) && !empty($data_list))
                              <a href="{{ $add_btn_action }}" class="btn btn-info">
                                  <i class="fa fa-plus" aria-hidden="true"></i>
                                  Add New +
                              </a>
                            @endif
                        {{-- Add Button End     --}}
                          <div class="row">
                            <div class="col-sm-12">
                              <div class="card-box table-responsive">
                                <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                                  <thead>
                                    <tr>
                                      <th>category_name</th>
                                      <th>description</th>
                                      <th>Add Date</th>
                                      <th>Action</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    @foreach($data_list as $data_each)
                                      <tr>
                                        <td>{{$data_each->category_name}}</td>
                                        <td>{{$data_each->description}}</td>
                                        <td>{{$data_each->created_at}}</td>
                                        @php
                                            $id=$data_each->id;
                                            $edit_route=route('Category.edit',$id,'edit');
                                            $delete_route=route('Category.destroy',$id);
                                        @endphp
                                        <td style="width: 84px;">
                                          <a href="{{ $edit_route }}" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                                          <form method="post" action="{{ $delete_route }}">@csrf @method('DELETE') <input type="submit" value="Delete" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></form>
                                        </td>
                                      </tr>
                                    @endforeach
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                {{-- Data List End   --}}
              </div>
            </div>
          </div>
        </div>

      </div>
     @endsection
  {{-- pageContent dashboard End --}}