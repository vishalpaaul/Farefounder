@extends('backend.common.layout')
	@section('pageTitle','dashboard ')

	{{-- sideBar Section Start --}}           
	    @section('sideBar')
	      @include('backend.common.sidebar')
	    @endsection               
	{{-- sideBar Section End  --}}
	{{-- headerTop Section Start --}} 
		@section('headerTop')
	      @include('backend.common.header') 
	    @endsection  
	{{-- headerTop Section End  --}}

	{{-- pageContent dashboard Start --}} 
       @section('pageContent')
		<div class="main_container">
        

	  {{-- Flights Deals Start --}}
      @php
      use App\Models\Manageflightsdeal;
      $flightsdealCount = Manageflightsdeal::count();
      @endphp
      {{-- Flights Deals end --}}
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="row" style="display: inline-block;">
            <div class=" top_tiles" style="margin: 10px 0;">
              <div class="col-md-3 col-sm-3  tile">
                <span>Total Flights Deals</span>
                <h2>{{$flightsdealCount}}</h2>
                <span class="sparkline_one" style="height: 160px;">
                      <canvas width="200" height="60" style="display: inline-block; vertical-align: top; width: 94px; height: 30px;"></canvas>
                  </span>
              </div>
			  
	 
	  {{-- destination Start --}}
      @php
	  use App\Models\Managedestination;
      $destinationCount = Managedestination::where('page_type_id','=',3)->count();
	  @endphp
     {{-- destination end --}} 
			 
              <div class="col-md-3 col-sm-3  tile">
                <span>Total Destinations </span>
                <h2>{{$destinationCount}}</h2>
                <span class="sparkline_one" style="height: 160px;">
                      <canvas width="200" height="60" style="display: inline-block; vertical-align: top; width: 94px; height: 30px;"></canvas>
                  </span>
              </div>
			  {{-- contact Start --}}
            @php
           use App\Models\Managecontactenquiries;
            $contactCount = Managecontactenquiries::count();
            @endphp
           {{-- contact end --}} 
			 <div class="col-md-3 col-sm-3  tile">
                <span>Total Contact Enquiries </span>
                <h2>{{$contactCount}}</h2>
                <span class="sparkline_one" style="height: 160px;">
                      <canvas width="200" height="60" style="display: inline-block; vertical-align: top; width: 94px; height: 30px;"></canvas>
                  </span>
              </div> 
			  
			  {{-- contact Start --}}
            @php
           use App\Models\subscribers;
            $subscribeCount = subscribers::count();
            @endphp
           {{-- contact end --}} 
			  <div class="col-md-3 col-sm-3  tile">
                <span>Total News Subscribers  </span>
                <h2>{{$subscribeCount}}</h2>
                <span class="sparkline_one" style="height: 160px;">
                      <canvas width="200" height="60" style="display: inline-block; vertical-align: top; width: 94px; height: 30px;"></canvas>
                  </span>
              </div>
	<!--{{-- Airlines Start --}}
     @php
	  use App\Models\Manageairlines;
      $airlinesCount = Manageairlines::where('page_type_id','=',4)->count();
	  @endphp
     {{-- Airlines end --}} 
              <div class="col-md-3 col-sm-3  tile">
                <span>Total Airlines </span>
                <h2>{{$airlinesCount}}</h2>
                <span class="sparkline_one" style="height: 160px;">
                      <canvas width="200" height="60" style="display: inline-block; vertical-align: top; width: 94px; height: 125px;"></canvas>
                  </span> 
              </div>-->
			<!--{{-- Blog Start --}}
            @php
            use App\Models\Manageblog;
            $blogCount = Manageblog::count();
            @endphp
           {{-- Blog end --}}  
			  
              <div class="col-md-3 col-sm-3  tile">
                <span>Total  Blogs</span>
                <h2>{{$blogCount}}</h2>
                <span class="sparkline_one" style="height: 160px;">
                      <canvas width="200" height="60" style="display: inline-block; vertical-align: top; width: 94px; height: 30px;"></canvas>
                  </span>
              </div>-->
            </div>
          </div>
		  <br/>
		   
		  <!--<div class="row" style="display: inline-block;">
            <div class=" top_tiles" style="margin: 10px 0;">
              
			  
	 
	  
			 
              
			   
			   
            </div>
          </div>-->
            <br/>


            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="dashboard_graph x_panel">
                  <div class="x_title">
                    <div class="col-md-6">
                      <h3>Graph title sub-title <small></small></h3>
                    </div>
                    <div class="col-md-6">
                      <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
                        <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
                        <span style="color: #1abb9c;">{{ \Carbon\Carbon::today()->format('l d F Y') }}</span> At <span style="color: #1abb9c;">Current Time: <span id="live-clock" style="color: #1abb9c;">{{ now()->format('g:i:s A') }}</span></span> <b class="caret"></b>
                      </div>
                    </div>
                  </div>
                  <div class="x_content">
                    <div class="demo-container" style="height:250px">
                      <div id="chart_plot_03" class="demo-placeholder"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>


            
          </div>
        </div>	
			
			
		@endsection
    {{-- pageContent dashboard End  --}}
    {{-- DataTable dashboard Start  --}}
    	@section('DataTable')
    	
			</pre>
		@endsection
    {{-- DataTable dashboard End    --}}

    {{-- footerBottom Section Start --}}           
      @section('footerBottom')	      
	  	@include('backend.common.footer')
      @endsection          
    {{-- footerBottom Section End  --}}

    {{-- dataTableScripts scripts start --}}
	    {{-- @pushOnce('scripts') --}}
		    @push('dataTableScripts')
		        
		    @endpush
	    {{-- @endPushOnce --}}
	{{-- dataTableScripts scripts End   --}}