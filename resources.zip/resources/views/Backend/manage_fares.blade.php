@extends('Backend.common.layout')
	@section('pageTitle','Manage Fares')
      
	  
	  
	{{-- sideBar Section Start --}}           
	    @section('sideBar')
	      @include('Backend.common.sidebar')
	    @endsection               
	{{-- sideBar Section End  --}}
	{{-- headerTop Section Start --}} 
		@section('headerTop')
	      @include('Backend.common.header') 
	    @endsection  
	{{-- headerTop Section End  --}}

	{{-- pageContent dashboard Start --}} 
       @section('pageContent')


       {{-- Edit Update/Create Start --}}
        @if(!empty($manage_fares_edit))
          @php
	        $display_form = '';
			$action=route('manage_fares.update',$manage_fares_edit['id']);
			$button = 'Update';
			$page_id=$manage_fares_edit['page_id'];
            $origin=$manage_fares_edit['origin'];
            $Origin_code=$manage_fares_edit['Origin_code'];
            $destination=$manage_fares_edit['destination'];
            $destination_code=$manage_fares_edit['destination_code'];
            $from_date=$manage_fares_edit['from_date'];
            $to_date=$manage_fares_edit['to_date'];
            $price_in_usd=$manage_fares_edit['price_in_usd'];
            $result_url=$manage_fares_edit['result_url'];
            $status=$manage_fares_edit['status'];
		    $airline_image=$manage_fares_edit['airline_image'];
          @endphp
          @else
            @php
		     $display_form = 'style=display:none;';
			 $action=route('manage_fares.store',['page_id' => $page_id]);
			 $button = 'Submit';
              $page_id='';
			  $origin='';
              $Origin_code='';
              $destination='';
              $destination_code='';
              $from_date='';
              $to_date='';
              $price_in_usd='';
              $result_url='';
              $status= '';
			  $airline_image= '';
            @endphp
        @endif
       {{-- Edit Update/Create End --}}
	   
	   
       		<div class="right_col" role="main">
        
            <div class="page-title">
              <div class="title_left">
                <h3>Manage fares  
				<div class="flash-message" style="font-size: 14px;float: right;padding: 0 15px;width: 355px;height: 59px;">
       @foreach (['danger', 'warning', 'success', 'info'] as $msg)
         @if(Session::has('alert-' . $msg))

           <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
           </p>
         @endif
      @endforeach
  </div></h3>
				
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel" id="abc" {{$display_form}} >
                  <div class="x_title">
                    <h2> <small>Manage fares </small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
             <form action="{{ $action }}" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data"> 
			@csrf
      @if(!empty($manage_fares_edit))
        @method('PUT')
      @endif
             <div class="row">
	@if(session('page_id') || isset($manage_fares_edit))
    <input type="hidden" name="page_id" value="{{ session('page_id') ?? $manage_fares_edit->page_id }}" readonly>
@endif
             <div class="col-md-4 col-sm-12  form-group">
             <label>Origin Name</label>
            <input type="text" name="origin" value="{{ $origin }}" class="form-control" placeholder="Enter origin Name" required />
			@if($errors->has('origin'))   
			<p class="help-block" style="color: #df4949;">{{$errors->first('origin')}}</p>
			@endif
            </div>
			
		     <div class="col-md-4 col-sm-12  form-group">
             <label>Origin Code</label>
             <input type="text" name="Origin_code" class="form-control" placeholder="Enter origin Code" required value="{{ $Origin_code }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('Origin_code')}}</p>
             </div>
			 
			 <div class="col-md-4 col-sm-12  form-group">
              <label>Destination name</label>
              <input type="text" name="destination" class="form-control" placeholder="Enter Destination Name" required value="{{ $destination }}"/>
			  <p class="help-block" style="color: #df4949;">{{$errors->first('destination')}}</p>
              </div>
			  
			  </div>
			  <div class="row">
			 
             <div class="col-md-4 col-sm-12  form-group">
             <label>Destination Code</label>
            <input type="text" name="destination_code" value="{{ $destination_code }}" class="form-control" placeholder="Enter Destination Code" required />
			@if($errors->has('destination_code'))   
			<p class="help-block" style="color: #df4949;">{{$errors->first('destination_code')}}</p>
			@endif
            </div>
			
			<div class="col-md-4 col-sm-12  form-group">
             <label>Fare in  USD</label>
            <input type="text" name="price_in_usd" value="{{ $price_in_usd }}" class="form-control" placeholder="Enter USD" required />
			@if($errors->has('price_in_usd'))   
			<p class="help-block" style="color: #df4949;">{{$errors->first('price_in_usd')}}</p>
			@endif
            </div>
			
			<div class="col-md-4 col-sm-12  form-group">
             <label>From Date</label>
            <input type="text" name="from_date" data-date-format="dd-mm-yyyy" id="from_date" value="{{ $from_date }}" class="form-control" placeholder="Enter from date" required />
			@if($errors->has('from_date'))   
			<p class="help-block" style="color: #df4949;">{{$errors->first('from_date')}}</p>
			@endif
            </div>
			</div> 
			 <div class="row">
			 <div class="col-md-4 col-sm-12  form-group">
             <label>To Date</label>
            <input type="text" name="to_date" data-date-format="dd-mm-yyyy" id="to_date" value="{{ $to_date }}" class="form-control" placeholder="Enter to date" required />
			@if($errors->has('to_date'))   
			<p class="help-block" style="color: #df4949;">{{$errors->first('to_date')}}</p>
			@endif
            </div>
			
			<div class="col-md-4 col-sm-12  form-group">
             <label>Result url</label>
            <input type="text" name="result_url" value="{{ $result_url }}" class="form-control" placeholder="Enter result url" required />
			@if($errors->has('result_url'))   
			<p class="help-block" style="color: #df4949;">{{$errors->first('result_url')}}</p>
			@endif
            </div>
			<div class="col-md-4 col-sm-12  form-group">
            
             <label for="heard">Status</label>
                          <select id="heard" name="status" class="form-control" required>
                            <option value="Enabled" {{ ('Enabled' == $status) ? 'selected' : '' }} {{ ('Enabled' == old('status')) ? 'selected' : '' }}>Enabled</option>
                            <option value="Disabled" {{ ('Disabled' == $status) ? 'selected' : '' }} {{ ('Disabled' == old('status')) ? 'selected' : '' }}>Disabled</option>
                           
                          </select>
              </div>
			 </div>
			
			  
			 <div class="row">
             <div class="col-md-4 col-sm-12  form-group">
			 <br>
			 <div class="form-group">
    @php
        $airline_image_OP = $airline_image == '' ? old('airline_image') : $airline_image;
        $current_image = $airline_image ? asset('public/images/'.$airline_image) : asset('public/images/no_image.png');
    @endphp
	<label for="airline_image">Select Slider Image</label>

    <div class="mt-3">
        <img id="imagePreview" src="{{ $current_image }}" alt="Preview" class="img-thumbnail" 
             style="max-width: 200px; max-height: 150px;">
    </div>

    <button type="button" class="btn btn-primary mt-2" onclick="document.getElementById('airline_image').click();">
        Select Image
    </button>
<button type="button" class="btn btn-danger mt-2" id="removeImage" style="display: none;">Remove</button>
    <input type="file" class="d-none" id="airline_image" name="airline_image" onchange="previewImage(event)">
</div>
             </div>
			<!--<div class="form-group">
                        <label class="col-sm-3 control-label"> Image</label>
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                <div class="input-group">
                                    <div class="form-control uneditable-input" data-trigger="fileinput">
                                        <i class="glyphicon glyphicon-file fileinput-exists"></i>
                                        <span class="fileinput-filename"></span>
                                    </div>
                                    <span class="input-group-addon btn btn-default btn-file">
                                        <span class="fileinput-new">Select Image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="airline_image">
                                    </span>
                                    <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
                                    @error('airline_image')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
							
                            
                    </div>-->
			 
			 
			 
			 
			 </div>
                      
					  
                      
                      
                      <div class="ln_solid"></div>
                      <div class=" form-group">
                        <div class="col-md-6 col-sm-6">
                          
                          <button type="submit" class="btn btn-success">{{$button}}</button>
						  <button class="btn btn-primary" type="reset">Reset</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>
           
          

		     
            <div class="clearfix"></div>

            <div class="row">
             
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title" style="color: white;background-color: #2a3f54;">
                    <h2>Total fares = {{$count}} <small></small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
				  
                  <div class="x_content">
				  <button id="sample_editable_1_new" class="btn btn-info">Add New +</button>
                      <div class="row">
					  
                          <div class="col-sm-12">
						  
                            <div class="card-box table-responsive">
                    
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Origin</th>
                          <th>Origin Code</th>
                          <th>Destination</th>
                          <th>Destination Code</th>
						  <th>Slider Image</th>
                          <th>Add Date</th>
						  <th>Add By</th>
						  <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>


                      <tbody>
					  {{-- @dd($Managefares_show) --}}
                        @foreach($Managefares_show as $Managefares)
						
						<tr>
                          <td>{{$Managefares['origin']}}</td>
                          <td>{{$Managefares['Origin_code']}}</td>
                          <td>{{$Managefares['destination']}}</td>
                          <td>{{$Managefares['destination_code']}}</td>
                          <!--<td><img src="{{ asset('public/Backend_assets/images/img.jpg') }}" width="70px" height="70px" ></td>-->
                          <!--<td><img src="{{url(($Managefares['airline_image']))}}" width="70px" height="70px" ></td>-->
						  <td><img src="{{ asset('public/images/'.$Managefares['airline_image'] )}}" width="70px" height="70px" ></td>
						  
						@php
						//$dateFromDb=$Managefares['created_at'];
						//$dateFromDbDormated=date('d/m/Y',strtotime($dateFromDb));
					    //{{ $dateFromDbDormated }}
						@endphp
						
                          <td>
						  {{$Managefares['created_at']}}
						  </td>
                          <td>Admin</td>
						  <td>
                          

						  <label class="switch">
						   
                           <input type="checkbox" @if($Managefares['status']=='Enabled')  checked @endif >
						  
						  <span class="slider round"></span>
                           </label>
                          </td>
						  <td style="width: 84px;">
						  {{--@dd($Managefares)--}}
						   <a href="{{route('manage_fares.edit',$Managefares['id'])}}" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            
						
							<form method="post" action="{{route('manage_fares.destroy',$Managefares['id'])}}" style="display: contents;">@csrf @method('DELETE') 
                            <button type="submit" onclick="return confirm('Are You Wanna delete Permanentely This Record ?')" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i>
                            </button>
                             </form>
                          </td>
                        </tr>
						@endforeach
						
						
						
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>

              

            

              
            </div>
          
        </div>
		@endsection
    {{-- pageContent dashboard End  --}}
    {{-- DataTable dashboard Start  --}}
    	@section('DataTable')
    	
			</pre>
		@endsection
    {{-- DataTable dashboard End    --}}

    {{-- footerBottom Section Start --}}           
      @section('footerBottom')	      
	  	@include('Backend.common.footer')
      @endsection          
    {{-- footerBottom Section End  --}}

    {{-- dataTableScripts scripts start --}}
	    {{-- @pushOnce('scripts') --}}
		    @push('dataTableScripts')
		        
		    @endpush
	    {{-- @endPushOnce --}}
	{{-- dataTableScripts scripts End   --}}

	