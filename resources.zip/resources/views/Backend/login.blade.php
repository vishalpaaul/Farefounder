<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="http://localhost/Rd/Lara_admin/public/images/favicon.ico " type="image/x-icon"> 
    <title>Farefounder.com - Login </title>

    <!-- Bootstrap -->
    <link href="{{ asset('public/Lara_admin_assets/vendors/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="{{ asset('public/Lara_admin_assets/vendors/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
    <!-- NProgress -->
    <link href="{{ asset('public/Lara_admin_assets/vendors/nprogress/nprogress.css') }}" rel="stylesheet">
    <!-- Animate.css -->
    <link href="{{ asset('public/Lara_admin_assets/vendors/animate.css/animate.min.css') }}" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="{{ asset('public/Lara_admin_assets/build/css/custom.min.css') }}" rel="stylesheet">
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>
      
      <div class="login_wrapper">
        <div class="animate form login_form">
		<div class="flash-message" style="font-size: 14px;text-align: center;padding: 0 15px;
    width: 355px;height: 59px;margin: 0 auto;">
       @foreach (['danger', 'warning', 'success', 'info'] as $msg)
         @if(Session::has('alert-' . $msg))

           <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}
           
           </p>
         @endif
      @endforeach
  </div>
          <section class="login_content">
            <form action="{{route('AdminLogin') }}" method="post">
              @csrf   
              <h1> {{ __('Login to your account') }} </h1>
              <div>
                <input type="text" name="email"class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" value="{{ old('email') }}" placeholder="User Name" ="" />
				@if ($errors->has('email'))
                  <span class="invalid-feedback">
                   <strong>{{ $errors->first('email') }}</strong>
                   </span>
                    @endif
              </div>
              <div>
               <input type="password" name="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" placeholder="Password"   />
			   @if ($errors->has('password'))
				<span class="invalid-feedback">
					<strong>{{ $errors->first('password') }}</strong>
				</span>
			@endif
              </div>
			  <div>
			  <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> {{ __('Remember Me') }}
			  </div>
			  <br>
              <div>
                <button type="submit" class="btn btn-info btn-sm" style="width: 100%;">{{ __('Log in') }}</button>
                
                <!--<a class="reset_pass" href="#">Lost your password?</a>-->
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                

                <div class="clearfix"></div>
                <br />

                <div>
               
                  <p>©2024 All Rights Reserved.SoftwareXprts.com</p>
                </div>
              </div>
            </form>
          </section>
        </div>

        
      </div>
    </div>
  </body>
</html>
