@extends('Backend.common.layout')
	@section('pageTitle','Manage Destination')
      
	  
	  
	{{-- sideBar Section Start --}}           
	    @section('sideBar')
	      @include('Backend.common.sidebar')
	    @endsection               
	{{-- sideBar Section End  --}}
	{{-- headerTop Section Start --}} 
		@section('headerTop')
	      @include('Backend.common.header') 
	    @endsection  
	{{-- headerTop Section End  --}}

	{{-- pageContent dashboard Start --}} 
       @section('pageContent')


       {{-- Edit Update/Create Start --}}
        @if(!empty($manage_destination_edit))
          @php
	        $display_form = '';
			$action=route('manage_destination.update',$manage_destination_edit['page_id']);
			$button = 'Update';
           
            $short_code=$manage_destination_edit['short_code'];
            $page_type_id=$manage_destination_edit['page_type_id'];
            $destinations_type=$manage_destination_edit['destinations_type'];
            $page_name=$manage_destination_edit['page_name'];
            $page_title=$manage_destination_edit['page_title'];
            $page_display_name=$manage_destination_edit['page_display_name'];
            $paratitle=$manage_destination_edit['paratitle'];
            $paracontent=$manage_destination_edit['paracontent'];
            $page_description=$manage_destination_edit['page_description'];
            $page_keyword=$manage_destination_edit['page_keyword'];
			$author=$manage_destination_edit['author'];
            $robots=$manage_destination_edit['robots'];
            $og_type=$manage_destination_edit['og_type'];
            $og_title=$manage_destination_edit['og_title'];
            $og_description=$manage_destination_edit['og_description'];
            $og_url=$manage_destination_edit['og_url'];
            $status=$manage_destination_edit['status'];
		    $og_image=$manage_destination_edit['og_image'];
          @endphp
          @else
            @php
		     $display_form = 'style=display:none;';
			 $action=route('manage_destination.store');
			 $button = 'Submit';
             $short_code ='';
			 $page_type_id ='';
			 $destinations_type ='';
			 $page_name  ='';
			 $page_title  ='';
			 $page_display_name  ='';
			 $paratitle ='';
			 $paracontent ='';
			 $page_description  ='';
			 $page_keyword  ='';
			 $author  ='';
			 $robots ='';
			 $og_type ='';
			 $og_title  ='';
			 $og_description  ='';
			 $og_url  ='';
			 $og_image ='';
             $status= '';
			 
            @endphp
        @endif
       {{-- Edit Update/Create End --}}
	   
	   
       		<div class="right_col" role="main">
        
            <div class="page-title">
              <div class="title_left">
                <h3>Manage Destination  
				<div class="flash-message" style="font-size: 14px;float: right;padding: 0 15px;width: 355px;height: 59px;">
      @foreach (['danger', 'warning', 'success', 'info'] as $msg)
    @if(Session::has('alert-' . $msg))
        <p class="alert alert-{{ $msg }}">
            {{ Session::get('alert-' . $msg) }}
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        </p>
    @endif
   @endforeach

{{-- Add the short_code error check within the same pattern --}}
@if ($errors->has('short_code'))
    <p class="alert alert-danger"> {{-- Changed to alert-danger for consistency --}}
        {{ $errors->first('short_code') }}
        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    </p>
@endif

  </div></h3>
				
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel" id="abc" {{$display_form}} >
                  <div class="x_title">
                    <h2> <small>Manage Destination </small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
             <form action="{{ $action }}" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data"> 
			@csrf
      @if(!empty($manage_destination_edit))
        @method('PUT')
      @endif
             <div class="row">
			 <div class="col-md-4 col-sm-12  form-group">
            
             <label for="heard">Page Type Name</label>
                          <select id="heard" name="page_type_id" class="form-control" >
                            
							<option value="3" {{ ('3' == $page_type_id) ? 'selected' : '3' }} {{ ('3' == old('page_type_id')) ? 'selected' : '3'}}>manage destination</option>
                            
                          </select>
              </div>
             <div class="col-md-4 col-sm-12  form-group">
             <label for="heard">Destinations Type</label>
              <select id="heard" name="destinations_type" class="form-control" required>
               <option value="Domestic" {{ ('Domestic' == $destinations_type) ? 'selected' : 'Domestic' }} {{ ('Domestic' == old('destinations_type')) ? 'selected' : 'Domestic'}}>Domestic Destinations</option>
			   <option value="International" {{ ('International' == $destinations_type) ? 'selected' : 'International' }} {{ ('International' == old('destinations_type')) ? 'selected' : 'International'}}>International Destinations </option>
			   <option value="routes" {{ ('routes' == $destinations_type) ? 'selected' : 'routes' }} {{ ('routes' == old('destinations_type')) ? 'selected' : 'routes'}}>Special Offers </option>
			   
               </select>
			
            </div>
			
		     <div class="col-md-4 col-sm-12  form-group">
             <label>Destination Name</label>
             <input type="text" name="page_display_name" class="form-control" placeholder="Enter Page display Name" required value="{{ $page_display_name }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('page_display_name')}}</p>
             </div>
			 
			 
			  
			  </div>
			  <div class="row">
			 <div class="col-md-4 col-sm-12  form-group">
             <label>Page Url Name </label>
             <input type="text" name="page_name" class="form-control" placeholder="Enter Page Url Name" required value="{{ $page_name }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('page_name')}}</p>
             </div>
			 <div class="col-md-4 col-sm-12  form-group">
             <label>Page Title Name</label>
             <input type="text" name="page_title" class="form-control" placeholder="Enter Page Title" required value="{{ $page_title }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('page_title')}}</p>
             </div>
			 <div class="col-md-4 col-sm-12  form-group">
             <label>Page description Name</label>
             <input type="text" name="page_description" class="form-control" placeholder="Enter Page description" required value="{{ $page_description }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('page_description')}}</p>
             </div>
			  
			  </div>
			  <div class="row">
			 <div class="col-md-4 col-sm-12  form-group">
             <label>Page Keyword </label>
             <input type="text" name="page_keyword" class="form-control" placeholder="Enter page keyword" required value="{{ $page_keyword }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('page_keyword')}}</p>
             </div>
			 <div class="col-md-4 col-sm-12  form-group">
             <label>Author</label>
             <input type="text" name="author" class="form-control" placeholder="Enter author" required value="{{ $author }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('author')}}</p>
             </div>
			 <div class="col-md-4 col-sm-12  form-group">
             <label>Robots</label>
             <input type="text" name="robots" class="form-control" placeholder="Enter robots" required value="{{ $robots }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('robots')}}</p>
             </div>
			  
			  </div>
			  <div class="row">
			 <div class="col-md-4 col-sm-12  form-group">
             <label>Og Type </label>
             <input type="text" name="og_type" class="form-control" placeholder="Enter og_type" required value="{{ $og_type }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('og_type')}}</p>
             </div>
			 <div class="col-md-4 col-sm-12  form-group">
             <label>Og Title</label>
             <input type="text" name="og_title" class="form-control" placeholder="Enter og_title" required value="{{ $og_title }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('og_title')}}</p>
             </div>
			 <div class="col-md-4 col-sm-12  form-group">
             <label>Og Description</label>
             <input type="text" name="og_description" class="form-control" placeholder="Enter og_description" required value="{{ $og_description }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('og_description')}}</p>
             </div>
			  
			  </div>
			  
			  <div class="row">
			 <div class="col-md-4 col-sm-12  form-group">
             <label>Og Url</label>
             <input type="text" name="og_url" class="form-control" placeholder="Enter og url" required value="{{ $og_url }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('og_url')}}</p>
             </div>
			 <div class="col-md-4 col-sm-12  form-group">
             <label>Og Image</label>
             <input type="file" name="og_image" class="form-control" placeholder="Enter author" value="{{ $og_image }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('og_image')}}</p>
             </div>
			 <div class="col-md-4 col-sm-12  form-group">
             <label>Sort Code</label>
             <input type="text" name="short_code" class="form-control" placeholder="Enter Sort Code" required value="{{ $short_code }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('short_code')}}</p>
             </div>
			  
			  </div>
			  <div class="row">
			 <div class="col-md-4 col-sm-12  form-group">
             <label>Places to visit Title</label>
             <input type="text" name="paratitle" class="form-control" placeholder="Places to visit Title" required value="{{ $paratitle }}"/>
			 <p class="help-block" style="color: #df4949;">{{$errors->first('paratitle')}}</p>
             </div>
			 </div>
			   <div class="row">
			   <div class="col-md-12 col-sm-12  form-group">
              <label>Places to visit Description </label>
               <textarea type="text" name="paracontent" placeholder="page description" id="editor">{{ $paracontent }}</textarea>
                  
			  <p class="help-block" style="color: #df4949;">{{$errors->first('paracontent')}}</p>
              </div>
			   </div>
			 
			
			  
			 <div class="row">
             
			 <div class="col-md-4 col-sm-12  form-group">
            
             <label for="heard">Status</label>
                          <select id="heard" name="status" class="form-control" required>
                            <option value="Enabled" {{ ('Enabled' == $status) ? 'selected' : '' }} {{ ('Enabled' == old('status')) ? 'selected' : '' }}>Enabled</option>
                            <option value="Disabled" {{ ('Disabled' == $status) ? 'selected' : '' }} {{ ('Disabled' == old('status')) ? 'selected' : '' }}>Disabled</option>
                           
                          </select>
              </div>
			
			 
			 
			 
			 
			 </div>
                      
					  
                      
                      
                      <div class="ln_solid"></div>
                      <div class=" form-group">
                        <div class="col-md-6 col-sm-6">
                          
                          <button type="submit" class="btn btn-success">{{$button}}</button>
						  <button class="btn btn-primary" type="reset">Reset</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>
           
          

		     
            <div class="clearfix"></div>

            <div class="row">
             
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title" style="color: white;background-color: #2a3f54;">
                    <h2>Total Manage Destination = {{$count}} <small></small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
				  
                  <div class="x_content">
				  <button id="sample_editable_1_new" class="btn btn-info">Add New +</button>
                      <div class="row">
					  
                          <div class="col-sm-12">
						  
                            <div class="card-box table-responsive">
                    
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Page Url Name</th>
						  <th>Page Title</th>
	                      <th>Short Code</th>
			              <th>Display Name</th>
						  <th>Images</th>
						  <th>Display image</th>
						  <th>Add Fares</th>
                          <th>Add Date</th>
						  <th>Add By</th>
						  <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>


                      <tbody>
					  {{-- @dd($Managedestination_show) --}}
                        @foreach($Managedestination_show as $Managedestination)
						
						<tr>
                          
                          <td>{{$Managedestination['page_name']}}</td>
                          <td>{{$Managedestination['page_title']}}</td>
                          <td>{!!$Managedestination['short_code']!!}</td>
                          <td>{!!$Managedestination['page_display_name']!!}</td>
                          <!--<td><img src="{{ asset('public/Backend_assets/images/img.jpg') }}" width="70px" height="70px" ></td>-->
                          <!--<td><img src="{{url(($Managedestination['og_image']))}}" width="70px" height="70px" ></td>-->
						  <td><img src="{{ asset('public/images/'.$Managedestination['og_image'] )}}" width="70px" height="70px" ></td>
						  <td>
						
						  <a class="btn btn-info" id="sample_editable_1_new" href="{{ url('admin/manage_pages_image', $Managedestination['page_id']) }}">Add Image</a>
					      </td>
						  <td>
						  <a class="btn btn-info" id="sample_editable_1_new" href="{{ url('admin/manage_fares', $Managedestination['page_id']) }}">
						  Add Fares</a>
                          </td>
						@php
						//$dateFromDb=$Managedestination['created_at'];
						//$dateFromDbDormated=date('d/m/Y',strtotime($dateFromDb));
					    //{{ $dateFromDbDormated }}
						@endphp
						
                          <td>
						  {{$Managedestination['created_at']}}
						  </td>
                          <td>Admin</td>
						  <td>
                           <label class="switch">
						   
                           <input type="checkbox" @if($Managedestination['status']=='Enabled')  checked @endif >
						  
						  <span class="slider round"></span>
                           </label>
                          </td>
						  <td style="width: 84px;">
						  {{--@dd($Managedestination)--}}
						   <a href="{{route('manage_destination.edit',$Managedestination['page_id'])}}" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                            
						
							<form method="post" action="{{route('manage_destination.destroy',$Managedestination['page_id'])}}" style="display: contents;">@csrf @method('DELETE') 
                            <button type="submit" onclick="return confirm('Are You Wanna delete Permanentely This Record ?')" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i>
                            </button>
                             </form>
                          </td>
                        </tr>
						@endforeach
						
						
						
                      </tbody>
                    </table>
					<!-- Pagination Links -->
                 <div class="d-flex justify-content-center">
    {!! $Managedestination_show->links('vendor.pagination.bootstrap-5') !!}
</div>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>

              

            

              
            </div>
          
        </div>
		@endsection
    {{-- pageContent dashboard End  --}}
    {{-- DataTable dashboard Start  --}}
    	@section('DataTable')
    	
			</pre>
		@endsection
    {{-- DataTable dashboard End    --}}

    {{-- footerBottom Section Start --}}           
      @section('footerBottom')	      
	  	@include('Backend.common.footer')
      @endsection          
    {{-- footerBottom Section End  --}}

    {{-- dataTableScripts scripts start --}}
	    {{-- @pushOnce('scripts') --}}
		    @push('dataTableScripts')
		        
		    @endpush
	    {{-- @endPushOnce --}}
	{{-- dataTableScripts scripts End   --}}

	