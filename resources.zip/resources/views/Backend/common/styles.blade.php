 <!-- Bootstrap -->
    <link href="{{ asset('public/Lara_admin_assets/cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css') }}">
    <link href="{{ asset('public/Lara_admin_assets/vendors/bootstrap/dist/css/bootstrap.min.css')}}" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="{{ asset('public/Lara_admin_assets/vendors/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet">
    <!-- NProgress -->
    <link href="{{ asset('public/Lara_admin_assets/vendors/nprogress/nprogress.css')}}" rel="stylesheet">
    <!-- iCheck -->
    <link href="{{asset('public/Lara_admin_assets/vendors/iCheck/skins/flat/green.css')}}" rel="stylesheet">
    <!-- Datatables -->
    
    <link href="{{ asset('public/Lara_admin_assets/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{ asset('public/Lara_admin_assets/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{ asset('public/Lara_admin_assets/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{ asset('public/Lara_admin_assets/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{ asset('public/Lara_admin_assets/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css')}}" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="{{ asset('public/Lara_admin_assets/build/css/custom.min.css')}}" rel="stylesheet">
	<link href="{{ asset('public/Lara_admin_assets/vendors/dropzone/dist/min/dropzone.min.css')}}" rel="stylesheet">
	<link href="{{ asset('public/Lara_admin_assets/vendors/bootstrap-daterangepicker/daterangepicker.css')}}" rel="stylesheet">
    <!-- bootstrap-datetimepicker -->
    <link href="{{ asset('public/Lara_admin_assets/vendors/bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.css')}}" rel="stylesheet">
	
	 <link href="{{ asset('public/Lara_admin_assets/vendors/cropper/dist/cropper.min.css')}}" rel="stylesheet">
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- bootstrap-progressbar -->
    <link href="{{ asset('public/Lara_admin_assets/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css')}}" rel="stylesheet">
	<!-- Animate.css -->
    <link href="{{ asset('public/Lara_admin_assets/vendors/animate.css/animate.min.css')}}" rel="stylesheet">