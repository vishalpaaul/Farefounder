@php
 use App\Models\Manageglobaldetails;
  $logodetail = Manageglobaldetails::first();
 @endphp
<div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="{{ url('admin/dashboard') }}" class="site_title"><img src="{{ asset('public/images/'.$logodetail['airline_image'] )}}" style="height: 30px;" alt=""> </a>
            </div>

            <div class="clearfix"></div>


            <!-- sidebar menu -->
           <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              
			  <div class="menu_section">
               
                <ul class="nav side-menu">
                  <li><a href="{{ url('admin/dashboard') }}"><i class="fa fa-home"></i> Dashboard </a>
                    
                  </li>
				  <li><a><i class="fa fa-clone"></i> Manage Hot Deals <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                   <li><a href="{{url('admin/manage_hotdeals') }}">Manage Hot Deals</a></li>
                     
                      
                    </ul>
                  </li>
				  <li><a><i class="fa fa-clone"></i> Manage Flights Deal <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="{{ url('admin/manage_flights_deal') }}">Manage Flights Deal</a></li>
                     </ul>
                    </li>
				  
                  <li><a><i class="fa fa-clone"></i> Manage Home Slider <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="{{ url('admin/manage_home_slider') }}">Manage Slider Images</a></li>
                      <li><a href="{{ url('admin/manage_home_page_title') }}">Manage Home Page Title</a></li>
                      
                    </ul>
                  </li>
                  <li><a><i class="fa fa-clone"></i> Manage Global Details <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="{{ url('admin/manage_global_details') }}">Manage Global Details</a></li>
                     
                      
                    </ul>
                  </li>
				  <li><a><i class="fa fa-clone"></i> Manage Contact Enquiries <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="{{ url('admin/manage_contact_enquiries') }}">Manage Contact Enquiries</a></li>
                     <li><a href="{{ url('admin/manage_news_subscribers') }}">Manage News Subscribers</a></li>
                      
                    </ul>
                  </li>
				  <li><a><i class="fa fa-clone"></i> Manage Destination <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="{{ url('admin/manage_destination') }}">Manage Destination</a></li>
                     
                      
                    </ul>
                  </li>
				  <!--<li><a><i class="fa fa-clone"></i> Manage Airlines <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="{{ url('/manage_airlines_pages') }}">Manage Airlines</a></li>
                     
                      
                    </ul>
                  </li>-->
                  <li><a><i class="fa fa-clone"></i> Manage Information <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="{{ url('admin/manage_information')}}">Manage Information</a></li>
                     
                      
                    </ul>
                  </li> 
                  <!--<li><a><i class="fa fa-clone"></i> Manage blogs
                   <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="{{ url('/manage_blog')}}">Manage blogs</a></li>
                     
                      
                    </ul>
                  </li> -->
                  <!--<li><a><i class="fa fa-clone"></i> Tables <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="tables.html">Tables</a></li>
                      <li><a href="tables_dynamic.html">Table Dynamic</a></li>
                    </ul>
                  </li>-->
                  
                  
                </ul>
              </div>
              

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="{{ route('logout') }}">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>