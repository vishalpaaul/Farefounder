<!DOCTYPE html>
<html lang="en">
  <head>
    <title>@yield('pageTitle') </title>
      @include('backend.common.seo_head') 
            @include('backend.common.styles')
    <!--<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">-->
    <!-- Meta, title, CSS, favicons, etc. -->
    <!--<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">-->

    
</head>
   <body class="nav-md">
    <div class="container body">
      <div class="main_container">
            {{-- sideBar Section Start --}}           
                @yield('sideBar')             
            {{-- sideBar Section End  --}}           

            {{-- headerTop Section Start --}}           
                @yield('headerTop')             
            {{-- headerTop Section End  --}}
            
    
        {{-- pageContent Section Start --}}
        
            @yield('pageContent')
                {{-- DataTable Section Start --}}           
                    @yield('DataTable')             
                {{-- DataTable Section End  --}}
           
                {{-- footerBottom Section Start --}}           
                    @yield('footerBottom')             
                {{-- footerBottom Section End  --}}
        
        {{-- pageContent Section End  --}}
        
        {{--  --}} 
        @include('backend.common.scripts') 
    </div>
    </div>
	</body>

</html>
