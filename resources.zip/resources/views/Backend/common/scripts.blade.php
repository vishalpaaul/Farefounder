<!-- jQuery old -->
    <script src="{{ asset('public/Lara_admin_assets/vendors/jquery/dist/jquery.min.js') }}"></script>
	<!-- jQuery new  --> 
	<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>-->
    <!-- Bootstrap -->
   <script src="{{ asset('public/Lara_admin_assets/vendors/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>
    <!-- FastClick -->
    <script src="{{ asset('public/Lara_admin_assets/vendors/fastclick/lib/fastclick.js') }}"></script>
    <!-- NProgress -->
    <script src="{{ asset('public/Lara_admin_assets/vendors/nprogress/nprogress.js') }}"></script>
    <!-- iCheck -->
    <script src="{{ asset('public/Lara_admin_assets/vendors/iCheck/icheck.min.js') }}"></script>
    <!-- Datatables -->
    <script src="{{ asset('public/Lara_admin_assets/vendors/datatables.net/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/datatables.net-buttons/js/dataTables.buttons.min.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/datatables.net-buttons/js/buttons.flash.min.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/datatables.net-buttons/js/buttons.html5.min.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/datatables.net-buttons/js/buttons.print.min.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/datatables.net-responsive/js/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/datatables.net-scroller/js/dataTables.scroller.min.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/jszip/dist/jszip.min.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/pdfmake/build/pdfmake.min.js') }}"></script>
    <script src="{{ asset('public/Lara_admin_assets/vendors/pdfmake/build/vfs_fonts.js') }}"></script>

    <!-- Custom Theme Scripts -->
    <script src="{{ asset('public/Lara_admin_assets/build/js/custom.min.js') }}"></script>
	<script src="{{ asset('public/Lara_admin_assets/vendors/dropzone/dist/min/dropzone.min.js') }}"></script>
	<script src="{{ asset('public/Lara_admin_assets/vendors/bootstrap-daterangepicker/daterangepicker.js') }}"></script>
    <!-- bootstrap-datetimepicker -->    
    <script src="{{ asset('public/Lara_admin_assets/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js') }}"></script>
	
    <!-- bootstrap-daterangepicker -->
    <script src="{{ asset('public/Lara_admin_assets/vendors/moment/min/moment.min.js') }}"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<script src="{{asset('public/Lara_admin_assets/ckeditor.js') }}"></script>
	<script src="{{asset('public/Lara_admin_assets/js/sample.js') }}"></script>
<link type="text/css" rel="stylesheet" href="{{ asset('public/Lara_admin_assets/jqte/jquery-te-1.4.0.css') }}">


<script type="text/javascript" src="{{ asset('public/Lara_admin_assets/jqte/jquery-te-1.4.0.min.js')}}" charset="utf-8"></script>
<script src="{{ asset('public/Lara_admin_assets/vendors/Chart.js/dist/Chart.min.js')}}"></script>
<script src="{{ asset('public/Lara_admin_assets/vendors/jquery-sparkline/dist/jquery.sparkline.min.js')}}"></script>
<!-- morris.js -->
<script src="{{ asset('public/Lara_admin_assets/vendors/raphael/raphael.min.js')}}"></script>
<script src="{{ asset('public/Lara_admin_assets/vendors/morris.js/morris.min.js')}}"></script>
<!-- gauge.js -->
    <script src="{{ asset('public/Lara_admin_assets/vendors/gauge.js/dist/gauge.min.js')}}"></script>
<!-- bootstrap-progressbar -->
    <script src="{{ asset('public/Lara_admin_assets/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js')}}"></script>
<!-- Skycons -->
    <script src="{{ asset('public/Lara_admin_assets/vendors/skycons/skycons.js')}}"></script>
<!-- Flot -->
    <script src="{{ asset('public/Lara_admin_assets/vendors/Flot/jquery.flot.js')}}"></script>
<script src="{{ asset('public/Lara_admin_assets/vendors/Flot/jquery.flot.pie.js')}}"></script>
<script src="{{ asset('public/Lara_admin_assets/vendors/Flot/jquery.flot.time.js')}}"></script>	
 <script src="{{ asset('public/Lara_admin_assets/vendors/Flot/jquery.flot.stack.js')}}"></script>
 <script src="{{ asset('public/Lara_admin_assets/vendors/Flot/jquery.flot.resize.js')}}"></script>
  <!-- Flot plugins -->
    <script src="{{ asset('public/Lara_admin_assets/vendors/flot.orderbars/js/jquery.flot.orderBars.js')}}"></script>
	 <script src="{{ asset('public/Lara_admin_assets/vendors/flot-spline/js/jquery.flot.spline.min.js')}}"></script>
	 <script src="{{ asset('public/Lara_admin_assets/vendors/flot.curvedlines/curvedLines.js')}}"></script>
	 <!-- DateJS -->
    <script src="{{ asset('public/Lara_admin_assets/vendors/DateJS/build/date.js')}}"></script>
	<script>
	initSample();
</script>
	<script>
				  var a= new nicEditor({fullPanel : true}).panelInstance('editor_1');
                  </script>
				  <script>var editor = new MediumEditor('.editable');</script>
	<script>
	
  $( function() {
$('#from_date').datepicker({ 
    minDate: new Date(),  // No past dates
 
});

$('#to_date').datepicker({ 
   minDate: new Date(),
});

  } );
  </script>
<script>
$('#sample_editable_1_new').click(function(){
	$("#abc").toggle(500);
	
});
</script>
<script>
    function previewImage(event) {
        var reader = new FileReader();
        reader.onload = function() {
            var output = document.getElementById('imagePreview');
            output.src = reader.result;
            document.getElementById('removeImage').style.display = 'inline-block';
        };
        reader.readAsDataURL(event.target.files[0]);
    }

    document.getElementById('removeImage').addEventListener('click', function() {
        document.getElementById('imagePreview').src = "{{ asset('public/images/no_image.png') }}";
        document.getElementById('airline_image').value = '';
        this.style.display = 'none';
    });
</script>
<script>
    function updateClock() {
        let now = new Date();
        let hours = now.getHours() % 12 || 12; // Convert to 12-hour format (12-hour clock)
        let minutes = now.getMinutes().toString().padStart(2, '0'); // Add leading zero if needed
        let seconds = now.getSeconds().toString().padStart(2, '0'); // Add leading zero if needed
        let ampm = now.getHours() >= 12 ? 'PM' : 'AM';
        let timeString = hours + ":" + minutes + ":" + seconds + " " + ampm;

        let clockElement = document.getElementById("live-clock");
        if (clockElement) {
            clockElement.textContent = timeString;
        }
    }

    document.addEventListener("DOMContentLoaded", function() {
        setInterval(updateClock, 1000); // Update every second
        updateClock(); // Initialize immediately
    });
</script>

<script>
    $(document).ready(function () {
        $('.toggle-status').change(function () {
            let id = $(this).data('id');
            let status = $(this).prop('checked') ? 'Enabled' : 'Disabled';

            $.ajax({
                url: routes.updateStatus, // Automatically fetch the correct URL
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    id: id,
                    status: status
                },
                success: function (response) {
                    alert(response.message);
                },
                error: function (error) {
                    console.log(error);
                    alert("Something went wrong!");
                }
            });
        });
    });
</script>