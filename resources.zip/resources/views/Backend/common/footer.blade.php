<footer>
          <div class="pull-right">
            Design and development by Software Xprts Services 
          </div>
          <div class="clearfix"></div>
        </footer>