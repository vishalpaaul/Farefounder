<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\frontend\HomeController;

use App\Http\Controllers\Backend\ManageflightsdealController;
use App\Http\Controllers\Backend\HomeSliderController;
use App\Http\Controllers\Backend\ManagehomepagetitleController;
use App\Http\Controllers\Backend\ManageglobaldetailsController;
use App\Http\Controllers\Backend\ManageinformationController;
use App\Http\Controllers\Backend\ManagedestinationController;
use App\Http\Controllers\Backend\ManageairlinesController;
use App\Http\Controllers\Backend\ManageblogController;
use App\Http\Controllers\Backend\ManagecontactController;
use App\Http\Controllers\Backend\ManagepagesimageController;
use App\Http\Controllers\Backend\AdminLoginController;
use App\Http\Controllers\Backend\ChangepasswordController;
use App\Http\Controllers\Backend\ManageblogimageController;
use App\Http\Controllers\Backend\ManagefaresController;
use App\Http\Controllers\Backend\ManagehotdealController;



// Admin Authentication Routes (Login)
Route::get('/admin/login', [AdminLoginController::class, 'login'])->name('login');
Route::post('/admin/login', [AdminLoginController::class, 'AdminLogin'])->name('AdminLogin');;
Route::get('/admin/logout',[AdminLoginController::class, 'logout'])->name('logout');


// Backend Routes
Route::group(['prefix' => 'admin', 'middleware' => 'auth:admin'], function () {
Route::get('/dashboard', [AdminLoginController::class, 'dashboard'])->name('admin.dashboard');
Route::get('/dashboard',[AdminLoginController::class, 'dashboard'])->name('admin.dashboard');
Route::resource('manage_flights_deal',ManageflightsdealController::class);

Route::resource('manage_home_slider',HomeSliderController::class);
Route::resource('manage_home_page_title',ManagehomepagetitleController::class);
Route::resource('manage_global_details',ManageglobaldetailsController::class);
Route::resource('manage_information',ManageinformationController::class);
Route::resource('manage_destination',ManagedestinationController::class);
Route::resource('manage_airlines_pages',ManageairlinesController::class);
Route::resource('manage_blog',ManageblogController::class);
Route::resource('manage_contact_enquiries',ManagecontactController::class);
Route::resource('change_password',ChangepasswordController::class);
Route::resource('manage_pages_image',ManagepagesimageController::class);
Route::resource('manage_fares',ManagefaresController::class);
Route::resource('manage_blog_image',ManageblogimageController::class);
Route::resource('manage_hotdeals',ManagehotdealController::class);
Route::post('manage_hotdeals/update-status', [ManagehotdealController::class, 'updateStatus'])
    ->name('manage_hotdeals.updateStatus');
});
// Frontend Routes
Route::group(['namespace' => 'Frontend'], function () {
Route::get('/', [HomeController::class, 'index'])->name('index');
Route::get('index', [HomeController::class, 'index'])->name('index');
Route::get('about-us', [HomeController::class, 'about'])->name('about');
Route::get('privacy-policy', [HomeController::class, 'privacy'])->name('privacy');
Route::get('terms-conditions', [HomeController::class, 'terms'])->name('terms');
Route::get('refund-policy', [HomeController::class, 'refund'])->name('refund');
Route::get('Cancellation-policy', [HomeController::class, 'Cancellation'])->name('Cancellation');
Route::get('contact-us', [HomeController::class, 'contact'])->name('contact');
Route::get('special-offers', [HomeController::class, 'special'])->name('special');
Route::get('/domestic/{page_id}', [HomeController::class, 'destinations'])->name('destinations');
Route::get('/International/{page_id}', [HomeController::class, 'destinations'])->name('destinations');	
Route::get('/routes/{page_id}', [HomeController::class, 'destinations'])->name('destinations');	
Route::post('contact-us', [HomeController::class, 'submitForm'])->name('contact.submit');
Route::post('/subscribers', [HomeController::class, 'subscribers'])->name('subscribers');



});

